# Import files

Import in file-name order (01 → 90) with the module `logistics_crm_demo` installed, the CRM "Leads" setting on, and all three Tervane companies active. Full steps: `docs/08_installation_guide.md`. Per-file detail: `docs/05_manifest_and_volume_matrix.md` and `docs/generated/manifest.csv`.

All data is fictional. Business dates assume installation on 2 Nov 2026; regenerate with `tools/build_docs_tables.py --as-of YYYY-MM-DD` for another date.

Do not re-import `02_res_users.csv` once the users exist. Every other file can be re-imported safely (external IDs update the same records).
