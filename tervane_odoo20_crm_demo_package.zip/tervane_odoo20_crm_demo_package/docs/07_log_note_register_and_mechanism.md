# 7. Log-note register and posting mechanism

## 7.1 What has to appear where

40 internal notes ("Log note" in the chatter) and 21 planned activities, on the records below. Full text, one row per item: `generated/log_note_register.csv` (the importable version is `import/90_demo_story_items.csv`, same content).

| Story | Opportunity / record | Notes | What a viewer reads |
|---|---|---|---|
| A | Valcrest Belgium - warehousing, bagging and plant shuttle (Antwerp) | A-01 to A-09, A-12 (10) | Operations signal → qualification in five fields → feasibility request → feasible with conditions → Finance/IT input → proposal v1 → negotiation, v2 → won, Expansion, TCV → detailed handover issued → live, next QBR |
| A | Task HO-A Valcrest Belgium (Warehousing handover project) | A-10, A-11 | Handover content (contacts, volumes, KPIs, open points) → accepted by Lotte Verhaegen |
| B | Contact Marlowe Feed Ingredients NV | B-01, B-02 | Selected as target account (no lead) → first contact (still no lead) |
| B | Marlowe - dedicated food-grade tankers Ghent | B-03 to B-07 | Concrete signal → lead → qualified → feasible → proposal → won, New business |
| B | Task HO-B Marlowe | B-08, B-09 | Simple handover → accepted by Pieter Vandaele |
| C | Kordis Circular - Duisburg plant transport (2025 bid), lost | C-01 | Loss reason Price + follow-up: re-engage early for the Ghent plant |
| C | Kordis - integrated logistics, new Ghent pellet plant + Duisburg | C-02 to C-07 | Tender invitation via kept relationship → QHSE permit condition → Operations capacity → Finance terms → offer → best-and-final, 60 % |
| D | Halden - warehousing & bagging renewal 2027-2029 | D-01 to D-03 | Renewal = current scope only (retained) → extra scope logged separately → signed |
| D | Halden - +2,000 pallet positions and export container stuffing | D-04, D-05 | Feasible with conditions → proposal 340,000 incremental |
| X | Contact Valcrest Polymers Belgium NV | X-01 | Operational request that is NOT an opportunity |
| X | Lead "Ops signal: Lumora weekend loading peaks" | X-02 | Operations signal on a lead (used live) |
| X | Valcrest Belgium bulk transport renewal, Ostrava lost renewal, Westbrook (won + task), Nordwerk Duisburg | X-03 to X-07 | No double count, lost retained revenue, awaiting acceptance, signal from GmbH Operations |

## 7.2 Mechanism: module `logistics_crm_demo`, model "Demo Story Items"

* The register rows are ordinary records of model `lg.demo.story.item`, imported from `90_demo_story_items.csv` with the standard import.
* An administrator opens **CRM > Configuration > Demo Story Items** and clicks **Run All Pending** (also available as Actions > Run all pending demo story items after selecting rows). Rows run in story / sequence order.
* For each row the loader:
  1. finds the target with its external ID (`env.ref('__import__.lg_opp_a')`); a missing target sets the row to *Target missing*, nothing is posted;
  2. **note**: calls the public API `record.message_post(body=..., message_type='comment', subtype_xmlid='mail.mt_note')`. That is what the chatter's *Log note* button does (checked in the Odoo 20 composer source: same message type and subtype). No mentions, so nobody is notified and no e-mail is created;
  3. **activity**: `record.activity_schedule(...)` with deadline = run date + N days, assignee from the register, without the "assigned to you" e-mail;
  4. **confirm_order**: `sale.order.action_confirm()` for won proposals;
  5. stores the message / activity, the run time and the user on the row and sets it to *Done*.
* Nothing is written to `mail_message` directly, no timestamp or author is set, no SQL is used.

## 7.3 What the chatter visibly shows (by design)

| Element | Shows | Why |
|---|---|---|
| Author | The user who ran the loader (e.g. "Administrator" or a user named "Demo Story Loader") | Authors are not forged |
| Time | The moment of the run | Timestamps are not backdated |
| First line | **Business date: 04 Mar 2026** · Role: Transport Operations Manager, Tervane Transport NV (fictional: Pieter Vandaele) | Gives the story order and the role honestly |
| Body | The note text, then **Decision / next step:** ... | |
| Footer (small, italic) | `[demo-note A-01]` Demo story note loaded by the demo package. The author and time shown by Odoo are the user who ran the loader and the moment it ran; the business date and role above are fictional. | Transparency, and the marker used against duplicates |

Order: notes are posted in register order, so the chatter (newest on top) reads A-12 at the top down to A-01. With the default import setting ("Track changes in chatter" unticked) the import adds no automatic messages, so the story notes stand alone. Automatic messages created later by live actions (stage changes, "Lead → Opportunity", accepted handover) stay visibly different: no business-date line, no footer.

## 7.4 Reruns, duplicates, privacy

* A row in state *Done* is never executed again.
* *Reset Selected to Pending* (list header button) is for an administrator; a reset note row first looks for its marker `[demo-note KEY]` on the target and links the existing message instead of posting a second one. Activities and confirmations are not re-created.
* Re-importing the CSV does not reset states.
* If a posted note was deleted by hand, reset the row and run it: it is posted again (deliberate repair path).
* Access: register menu and run action are restricted to Settings administrators; sales managers can read the register. The register contains only fictional text; no personal data.
* Tested locally: first run 65/65 Done (40 notes, 21 activities, 4 confirmations); second run, run of all rows and reset + run: still 40 notes and 21 activities; every note is type comment + subtype Note, author = loader user, on the right record. Module unit tests check the same on Odoo.sh builds (tests are tagged post_install).

## 7.5 Dependencies and rights

`crm`, `sale_crm`, `project`, `mail` (declared in the manifest). Odoo 20 access model `ir.access` (file `security/ir.access.csv`). Run as an internal user with Settings (administrator) rights who has all three Tervane companies active.

## 7.6 Fallback: precise administrator procedure (if the module cannot be deployed)

Without the module there are no custom fields either, so the demo would be weaker overall (doc 02). For the notes alone:

1. Open `generated/log_note_register.csv`, filter kind = note, sort by story and sequence.
2. For each row open the target record (search its name in CRM, Contacts or Project) and click **Log note** (not *Send message*).
3. Paste: first line `Business date: <date> · Role: <role>`, then the text, then `Decision / next step: <text>`, then `[demo-note <key>] Posted manually from the demo register.`
4. Post in register order. Tick the row in your copy of the register.
5. Verification is the same as S6-S8 in doc 09.

About 40 notes, roughly 45 minutes. The author will be the person posting, the time the posting time, same principle as the loader.

**Status: not live-verified on the target.** The notes count as verified only after smoke tests S6-S8 pass on the Odoo.sh database.

## 7.7 Register

### Story A

| Key | Kind | Target | Role (fictional) | Business date | Text (start) | Decision / next step |
|---|---|---|---|---|---|---|
| A-01 | note | `lg_opp_a` | Transport Operations Manager, Tervane Transport NV (fictional: Pieter Vandaele) | 2026-03-04 | Signal from Operations. Our drivers at the Valcrest Antwerp plant wait 2 to 3 hours per loading because finish... | Pass to the account owner for qualification; no quote yet. |
| A-02 | note | `lg_opp_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-03-09 | Qualified on a call with Isabelle Moreau (Supply Chain Manager, Valcrest Belgium). Need confirmed: 10,000 to 1... | Move to Solution Design. Next action: feasibility review by Warehouse Operations within 10 days. |
| A-03 | note | `lg_opp_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-03-10 | Feasibility requested from Lotte Verhaegen (Warehouse Operations). Questions: free capacity in Hall 3 from 01 ... | Feasibility reviewer set on the opportunity; no quotation before the answer. |
| A-04 | note | `lg_opp_a` | Warehouse Operations Manager, Tervane Warehousing NV (fictional: Lotte Verhaegen) | 2026-03-20 | Feasible with conditions. Hall 3 can hold 11,500 positions from 01 Sep 2026. Bagging line 2 needs a second shi... | Feasibility = feasible with conditions. Conditions go into the proposal. |
| A-05 | note | `lg_opp_a` | Finance Business Partner (fictional: Elif Aydin) | 2026-03-24 | Finance: credit limit for Valcrest Polymers Belgium NV is sufficient for the extra volume. Billing proposal: p... | Commercial structure: one contract with Tervane Warehousing NV as contracting entity. |
| A-06 | note | `lg_opp_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-04-24 | Price calculated in the group costing model (outside Odoo) and approved by Sophie Marchal. Proposal v1 sent: 1... | Stage Proposal. Next action: proposal walkthrough with Valcrest supply chain and procurement. |
| A-07 | note | `lg_opp_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-05-29 | Negotiation: Group Procurement asked for 4 percent off the storage rate. Agreed 2.5 percent in exchange for a ... | Stage Negotiation. Wait for signature; Sophie informed. |
| A-08 | note | `lg_opp_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-06-19 | Valcrest Belgium signed. Won. Revenue type: Expansion, because the Valcrest group has been a customer since 20... | Create a detailed handover for Warehouse Operations. Ruben stays commercial owner until acceptance. |
| A-09 | note | `lg_opp_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-06-22 | Detailed handover created as task 'HO-A Valcrest Belgium' in the Warehousing handover project, with six workst... | Handover status: awaiting Operations acceptance (at that business date). |
| A-10 | note | `lg_task_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-06-22 | Handover content. Customer contacts: Isabelle Moreau (supply chain), Koen Lambrechts (plant logistics). Volume... | Operations to confirm the open points and accept. |
| A-11 | note | `lg_task_a` | Warehouse Operations Manager, Tervane Warehousing NV (fictional: Lotte Verhaegen) | 2026-07-03 | Handover accepted. Open points closed: second shift recruited, plant confirmed the 06:00 to 22:00 loading wind... | Accepted by Lotte Verhaegen. Stage moves on to Onboarding / Live. |
| A-12 | note | `lg_opp_a` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-10-20 | Live since 01 Sep 2026. First quarterly review to prepare with the Valcrest group: storage needs at the Koeln ... | Next action: quarterly business review with the Valcrest group. |
| A-13 | activity | `lg_opp_a` |  |  | ACTIVITY: Quarterly business review with Valcrest group (assignee ruben, due run date +21 days). Prepare QBR: ... |  |
| A-20 | confirm_order | `lg_so_a` |  |  | CONFIRM QUOTATION with the standard action_confirm() |  |

### Story B

| Key | Kind | Target | Role (fictional) | Business date | Text (start) | Decision / next step |
|---|---|---|---|---|---|---|
| B-01 | note | `lg_p_marlowe` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-01-12 | Selected as a Food & Feed target account: certified feed-ingredient producer in Ghent, fits our food-grade tan... | Target account with owner Amira; first outreach within a month. |
| B-02 | note | `lg_p_marlowe` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-02-05 | First contact with Elise Vandenberghe (Logistics Manager) at a feed industry event. Current carrier performs w... | First contact date set. Follow up in the spring. |
| B-03 | note | `lg_opp_b` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-03-17 | Concrete signal: Marlowe's current carrier withdraws two food-grade tankers from the Ghent region from 01 Jul ... | Qualify within a week. |
| B-04 | note | `lg_opp_b` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-03-25 | Qualified and converted to an opportunity: 2 dedicated food-grade tankers, about 1,900 loads a year from Ghent... | Next action: tank availability and cleaning check with Transport Operations and QHSE. |
| B-05 | note | `lg_opp_b` | Transport Operations Manager, Tervane Transport NV (fictional: Pieter Vandaele) | 2026-04-08 | Feasible. Two tankers can be freed from the spot pool from 15 Jun 2026. QHSE confirmed the Ghent cleaning stat... | Feasibility = feasible. Price can be calculated. |
| B-06 | note | `lg_opp_b` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-04-28 | Proposal sent: 620,000 EUR expected annual revenue, 24 months. Price from the costing model; quotation in Odoo... | Follow-up call in two weeks. |
| B-07 | note | `lg_opp_b` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-05-27 | Marlowe signed. Won. Revenue type: New business (first contract with this customer). Simple handover to Transp... | Handover to Pieter Vandaele; Amira stays owner until accepted. |
| B-08 | note | `lg_task_b` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-05-28 | Simple handover. Contacts: Elise Vandenberghe. Volumes: about 1,900 loads a year, 2 dedicated tankers. Require... | Transport Operations to accept. |
| B-09 | note | `lg_task_b` | Transport Operations Manager, Tervane Transport NV (fictional: Pieter Vandaele) | 2026-06-05 | Handover accepted. Tankers and drivers assigned, cleaning schedule set with the Ghent station. | Accepted by Pieter Vandaele. |
| B-10 | activity | `lg_opp_b` |  |  | ACTIVITY: First KPI review with Marlowe (assignee amira, due run date +35 days). Loads, on-time rate and clean... |  |
| B-20 | confirm_order | `lg_so_b` |  |  | CONFIRM QUOTATION with the standard action_confirm() |  |

### Story C

| Key | Kind | Target | Role (fictional) | Business date | Text (start) | Decision / next step |
|---|---|---|---|---|---|---|
| C-01 | note | `lg_opp_cprev` | Key Account Manager Germany & CEE (fictional: Jonas Kessler) | 2025-04-29 | Lost to the incumbent on price (about 7 percent below our offer). Customer feedback: our service model scored ... | Lost reason Price. Follow-up: keep the relationship, watch the Ghent tender. |
| C-02 | note | `lg_opp_c` | Key Account Manager Germany & CEE (fictional: Jonas Kessler) | 2025-12-03 | Kordis invited us to the tender for integrated logistics of the new Ghent pellet plant plus the Duisburg plant... | Strategic opportunity owned by Sophie Marchal; Jonas stays involved for Duisburg. |
| C-03 | note | `lg_opp_c` | QHSE Manager (fictional: Thomas Wouters) | 2026-02-11 | QHSE: storing plastic bales counts as waste storage. Hall 5 needs a check of the environmental permit, sprinkl... | Permit check is a condition of the offer. |
| C-04 | note | `lg_opp_c` | Warehouse Operations Manager, Tervane Warehousing NV (fictional: Lotte Verhaegen) | 2026-02-19 | Warehouse Operations: Hall 5 capacity fits the ramp-up from 01 Jul 2027. Shuttle Ghent to Beveren by Transport... | Feasibility = feasible with conditions. |
| C-05 | note | `lg_opp_c` | Finance Business Partner (fictional: Elif Aydin) | 2026-03-05 | Finance: Kordis asks for 60-day payment terms. Maximum 45 days; credit insurance covers up to 1.2 M EUR. | Payment terms 45 days in the offer. |
| C-06 | note | `lg_opp_c` | Commercial Director (fictional: Sophie Marchal) | 2026-06-12 | Offer submitted: 3.4 M EUR expected annual revenue, 60 months, price from the group costing model. | Wait for the shortlist. |
| C-07 | note | `lg_opp_c` | Commercial Director (fictional: Sophie Marchal) | 2026-10-28 | Best and final round. Kordis wants an index clause on diesel and energy and a 5-year term. Our BAFO baseline i... | Next action: commercial validation call on the index clause with Elif (Finance). |
| C-08 | activity | `lg_opp_c` |  |  | ACTIVITY: BAFO call with Kordis procurement: index clause (assignee sophie, due run date +3 days). Agree the d... |  |
| C-09 | activity | `lg_opp_c` |  |  | ACTIVITY: Confirm environmental permit scope for bale storage (Hall 5) (assignee thomas, due run date +10 days... |  |

### Story D

| Key | Kind | Target | Role (fictional) | Business date | Text (start) | Decision / next step |
|---|---|---|---|---|---|---|
| D-01 | note | `lg_opp_d1` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-06-30 | Contract ends 31 Dec 2026. This renewal covers the current scope only: 9,000 pallet positions plus bagging. Cu... | Renewal opportunity created six months before expiry. |
| D-02 | note | `lg_opp_d1` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-09-10 | Halden asked for 2,000 extra positions and export container stuffing from 2027. That is NOT added to the renew... | Separate expansion opportunity created. |
| D-03 | note | `lg_opp_d1` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-10-08 | Renewal signed for 36 months from 01 Jan 2027. Retained annual revenue 1.43 M EUR. No handover needed: scope u... | Won. Account development continues on the expansion opportunity. |
| D-04 | note | `lg_opp_d2` | Warehouse Operations Manager, Tervane Warehousing NV (fictional: Lotte Verhaegen) | 2026-09-24 | Feasible with conditions: 2,000 positions free in Hall 2 from 01 Feb 2027; container stuffing needs one extra ... | Feasibility = feasible with conditions. |
| D-05 | note | `lg_opp_d2` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-10-15 | Proposal sent: 340,000 EUR incremental annual revenue, co-terminating with the renewal. | Follow-up call next week. |
| D-06 | activity | `lg_opp_d2` |  |  | ACTIVITY: Follow up on expansion proposal with Halden (assignee ruben, due run date +6 days). Check decision t... |  |
| D-20 | confirm_order | `lg_so_d1` |  |  | CONFIRM QUOTATION with the standard action_confirm() |  |

### Story X

| Key | Kind | Target | Role (fictional) | Business date | Text (start) | Decision / next step |
|---|---|---|---|---|---|---|
| X-01 | note | `lg_p_valcrest_be` | Transport Operations Manager, Tervane Transport NV (fictional: Pieter Vandaele) | 2026-10-14 | Operational request: extra Saturday pick-ups for two weeks. Handled by planning in the transport system. Not a... | No CRM action. |
| X-02 | note | `lg_lead_l4` | Transport Operations Manager, Tervane Transport NV (fictional: Pieter Vandaele) | 2026-10-20 | Lumora loads peak on Fridays; trucks wait up to 2 hours. They asked whether we can buffer about 400 pallets ov... | Ruben to qualify. |
| X-03 | note | `lg_opp_v6` | Key Account Manager Benelux (fictional: Ruben Daelman) | 2026-08-18 | Renewal of the bulk transport scope only. The warehousing deal won in June is a separate expansion and is not ... | No double counting between renewal and expansion. |
| X-04 | note | `lg_opp_o2` | Key Account Manager Germany & CEE (fictional: Jonas Kessler) | 2026-03-16 | Renewal lost to a competitor with a lower price. Retained revenue lost: 430,000 EUR per year. Account status s... | Lost reason Price. Win-back review in 12 months. |
| X-05 | note | `lg_opp_wb` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-10-13 | Westbrook signed. Won, New business. Simple handover created for Transport Operations; not yet accepted, so Am... | Pieter to accept the handover. |
| X-06 | note | `lg_task_wb` | Business Developer Food & Feed (fictional: Amira Benali) | 2026-10-14 | Simple handover. Contact Ruud Jansen. About 900 silo loads a year from Terneuzen; start 01 Dec 2026. | Transport Operations to accept. |
| X-07 | note | `lg_opp_n3` | Operations Manager, Tervane Logistik GmbH (fictional: Markus Brandt) | 2026-08-26 | Nordwerk export volumes through Duisburg are growing; they store in third-party sheds. Possible warehousing op... | Jonas to qualify; feasibility needed on Duisburg capacity. |
| X-10 | activity | `lg_opp_v6` |  |  | ACTIVITY: Send final renewal contract for signature (assignee ruben, due run date +4 days).  |  |
| X-11 | activity | `lg_opp_n3` |  |  | ACTIVITY: Feasibility: Duisburg hall capacity from Q2 (assignee markus, due run date +7 days).  |  |
| X-12 | activity | `lg_opp_au2` |  |  | ACTIVITY: Proposal walkthrough with Aurelia (assignee camille, due run date +8 days).  |  |
| X-13 | activity | `lg_opp_g3` |  |  | ACTIVITY: Negotiate tank-cleaning surcharge with Grainfield (assignee amira, due run date +2 days).  |  |
| X-14 | activity | `lg_opp_bk3` |  |  | ACTIVITY: Call Bakeline about cross-dock volumes (assignee amira, due run date -9 days).  |  |
| X-15 | activity | `lg_opp_r4` |  |  | ACTIVITY: Check fire-safety limits for bale storage (assignee thomas, due run date +12 days).  |  |
| X-16 | activity | `lg_opp_brevik_ren` |  |  | ACTIVITY: Renewal proposal follow-up with Brevik (assignee ruben, due run date +9 days).  |  |
| X-17 | activity | `lg_opp_greenmill` |  |  | ACTIVITY: Send reference case for bale transport (assignee jonas, due run date +15 days).  |  |
| X-18 | activity | `lg_opp_durand` |  |  | ACTIVITY: Follow-up call on proposal (assignee camille, due run date +5 days).  |  |
| X-19 | activity | `lg_opp_tessaro` |  |  | ACTIVITY: Feasibility: tank availability for feed additives (assignee pieter, due run date +6 days).  |  |
| X-20 | activity | `lg_lead_l1` |  |  | ACTIVITY: Qualification call with Circulex (assignee amira, due run date +3 days).  |  |
| X-21 | activity | `lg_lead_l2` |  |  | ACTIVITY: Qualify domestic volumes with Nordwerk Polska (assignee jonas, due run date +5 days).  |  |
| X-22 | activity | `lg_lead_l4` |  |  | ACTIVITY: Qualify Lumora buffer storage need (assignee ruben, due run date +2 days).  |  |
| X-23 | activity | `lg_lead_l5` |  |  | ACTIVITY: Clarify Grenoble flows with Castellan (assignee camille, due run date +7 days).  |  |
| X-30 | activity | `lg_t_polaris` |  |  | ACTIVITY: First outreach: introduction call (assignee camille, due run date +10 days). Target account selected... |  |
| X-31 | activity | `lg_task_wb` |  |  | ACTIVITY: Review and accept the Westbrook handover (assignee pieter, due run date +2 days).  |  |
| X-40 | confirm_order | `lg_so_wb` |  |  | CONFIRM QUOTATION with the standard action_confirm() |  |
