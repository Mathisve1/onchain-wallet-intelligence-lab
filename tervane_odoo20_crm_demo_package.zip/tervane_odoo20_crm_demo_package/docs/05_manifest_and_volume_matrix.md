# 5. Manifest and volume matrix

Full per-file detail (every column with its type, external-ID pattern, rights, mapping to verify, post-import test) is in `generated/manifest.csv`. The long-format volume matrix is `generated/volume_matrix.csv`.

## 5.1 Import sequence and manifest

| # | File | Model | Records | Purpose | Depends on | Post-import test |
|---|---|---|---|---|---|---|
| 1 | `01_res_company.csv` | `res.company` | 3 | 3 fictional legal entities of the logistics group (EUR) | - | Settings > Companies lists the 3 Tervane companies; admin user has them in Allowed Companies |
| 2 | `02_res_users.csv` | `res.users` | 11 | 11 fictional internal users (Sales, Operations, Finance, QHSE, IT) | 01 | Users have no e-mail (no invitations); notification = Inbox; GmbH-only users: Jonas, Markus |
| 3 | `03_crm_team.csv` | `crm.team` | 3 | 3 sales teams (separate from segments and legal entities) | 01, 02 | CRM > Configuration > Sales Teams shows 3 teams with leaders |
| 4 | `04_crm_stage.csv` | `crm.stage` | 6 | Pipeline stages; renames the 4 default stages and adds Solution Design + Negotiation | CRM installed | Pipeline shows New, Qualified, Solution Design, Proposal, Negotiation, Won |
| 5 | `05_crm_lost_reason.csv` | `crm.lost.reason` | 5 | Commercially meaningful loss reasons | - | CRM > Configuration > Lost Reasons |
| 6 | `06_crm_tag.csv` | `crm.tag` | 8 | Service tags (combinations of services on one opportunity) | - | Never sum revenue grouped by tag (many2many double counts) |
| 7 | `07a_res_partner_groups.csv` | `res.partner` | 4 | 4 customer groups (grouping only, not invoicing entities) | 02 (owners) | Contacts filter 'Customer Groups' = 4 |
| 8 | `07b_res_partner_legal.csv` | `res.partner` | 34 | 34 legal customers, prospects and target accounts | 07a, 02 | Valcrest group form lists 3 legal customers; 'Target Accounts Awaiting First Action' = 4 |
| 9 | `07c_res_partner_sites.csv` | `res.partner` | 9 | 9 operational sites (delivery addresses of legal customers) | 07b | Sites appear under their legal customer |
| 10 | `07d_res_partner_contacts.csv` | `res.partner` | 32 | 32 fictional customer contacts (.example e-mail domains) | 07a, 07b | Contact's commercial entity = legal customer, not the group |
| 11 | `08_product_template.csv` | `product.template` | 8 | 8 service products used as proposal lines (annual values) | Sales | Products exist as services, no stock impact |
| 12 | `09_project_project.csv` | `project.project` | 3 | 3 handover projects, one per legal entity | 01 | Project app shows 3 'Operations Handover' projects |
| 13 | `10_project_task_type.csv` | `project.task.type` | 4 | Handover stages (To Accept, Accepted, Onboarding, Live) | 09 | Stages visible in each handover project |
| 14 | `11a_crm_lead_opportunities.csv` | `crm.lead` | 51 | 51 opportunities: 13 open, 26 won, 12 lost (archived) over ~3 business years | 01-07, 03-06 | Pipeline Analysis / Commercial Management totals match doc 10 |
| 15 | `11b_crm_lead_leads.csv` | `crm.lead` | 5 | 5 unqualified leads (type = lead), 2 raised by Operations | 01-07, 03, 06; CRM setting Leads enabled | CRM > Leads lists 5 leads; filter 'Raised by Operations' |
| 16 | `12_sale_order.csv` | `sale.order` | 6 | 6 proposals (quotations) with annual service lines; order_line/id keeps re-import idempotent | 08, 11a | Untaxed totals equal the opportunity's expected annual revenue |
| 17 | `13_project_task.csv` | `project.task` | 6 | 6 handover tasks (simple and detailed) linked to won opportunities | 09, 10, 11a | Opportunity A shows 'Accepted by Operations' |
| 18 | `14_project_subtask.csv` | `project.task` | 6 | 6 workstreams of the detailed handover (story A) | 13 | Task HO-A shows 6 sub-tasks |
| 19 | `90_demo_story_items.csv` | `lg.demo.story.item` | 65 | Register of 40 Log notes, 21 activities, 4 proposal confirmations | All above + module logistics_crm_demo | After 'Run all pending': 65 rows Done, notes visible in chatter |

**Common rules for all files**

* Encoding UTF-8, comma separator, `"` quoting, dates `YYYY-MM-DD`, datetime `YYYY-MM-DD HH:MM:SS`, decimal point `.`.
* Headers are Odoo technical field names. Odoo 20's import screen maps them automatically (checked with Odoo's own preview: every header matched its field). Relations use `field/id` with the external ID of the target record.
* The `id` column is the record's external ID. Odoo stores it as `__import__.<id>`; all IDs start with `lg_` so they cannot collide. Default records are referenced by their module ID (`crm.stage_lead1`, `base.be`, `base.EUR`, `sales_team.group_sale_salesman_all_leads`, ...).
* Import with all three Tervane companies active in the company switcher (otherwise Odoo's company checks refuse records of inactive companies).
* Keep the default import options. Empty cells in these files are intentional and only appear in fields that Odoo does not compute.

## 5.2 Field mappings to verify on the target

| File | Mapping | Why it matters |
|---|---|---|
| 02 | `group_ids/id` | Odoo 20 name of the user groups field (it was `groups_id` before). Enterprise may add more groups; keep these. |
| 04 | `id` = `crm.stage_lead1..4` | Updates (renames) the 4 default stages instead of creating duplicates. If the target already has other stages, check doc 06 item C6. |
| 07a/07b | no `is_company` column | In Odoo 20 "is a company" is computed from the Tax ID and cannot be imported (the import screen would map that header to *Company*). |
| 07b | `lg_customer_group_id/id` | Group link, NOT `parent_id` (doc 03 §3.3). |
| 08 / 12 | products as `product.template`; quotation lines reference them by product code (`order_line/product_id` = `WH-STOR`, ...) | Order lines need product variants; a template external ID is refused there, and in our test setup there was no standalone Product Variants list to import into (the variants action needs a product context). Codes are unique and matched exactly (tested). |
| 11a/11b | split files | Opportunities and leads have different columns. Empty cells in computed fields (e-mail, contact name, stage) would overwrite Odoo's computed values, so each file only contains columns it fills. |
| 12 | `order_line/id` | Line external IDs make a re-import update lines instead of adding new ones. |
| 90 | `target_xmlid` | Must equal `__import__.` + the `id` used in the files above. |

## 5.3 Safe re-import (no duplicates)

* Re-importing any file updates the records with the same external ID; nothing is duplicated. Tested: all files except 02 re-imported on a loaded database, record counts and totals unchanged (`evidence/rerun_counts_before_after.txt`).
* **Do not re-import `02_res_users.csv`** once users exist. Writing the login again makes Odoo 20 queue a "Security Update: Login Changed" message per user (no recipient, but noise). Change users in the UI instead.
* Re-importing `90_demo_story_items.csv` after the loader ran is safe: rows keep their Done state and are not posted again. Text changes in the CSV do not change notes that were already posted.
* Re-import does not delete. To remove a record from the demo, archive or delete it in Odoo, not by leaving it out of the file.

## 5.4 Volume matrix

Business year = decision year for won/lost, signal year for open deals. History covers November 2023 to October 2026 (installation 2 Nov 2026).

**Opportunities by business year and status**

| Business year | Won | Lost | Open | Total |
|---|---|---|---|---|
| 2023 | 2 | 0 | 0 | 2 |
| 2024 | 9 | 4 | 0 | 13 |
| 2025 | 8 | 5 | 1 | 14 |
| 2026 | 7 | 3 | 12 | 22 |

**Opportunities by contracting entity and segment**

| Legal entity | Polyolefins | Food & Feed | Circular Polymers | Total |
|---|---|---|---|---|
| Tervane Transport NV | 13 | 9 | 2 | 24 |
| Tervane Warehousing NV | 11 | 0 | 4 | 15 |
| Tervane Logistik GmbH | 5 | 3 | 4 | 12 |

**Other objects**

| Object | Records | Split |
|---|---|---|
| Leads (type Lead, open) | 5 | 2 raised by Operations, 1 trade-fair contact, 2 customer requests (one is an unassigned web request that is out of scope and should be disqualified) |
| Customer groups | 4 | Valcrest (3 legal customers), Nordwerk (2), Grainfield (2), Kordis (2, prospect) |
| Legal customers / prospects / targets | 34 | 17 customers, 1 former customer, 11 prospects, 5 target accounts (4 awaiting first action) |
| Sites | 9 | delivery addresses |
| Contacts | 32 | `.example` domains only |
| Proposals (quotations) | 6 | 4 confirmed on win (A, B, D1, Westbrook), 2 draft (C, D2) |
| Handover tasks | 6 + 6 workstreams | A detailed (6 sub-tasks), 5 simple; 5 accepted, 1 awaiting (Westbrook) |
| Log notes | 40 | A 12, B 9, C 7, D 5, supporting 7 |
| Activities | 21 | 1 overdue (Bakeline), 1 open opportunity deliberately without next action (Castellan) |

**Why this volume.** Each pipeline stage column has 2-5 cards, each owner has 4-13 deals, every year has wins and losses in each segment, there are renewals won and lost, and every report cell can be traced to a handful of records. No filler records were added to inflate figures.
