| Legal entity | Polyolefins | Food & Feed | Circular Polymers | Total |
|---|---|---|---|---|
| Tervane Transport NV | 13 | 9 | 2 | 24 |
| Tervane Warehousing NV | 11 | 0 | 4 | 15 |
| Tervane Logistik GmbH | 5 | 3 | 4 | 12 |
