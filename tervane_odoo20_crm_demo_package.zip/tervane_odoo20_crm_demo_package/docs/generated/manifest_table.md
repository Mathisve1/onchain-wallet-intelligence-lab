| # | File | Model | Records | Purpose | Depends on | Post-import test |
|---|---|---|---|---|---|---|
| 1 | `01_res_company.csv` | `res.company` | 3 | 3 fictional legal entities of the logistics group (EUR) | - | Settings > Companies lists the 3 Tervane companies; admin user has them in Allowed Companies |
| 2 | `02_res_users.csv` | `res.users` | 11 | 11 fictional internal users (Sales, Operations, Finance, QHSE, IT) | 01 | Users have no e-mail (no invitations); notification = Inbox; GmbH-only users: Jonas, Markus |
| 3 | `03_crm_team.csv` | `crm.team` | 3 | 3 sales teams (separate from segments and legal entities) | 01, 02 | CRM > Configuration > Sales Teams shows 3 teams with leaders |
| 4 | `04_crm_stage.csv` | `crm.stage` | 6 | Pipeline stages; renames the 4 default stages and adds Solution Design + Negotiation | CRM installed | Pipeline shows New, Qualified, Solution Design, Proposal, Negotiation, Won |
| 5 | `05_crm_lost_reason.csv` | `crm.lost.reason` | 5 | Commercially meaningful loss reasons | - | CRM > Configuration > Lost Reasons |
| 6 | `06_crm_tag.csv` | `crm.tag` | 8 | Service tags (combinations of services on one opportunity) | - | Never sum revenue grouped by tag (many2many double counts) |
| 7 | `07a_res_partner_groups.csv` | `res.partner` | 4 | 4 customer groups (grouping only, not invoicing entities) | 02 (owners) | Contacts filter 'Customer Groups' = 4 |
| 8 | `07b_res_partner_legal.csv` | `res.partner` | 34 | 34 legal customers, prospects and target accounts | 07a, 02 | Valcrest group form lists 3 legal customers; 'Target Accounts Awaiting First Action' = 4 |
| 9 | `07c_res_partner_sites.csv` | `res.partner` | 9 | 9 operational sites (delivery addresses of legal customers) | 07b | Sites appear under their legal customer |
| 10 | `07d_res_partner_contacts.csv` | `res.partner` | 32 | 32 fictional customer contacts (.example e-mail domains) | 07a, 07b | Contact's commercial entity = legal customer, not the group |
| 11 | `08_product_template.csv` | `product.template` | 8 | 8 service products used as proposal lines (annual values) | Sales | Products exist as services, no stock impact |
| 12 | `09_project_project.csv` | `project.project` | 3 | 3 handover projects, one per legal entity | 01 | Project app shows 3 'Operations Handover' projects |
| 13 | `10_project_task_type.csv` | `project.task.type` | 4 | Handover stages (To Accept, Accepted, Onboarding, Live) | 09 | Stages visible in each handover project |
| 14 | `11a_crm_lead_opportunities.csv` | `crm.lead` | 51 | 51 opportunities: 13 open, 26 won, 12 lost (archived) over ~3 business years | 01-07, 03-06 | Pipeline Analysis / Commercial Management totals match doc 10 |
| 15 | `11b_crm_lead_leads.csv` | `crm.lead` | 5 | 5 unqualified leads (type = lead), 2 raised by Operations | 01-07, 03, 06; CRM setting Leads enabled | CRM > Leads lists 5 leads; filter 'Raised by Operations' |
| 16 | `12_sale_order.csv` | `sale.order` | 6 | 6 proposals (quotations) with annual service lines; order_line/id keeps re-import idempotent | 08, 11a | Untaxed totals equal the opportunity's expected annual revenue |
| 17 | `13_project_task.csv` | `project.task` | 6 | 6 handover tasks (simple and detailed) linked to won opportunities | 09, 10, 11a | Opportunity A shows 'Accepted by Operations' |
| 18 | `14_project_subtask.csv` | `project.task` | 6 | 6 workstreams of the detailed handover (story A) | 13 | Task HO-A shows 6 sub-tasks |
| 19 | `90_demo_story_items.csv` | `lg.demo.story.item` | 65 | Register of 40 Log notes, 21 activities, 4 proposal confirmations | All above + module logistics_crm_demo | After 'Run all pending': 65 rows Done, notes visible in chatter |
