**Mgmt 1 - Weighted forecast by segment x revenue type (open opportunities, EUR, weighted = annual x probability)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| Circular Polymers | 1,992,000 | 99,000 |  | 2,091,000 |
| Food & Feed | 140,000 | 45,000 | 595,000 | 780,000 |
| Polyolefins | 145,000 | 627,000 | 1,995,000 | 2,767,000 |
| **Total** | 2,277,000 | 771,000 | 2,590,000 | **5,638,000** |

**Mgmt 1 - same records, expected annual revenue (unweighted)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| Circular Polymers | 3,560,000 | 220,000 |  | 3,780,000 |
| Food & Feed | 400,000 | 180,000 | 850,000 | 1,430,000 |
| Polyolefins | 290,000 | 1,620,000 | 2,720,000 | 4,630,000 |
| **Total** | 4,250,000 | 2,020,000 | 3,570,000 | **9,840,000** |

**Mgmt 2 - Weighted forecast by region x revenue type (open, EUR)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| Benelux | 1,920,000 | 314,000 | 2,590,000 | 4,824,000 |
| France | 145,000 | 50,000 |  | 195,000 |
| Germany | 72,000 | 252,000 |  | 324,000 |
| Southern Europe | 140,000 | 155,000 |  | 295,000 |
| **Total** | 2,277,000 | 771,000 | 2,590,000 | **5,638,000** |

**Mgmt 3 - Won expected annual revenue by business decision year x revenue type (EUR)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| 2023 | 1,380,000 | 1,100,000 |  | 2,480,000 |
| 2024 | 3,630,000 | 540,000 | 2,350,000 | 6,520,000 |
| 2025 | 2,420,000 | 520,000 | 1,150,000 | 4,090,000 |
| 2026 | 1,090,000 | 1,850,000 | 3,060,000 | 6,000,000 |
| **Total** | 8,520,000 | 4,010,000 | 6,560,000 | **19,090,000** |

**Mgmt 3 - Won deals count**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| 2023 | 1 | 1 |  | 2 |
| 2024 | 6 | 2 | 1 | 9 |
| 2025 | 5 | 2 | 1 | 8 |
| 2026 | 2 | 1 | 4 | 7 |
| **Total** | 14 | 6 | 6 | **26** |

**Mgmt 3 - Won total contract value by decision year (EUR, never add to annual figures)**

| | TCV | Total |
|---|---|---|
| 2023 | 6,340,000 | 6,340,000 |
| 2024 | 13,870,000 | 13,870,000 |
| 2025 | 9,403,333 | 9,403,333 |
| 2026 | 15,280,000 | 15,280,000 |
| **Total** | 44,893,333 | **44,893,333** |

**Mgmt 4 - Renewals (retained revenue type): won vs lost by decision year (EUR)**

| | Won | Lost | Total |
|---|---|---|---|
| 2024 | 2,350,000 |  | 2,350,000 |
| 2025 | 1,150,000 |  | 1,150,000 |
| 2026 | 3,060,000 | 430,000 | 3,490,000 |
| **Total** | 6,560,000 | 430,000 | **6,990,000** |

**Mgmt 5 - Customer group x contracting entity: open + won with decision since 2025-11-02 (EUR)**

| | Tervane Transport NV | Tervane Warehousing NV | Tervane Logistik GmbH | Total |
|---|---|---|---|---|
| Aurelia Polimeros SL |  | 310,000 |  | 310,000 |
| Bakeline Foods NV | 180,000 |  |  | 180,000 |
| Brevik Masterbatch NV |  | 300,000 |  | 300,000 |
| Castellan Plastiques SA | 250,000 |  |  | 250,000 |
| Durand Compounds SAS | 290,000 |  |  | 290,000 |
| Grainfield Milling Group | 850,000 |  |  | 850,000 |
| Greenmill Recycling GmbH |  |  | 360,000 | 360,000 |
| Halden Polyolefins NV |  | 1,770,000 |  | 1,770,000 |
| Kordis Circular Group |  | 3,200,000 |  | 3,200,000 |
| Lumora Packaging Films NV | 560,000 |  |  | 560,000 |
| Marlowe Feed Ingredients NV | 620,000 |  |  | 620,000 |
| Nordwerk Group |  |  | 720,000 | 720,000 |
| ReForm Polymers BV |  | 860,000 |  | 860,000 |
| Tessaro Feed SpA | 400,000 |  |  | 400,000 |
| Valcrest Polymers Group | 2,850,000 | 1,850,000 | 1,150,000 | 5,850,000 |
| Westbrook Malt BV | 470,000 |  |  | 470,000 |
| **Total** | 6,470,000 | 8,290,000 | 2,230,000 | **16,990,000** |

**Mgmt 6 - Open pipeline expected annual revenue by stage x segment (EUR)**

| | Polyolefins | Food & Feed | Circular Polymers | Total |
|---|---|---|---|---|
| Negotiation | 2,420,000 | 850,000 | 3,200,000 | 6,470,000 |
| Proposal | 1,240,000 |  | 220,000 | 1,460,000 |
| Qualified | 250,000 | 180,000 | 360,000 | 790,000 |
| Solution Design | 720,000 | 400,000 |  | 1,120,000 |
| **Total** | 4,630,000 | 1,430,000 | 3,780,000 | **9,840,000** |

**Mgmt 6 - Open pipeline weighted by stage x segment (EUR)**

| | Polyolefins | Food & Feed | Circular Polymers | Total |
|---|---|---|---|---|
| Negotiation | 1,815,000 | 595,000 | 1,920,000 | 4,330,000 |
| Proposal | 650,000 |  | 99,000 | 749,000 |
| Qualified | 50,000 | 45,000 | 72,000 | 167,000 |
| Solution Design | 252,000 | 140,000 |  | 392,000 |
| **Total** | 2,767,000 | 780,000 | 2,091,000 | **5,638,000** |

**Mgmt 7 - Open pipeline by owner x stage (EUR)**

| | Qualified | Solution Design | Proposal | Negotiation | Total |
|---|---|---|---|---|---|
| Amira Benali | 180,000 |  |  | 850,000 | 1,030,000 |
| Camille Fontaine | 250,000 | 400,000 | 600,000 |  | 1,250,000 |
| Jonas Kessler | 360,000 | 720,000 |  |  | 1,080,000 |
| Ruben Daelman |  |  | 860,000 | 2,420,000 | 3,280,000 |
| Sophie Marchal |  |  |  | 3,200,000 | 3,200,000 |
| **Total** | 790,000 | 1,120,000 | 1,460,000 | 6,470,000 | **9,840,000** |

**Mgmt 8 - Lost expected annual revenue by decision year x lost reason (EUR)**

| | Price - competitor or incumbent lower | Lane or site not covered by our network | Customer postponed or cancelled the project | Customer chose an in-house solution | Total |
|---|---|---|---|---|---|
| 2024 | 1,000,000 | 260,000 | 350,000 |  | 1,610,000 |
| 2025 | 1,560,000 | 600,000 | 410,000 |  | 2,570,000 |
| 2026 | 430,000 | 300,000 |  | 440,000 | 1,170,000 |
| **Total** | 2,990,000 | 1,160,000 | 760,000 | 440,000 | **5,350,000** |

