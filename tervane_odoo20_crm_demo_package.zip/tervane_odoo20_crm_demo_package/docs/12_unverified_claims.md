# 12. Unverified claims

What this package does **not** prove, and what has to be checked on the target before anyone relies on it. "Local" = Odoo 20.0 Community built from the official source (commit 0af7f93, 24 Oct 2026) with CRM, Sales, Project, Contacts, tested on 26 Oct 2026.

## 12.1 Environment (not checked at all)

| # | Claim we cannot make yet | How to verify |
|---|---|---|
| U1 | The module builds and installs on the target Odoo.sh branch | Push, check build log, install (doc 08 §8.1) |
| U2 | The target database is clean (no Odoo demo data, no other CRM / Sales / Project records) | Q1; count records before import |
| U3 | Outgoing mail is neutralised on that branch | Q5; Settings > Technical > Emails after import |
| U4 | 11 extra internal users are acceptable licence-wise | Q4 |
| U5 | Enterprise edition shows the same screens (Enterprise CRM / Sales / Project add or replace views, e.g. forecast, maps, Studio) | Smoke test S1-S12 on the target |
| U6 | Existing configuration on the target (stages, teams, companies, languages, custom fields) does not conflict | Q3, Q7; check for fields starting with `lg_` |
| U7 | Menu labels in the guide match the target UI language and edition | The tested URLs in doc 08 §8.4 work regardless of labels |
| U8 | Module unit tests pass in the Odoo.sh test build | Odoo.sh build log |

## 12.2 Product behaviour checked only locally

| # | Statement in the package | Status |
|---|---|---|
| L1 | All 19 CSV files import through the Odoo 20 Import screen without errors, headers auto-mapped | Local, browser |
| L2 | Re-import (except users) creates no duplicates | Local, server |
| L3 | Log notes are posted as standard internal notes on the right records, in order, once; author = loader user | Local, server + browser |
| L4 | The 8 favourites produce the expected figures in doc 10 | Local, server (all 8) + browser (Mgmt 1, 3, 5) |
| L5 | Multi-company access: GmbH-only user sees only GmbH deals | Local, server + browser for one user. Not tested: project visibility of handover tasks for Operations users, portal / share users |
| L6 | Confirming a quotation raises the opportunity's expected revenue to the quotation total if higher (sale_crm) | Read in Odoo 20 source and observed (no change when equal); the "higher" case was not triggered |
| L7 | Odoo 20 makes the top of the parent chain the commercial entity and derives "is a company" from the Tax ID | Read in Odoo 20 source, confirmed on imported data |
| L8 | Accept Handover, lead conversion and quick create work live | Local, browser |
| L9 | No e-mail is queued by import (with "Track changes in chatter" unticked) or by the loader | Local. Re-importing users does queue "Login Changed" mails |
| L10 | The relative-date filters (`today -60d`, `today -12m`) evaluate in the browser and on the server | Local (Mgmt 5 in browser, stalled filter on server) |

## 12.3 Not tested, illustrative only

Mobile app; Outlook / Microsoft 365 add-in and mail integration; e-mail alias lead capture; quotation PDF layout, online signature and payment; any approval rule; Studio / key-user customisation; spreadsheet dashboards; Odoo AI features; integrations with TMS, WMS, costing or ERP systems; performance at real data volumes; Dutch or other languages; archived-record behaviour in Enterprise reporting.

## 12.4 Official documentation

The Odoo 20.0 user documentation page on import exists (search result: odoo.com/documentation/20.0/applications/essentials/export_import_data.html) but could not be retrieved through our tooling. Version-specific behaviour was therefore checked in the Odoo 20.0 source code and on a running 20.0 instance, which is stronger evidence for Community but says nothing about Enterprise-only modules.

## 12.5 Statements presales must not make without verification

See the list at the end of doc 11. In short: no claims about the target environment, Enterprise, integrations, automatic revenue classification, real history, real authors of notes, or figures that were not reconciled on the target.
