# 10. Search, filter and report definitions with expected results

**Where they live.** Filters and group-bys are added by the module to the standard CRM, Pipeline Analysis, Contacts and Tasks search views (classification CUS: custom view inheritance). The eight management reports are shared favourites (`ir.filters`, no user = everyone) on the module's action **CRM > Reporting > Commercial Management** (pivot, graph, list), CUS. The pivot, graph, grouping and drill-down mechanics are native Odoo. Measures: **Expected Annual Revenue** (native `expected_revenue`, relabelled), **Weighted Annual Revenue** (native `prorated_revenue`, relabelled), **Total Contract Value** (module), Count (native).

**Expected results** below are derived from the package records by `tools/build_docs_tables.py` and were reconciled cell by cell against Odoo's own grouping on the local Odoo 20.0 database (server) and, for Mgmt 1, 3 and 5, in the browser. Preconditions: clean database, all three Tervane companies active, installation on 2 Nov 2026 (relative filters move with the actual date).

## 10.1 Filters

| ID | Business question | Where | Exact condition (domain) | Expected result | Class | Tested |
|---|---|---|---|---|---|---|
| F1 | Which target accounts still wait for a first action? | Contacts > Filters > **Target Accounts Awaiting First Action** | `lg_account_status = target` and `lg_first_contact_date` not set | Fenwick Starch NV, Hexley Compounds GmbH, Polaris Polyolefins Iberia SA, Sunvale Sweeteners BV (Polaris has a planned outreach call, still no contact) | CUS | server + UI |
| F2 | All target accounts | Contacts > Filters > **Target Accounts** | `lg_account_status = target` | F1 + Brightwater Oils & Fats NV (first contact done, no signal yet) | CUS | server |
| F3 | Which opportunities and leads came from Operations? | Pipeline / Leads > Filters > **Raised by Operations** | `lg_signal_source = operations` (+ Open filter for current) | Open: Aurelia export packing, Bakeline cross-dock, Nordwerk Duisburg, ReForm bale storage; leads: Lumora weekend peaks, Nordwerk Polska domestic. Won history incl. story A | CUS | server |
| F4 | Where is Operations input still missing? | Pipeline > Filters > **Feasibility Input Needed** | `lg_feasibility_state in (requested, in_review)` and `won_status = pending` | Bakeline cross-dock, Castellan consignment, Nordwerk Duisburg, Tessaro Feed | CUS | server + UI |
| F5 | Which open deals have no next action? | Pipeline > Filters > **Open, No Next Action** | `type = opportunity`, `won_status = pending`, no activity | Castellan - consignment stock near Lyon | CUS (native activities) | server |
| F6 | Which deals are stalled? | Pipeline > Filters > **Stalled: No Customer Interaction 60+ Days** | open and `lg_last_touch_date < today -60d` (Odoo 20 relative-date syntax) | Bakeline cross-dock, Castellan consignment, Greenmill bale transport (at installation) | CUS | server |
| F7 | Which wins wait for Operations? | Pipeline > Filters > **Won, Awaiting Handover Acceptance**; Tasks > Filters > **Handovers Awaiting Acceptance** | `lg_handover_state = awaiting` / task with opportunity, no parent, no Accepted By | Westbrook Malt - malt silo transport Terneuzen | CUS | server + UI |
| F8 | Split by revenue type | Pipeline and Pipeline Analysis > Filters > **New Business / Expansion / Retained (Renewal)** | `lg_revenue_type = ...` | see reports | CUS | server |
| F9 | Overdue next actions | Pipeline > Activity view (clock icon) | native | Bakeline: "Call Bakeline about cross-dock volumes", 9 days overdue at installation | STD | not separately tested |
| F10 | Lost deals | Pipeline Analysis > Filters > **Lost** (native) | `won_status = lost` and archived | 12 lost opportunities | STD | server |

**Group-bys added:** Segment, Region, Revenue Type, Customer Group, Legal Customer, Decision Year (business). Native group-bys stay available (Salesperson, Sales Team, Stage, Company, Lost Reason, ...). Avoid "Creation Date" and "Closed Date" for history: they are system dates (installation day).

## 10.2 Management reports (shared favourites)

Open **CRM > Reporting > Commercial Management**, then the search panel's **Favorites**. Odoo 20 lists three favourites and puts the rest under **More...**.

| Fav | Business question | Records (domain) | Rows x columns | Measures |
|---|---|---|---|---|
| Mgmt 1 | What is the weighted forecast per segment, and how much is growth vs retention? | open opportunities (`type = opportunity`, `won_status = pending`, active) | Segment x Revenue Type | Weighted, Expected Annual Revenue |
| Mgmt 2 | Same by region | same | Region x Revenue Type | Weighted, Expected |
| Mgmt 3 | What did we win per business year, and of which type? | `won_status = won` | Decision Year (business) x Revenue Type | Expected Annual Revenue, TCV, Count |
| Mgmt 4 | How much existing revenue did we keep? | Retained type, won or lost (incl. archived) | Decision Year x Won/Lost | Expected Annual Revenue, Count |
| Mgmt 5 | What do we do with each customer group, through which entity? | open + won with decision in the last 12 months (`lg_decision_date >= today -12m`) | Customer Group > Legal Customer x Contracting Entity | Expected Annual Revenue, Count |
| Mgmt 6 | Where in the funnel is the open value? | open | Stage x Segment | Expected, Weighted, Count |
| Mgmt 7 | Who owns which open value? | open | Salesperson x Stage | Expected, Weighted, Count |
| Mgmt 8 | Why do we lose? | lost (archived) | Decision Year x Lost Reason | Expected Annual Revenue, Count |

**Reading rules.** Weighted and unweighted are never added. TCV is shown next to annual revenue, never added to it. Mgmt 5 deliberately excludes older wins so a contract and its renewal are not both counted. Service tags are not used as a revenue grouping. Each cell can be clicked to see its records (doc 09 §9.5).

**Multi-entity view and access.** Mgmt 5 shows all entities only when the user has and activates all three companies. A GmbH-only user (Jonas) sees only the GmbH column for Valcrest: 1,150,000, 1 record in this view (tested on the server: he sees 2 of 8 Valcrest deals overall, only GmbH).

**Native alternative without the module's favourites:** CRM > Reporting > Pipeline Analysis, pivot view, Group by > Add Custom Group > Segment / Revenue Type / Decision Date (business). Same numbers, more clicks.

## 10.3 Expected results

**Mgmt 1 - Weighted forecast by segment x revenue type (open opportunities, EUR, weighted = annual x probability)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| Circular Polymers | 1,992,000 | 99,000 |  | 2,091,000 |
| Food & Feed | 140,000 | 45,000 | 595,000 | 780,000 |
| Polyolefins | 145,000 | 627,000 | 1,995,000 | 2,767,000 |
| **Total** | 2,277,000 | 771,000 | 2,590,000 | **5,638,000** |

**Mgmt 1 - same records, expected annual revenue (unweighted)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| Circular Polymers | 3,560,000 | 220,000 |  | 3,780,000 |
| Food & Feed | 400,000 | 180,000 | 850,000 | 1,430,000 |
| Polyolefins | 290,000 | 1,620,000 | 2,720,000 | 4,630,000 |
| **Total** | 4,250,000 | 2,020,000 | 3,570,000 | **9,840,000** |

**Mgmt 2 - Weighted forecast by region x revenue type (open, EUR)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| Benelux | 1,920,000 | 314,000 | 2,590,000 | 4,824,000 |
| France | 145,000 | 50,000 |  | 195,000 |
| Germany | 72,000 | 252,000 |  | 324,000 |
| Southern Europe | 140,000 | 155,000 |  | 295,000 |
| **Total** | 2,277,000 | 771,000 | 2,590,000 | **5,638,000** |

**Mgmt 3 - Won expected annual revenue by business decision year x revenue type (EUR)**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| 2023 | 1,380,000 | 1,100,000 |  | 2,480,000 |
| 2024 | 3,630,000 | 540,000 | 2,350,000 | 6,520,000 |
| 2025 | 2,420,000 | 520,000 | 1,150,000 | 4,090,000 |
| 2026 | 1,090,000 | 1,850,000 | 3,060,000 | 6,000,000 |
| **Total** | 8,520,000 | 4,010,000 | 6,560,000 | **19,090,000** |

**Mgmt 3 - Won deals count**

| | New business | Expansion | Retained (renewal) | Total |
|---|---|---|---|---|
| 2023 | 1 | 1 |  | 2 |
| 2024 | 6 | 2 | 1 | 9 |
| 2025 | 5 | 2 | 1 | 8 |
| 2026 | 2 | 1 | 4 | 7 |
| **Total** | 14 | 6 | 6 | **26** |

**Mgmt 3 - Won total contract value by decision year (EUR, never add to annual figures)**

| | TCV | Total |
|---|---|---|
| 2023 | 6,340,000 | 6,340,000 |
| 2024 | 13,870,000 | 13,870,000 |
| 2025 | 9,403,333 | 9,403,333 |
| 2026 | 15,280,000 | 15,280,000 |
| **Total** | 44,893,333 | **44,893,333** |

**Mgmt 4 - Renewals (retained revenue type): won vs lost by decision year (EUR)**

| | Won | Lost | Total |
|---|---|---|---|
| 2024 | 2,350,000 |  | 2,350,000 |
| 2025 | 1,150,000 |  | 1,150,000 |
| 2026 | 3,060,000 | 430,000 | 3,490,000 |
| **Total** | 6,560,000 | 430,000 | **6,990,000** |

**Mgmt 5 - Customer group x contracting entity: open + won with decision since 2025-11-02 (EUR)**

| | Tervane Transport NV | Tervane Warehousing NV | Tervane Logistik GmbH | Total |
|---|---|---|---|---|
| Aurelia Polimeros SL |  | 310,000 |  | 310,000 |
| Bakeline Foods NV | 180,000 |  |  | 180,000 |
| Brevik Masterbatch NV |  | 300,000 |  | 300,000 |
| Castellan Plastiques SA | 250,000 |  |  | 250,000 |
| Durand Compounds SAS | 290,000 |  |  | 290,000 |
| Grainfield Milling Group | 850,000 |  |  | 850,000 |
| Greenmill Recycling GmbH |  |  | 360,000 | 360,000 |
| Halden Polyolefins NV |  | 1,770,000 |  | 1,770,000 |
| Kordis Circular Group |  | 3,200,000 |  | 3,200,000 |
| Lumora Packaging Films NV | 560,000 |  |  | 560,000 |
| Marlowe Feed Ingredients NV | 620,000 |  |  | 620,000 |
| Nordwerk Group |  |  | 720,000 | 720,000 |
| ReForm Polymers BV |  | 860,000 |  | 860,000 |
| Tessaro Feed SpA | 400,000 |  |  | 400,000 |
| Valcrest Polymers Group | 2,850,000 | 1,850,000 | 1,150,000 | 5,850,000 |
| Westbrook Malt BV | 470,000 |  |  | 470,000 |
| **Total** | 6,470,000 | 8,290,000 | 2,230,000 | **16,990,000** |

**Mgmt 6 - Open pipeline expected annual revenue by stage x segment (EUR)**

| | Polyolefins | Food & Feed | Circular Polymers | Total |
|---|---|---|---|---|
| Negotiation | 2,420,000 | 850,000 | 3,200,000 | 6,470,000 |
| Proposal | 1,240,000 |  | 220,000 | 1,460,000 |
| Qualified | 250,000 | 180,000 | 360,000 | 790,000 |
| Solution Design | 720,000 | 400,000 |  | 1,120,000 |
| **Total** | 4,630,000 | 1,430,000 | 3,780,000 | **9,840,000** |

**Mgmt 6 - Open pipeline weighted by stage x segment (EUR)**

| | Polyolefins | Food & Feed | Circular Polymers | Total |
|---|---|---|---|---|
| Negotiation | 1,815,000 | 595,000 | 1,920,000 | 4,330,000 |
| Proposal | 650,000 |  | 99,000 | 749,000 |
| Qualified | 50,000 | 45,000 | 72,000 | 167,000 |
| Solution Design | 252,000 | 140,000 |  | 392,000 |
| **Total** | 2,767,000 | 780,000 | 2,091,000 | **5,638,000** |

**Mgmt 7 - Open pipeline by owner x stage (EUR)**

| | Qualified | Solution Design | Proposal | Negotiation | Total |
|---|---|---|---|---|---|
| Amira Benali | 180,000 |  |  | 850,000 | 1,030,000 |
| Camille Fontaine | 250,000 | 400,000 | 600,000 |  | 1,250,000 |
| Jonas Kessler | 360,000 | 720,000 |  |  | 1,080,000 |
| Ruben Daelman |  |  | 860,000 | 2,420,000 | 3,280,000 |
| Sophie Marchal |  |  |  | 3,200,000 | 3,200,000 |
| **Total** | 790,000 | 1,120,000 | 1,460,000 | 6,470,000 | **9,840,000** |

**Mgmt 8 - Lost expected annual revenue by decision year x lost reason (EUR)**

| | Price - competitor or incumbent lower | Lane or site not covered by our network | Customer postponed or cancelled the project | Customer chose an in-house solution | Total |
|---|---|---|---|---|---|
| 2024 | 1,000,000 | 260,000 | 350,000 |  | 1,610,000 |
| 2025 | 1,560,000 | 600,000 | 410,000 |  | 2,570,000 |
| 2026 | 430,000 | 300,000 |  | 440,000 | 1,170,000 |
| **Total** | 2,990,000 | 1,160,000 | 760,000 | 440,000 | **5,350,000** |

## 10.4 Screenshots to capture on the target (after smoke test)

1. Story A opportunity: header + Commercial Journey tab + chatter top (doc 09 S2-S6).
2. Task HO-A with sub-tasks and acceptance note.
3. Mgmt 1 pivot with the 5,638,000 total.
4. Mgmt 3 pivot (won by year x type) with 19,090,000 total.
5. Mgmt 5 pivot with the Valcrest group row expanded.
6. Pipeline with filter Feasibility Input Needed.
7. Contacts with filter Target Accounts Awaiting First Action.
8. A GmbH-only user's pipeline searched on "Valcrest".

Reference screenshots from the local test are in `evidence/` (file names 01-14).

## 10.5 Second iteration (not needed for the first demo)

Spreadsheet dashboard combining Mgmt 1, 3 and 4; retention rate as a computed figure instead of a manual division; forecast by expected closing quarter; renewal calendar from contract end dates; Dutch-language data.
