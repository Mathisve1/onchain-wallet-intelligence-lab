# 9. Validation and smoke tests

Three layers: file-level checks (no Odoo needed), post-import checks (need the database), and the presales smoke test (15 minutes, by a person, on the target before every client demo).

Everything below marked "local result" ran on Odoo 20.0 Community built from source, not on the target Odoo.sh environment.

## 9.1 File-level validation (before import)

`python3 tools/validate_files.py import` (standard library only). Local result: no problems (`evidence/file_validation.txt`).

| Check | Rule |
|---|---|
| V1 Unique IDs | No duplicate external ID in or across files |
| V2 References | Every `.../id` value exists in the package or is a standard Odoo ID (`base.`, `crm.`, `sales_team.`, `project.`, `mail.`) |
| V3 Product codes | Every quotation line code exists in 08 |
| V4 Quotation = deal | Sum of annual lines = opportunity expected annual revenue (6 of 6) |
| V5 Register | Every note/activity target and assignee exists in the package |
| V6 Fictional data | Only `.example` e-mail domains, no phone numbers, no Tax IDs |
| V7 Deal consistency | Won = 100 %, lost = 0 % with a reason, open between 0 and 100 %, open deals have no decision date, every deal has segment, region, revenue type |

## 9.2 Post-import checks (server side)

`tools/odoo_verify.py` (run with `odoo-bin shell`). Local result: **49 of 49 passed** (`evidence/verify_report.json`); on the database imported through the browser 44 of 44 (loader already run with the button, so the loader-run checks are replaced by "65 rows done").

| Area | Checks |
|---|---|
| Records | 56 crm.lead records with the expected type, company, stage, won/lost status, probability, revenue, owner, revenue type |
| Customer structure | Legal customer is its own commercial entity; contact → legal customer → group; group lists 3 legal customers; story A shows group, legal customer and site |
| Story A | TCV 5,550,000; delivering entities; originator / owner / reviewer / revenue / accepter all identifiable; detailed handover with 6 sub-tasks |
| Handovers | A accepted, B accepted, Westbrook awaiting, renewal D1 none |
| Dates | System creation dates are the install moment; business decision date separate from Closed Date |
| Targets | 4 target accounts awaiting first action; none of them has a lead |
| Loader | 65/65 done; one note per note row, one activity per activity row; rerun, run-all and reset + rerun create no duplicates |
| Notes | Every note is on its target record, type comment + subtype Note (= Log note), author = the loader user, marker present; story A notes in register order; 10 demo notes on A, other messages carry no marker |
| Proposals | 6 quotations: untaxed totals, states (4 confirmed, 2 draft), link to the opportunity, opportunity revenue unchanged after confirmation |
| Favourites | Mgmt 1-8 recomputed with Odoo's own grouping and compared cell by cell with `tools/expected_results.json` |
| Filters | Feasibility input needed (4), Open with no next action (Castellan only), Raised by Operations (open + leads), Awaiting handover acceptance (Westbrook) |
| Access | GmbH-only user sees 2 of 8 Valcrest deals and not the Warehousing quotation; Transport/Warehousing user sees no GmbH deals; all-company user sees 8; customer partners shared |
| Side effects | No outgoing e-mail queued |

**Re-import test (local result):** all files except 02 imported a second time on the loaded database, then the loader run again: record counts, quotation lines and totals, notes (40) and activities (21) unchanged (`evidence/rerun_counts_before_after.txt`). Re-importing 02 queues "Login Changed" security mails, hence the rule "do not re-import users".

**Module tests:** 4 unit tests (idempotent loader, Run All Pending button, TCV and handover state, group is not the commercial parent) pass on Odoo 20.0 (`evidence/unit_tests.log`).

## 9.3 Browser checks

`tools/ui_import_test.py` imports all 19 files through the Import screen (⋮ > Import > Upload > Test > Import) on an empty database and runs the loader with the **Run All Pending** button: **19 of 19 files imported**, 65 rows done (`evidence/ui_import_results.json`, `evidence/14_ui_loader_done.png`).

`tools/ui_smoke_test.py`: **30 of 30 passed** (`evidence/ui_results.json`, screenshots `evidence/*.png`): story A chatter and Commercial Journey tab values, handover task notes, favourites Mgmt 1, 3, 5 with exact totals, pipeline filter, contacts filter, customer group form, live Accept Handover, live lead conversion, live quick create, GmbH-only user's pipeline.

## 9.4 Presales smoke test on the target (run before every client demo)

Log in as the presenting user with all three Tervane companies ticked. Expected values are for installation on 2 Nov 2026 (regenerated dates do not change amounts).

| # | Step | Expected result | If it fails |
|---|---|---|---|
| S1 | CRM > Pipeline, remove the "My Pipeline" facet | Columns New, Qualified, Solution Design, Proposal, Negotiation, Won; open cards 0 / 3 / 2 / 5 / 3 (13 open opportunities) | Stages not imported (04) |
| S2 | Open "Valcrest Belgium - warehousing, bagging and plant shuttle (Antwerp)" | Won, Expected Annual Revenue 1,850,000, owner Ruben Daelman | Import 11a |
| S3 | Commercial Journey tab of S2 | Segment Polyolefins, Region Benelux, Revenue Type Expansion, Contracting Entity Tervane Warehousing NV, Signal Raised By Pieter Vandaele, Feasibility Reviewer Lotte Verhaegen, TCV 5,550,000, Handover Accepted by Operations / Lotte Verhaegen | Module or import |
| S4 | Smart buttons of S2 | Orders 1 (1,850,000), Handovers 1 | Import 12 / 13 / loader |
| S5 | Planned activity on S2 | "Quarterly business review with Valcrest group" for Ruben | Loader |
| S6 | Chatter of S2 | 10 notes, top one "Business date: 20 Oct 2026", bottom one "Business date: 04 Mar 2026 ... Signal from Operations", each with `[demo-note A-..]` | **Scene not client-ready.** Run the loader; check Demo Story Items states |
| S7 | Task HO-A (Handovers button) | Notes A-10 and A-11, Accepted By Lotte Verhaegen, 6 sub-tasks | Scene 6 not client-ready |
| S8 | Chatter of Marlowe opportunity, Marlowe contact, Kordis (both), Halden renewal + expansion | B-03..B-07, B-01/B-02, C-01, C-02..C-07, D-01..D-03, D-04/D-05 visible | Scenes 7-9 not client-ready |
| S9 | CRM > Reporting > Commercial Management > Favorites > "Mgmt 1 - Weighted forecast by segment x revenue type" | Weighted total **5,638,000**; Polyolefins 2,767,000; Food & Feed 780,000; Circular Polymers 2,091,000 | Companies not all ticked, or extra data in the database |
| S10 | Favorites > More... > "Mgmt 5 - Customer group x contracting entity ..." | Valcrest Polymers Group **5,850,000** (Transport 2,850,000, Warehousing 1,850,000, GmbH 1,150,000) | As S9 |
| S11 | Contacts > Filters > "Target Accounts Awaiting First Action" | Fenwick Starch, Hexley Compounds, Polaris Polyolefins Iberia, Sunvale Sweeteners | Import 07b |
| S12 | Task "HO Westbrook Malt - silo transport" | Button **Accept Handover** visible (do not click during the smoke test) | Import 13 / module |

## 9.5 Reconciliation tests (trace a total to records)

| Test | How | Expected |
|---|---|---|
| R1 | Mgmt 1, click the grand total cell | List of the 13 open opportunities; column Weighted sums to 5,638,000, Expected Annual Revenue to 9,840,000 |
| R2 | Mgmt 3, cell 2026 x Expansion | 1 record: Valcrest Belgium warehousing (story A), 1,850,000 |
| R3 | Mgmt 3, row 2026 x Retained | 4 records: Valcrest Compounds renewal 430,000, Lumora renewal 560,000, ReForm renewal 640,000, Halden renewal 1,430,000 = 3,060,000 |
| R4 | Mgmt 4, 2026 Lost | Ostrava renewal 430,000 (the only lost renewal); 2026 retention by value = 3,060,000 / 3,490,000 = 87.7 % |
| R5 | Mgmt 1, Circular Polymers x New business | Kordis 3,200,000 x 60 % = 1,920,000 + Greenmill 360,000 x 20 % = 72,000 → 1,992,000 |
| R6 | Story D | Halden renewal (Won, Retained 1,430,000) and Halden expansion (Proposal, Expansion 340,000, weighted 170,000) are two records; the renewal amount does not include the expansion |
| R7 | Business vs system date | In the list of R1 add columns "Created on" (all = install day) and "Decision Date (business)" / "Signal Date (business)" (spread over 2023-2026) |

## 9.6 Chatter per story (the Log-note requirement)

| Story | Records | Expected order (top = newest) | Distinct from automatic messages |
|---|---|---|---|
| A | Opportunity A; task HO-A | A-12, A-09 ... A-01; on the task A-11, A-10 | Every demo note starts with a bold Business date line and ends with the `[demo-note]` footer; automatic messages (creation, stage tracking) have neither |
| B | Marlowe contact; Marlowe opportunity; task HO-B | B-02, B-01; B-07 ... B-03; B-09, B-08 | same |
| C | Kordis 2025 bid (Lost filter); Kordis integrated | C-01; C-07 ... C-02 | same |
| D | Halden renewal; Halden expansion | D-03 ... D-01; D-05, D-04 | same |

Rerun check on the target: click Demo Story Items > **Run All Pending** a second time; the notification still reads "65 done, 0 target missing, 0 error" (it counts all Done rows) and the number of notes on story A must stay 10. Visibility check: log in as a GmbH-only user and open a GmbH record with notes (for example "Kordis Circular - Duisburg plant transport (2025 bid)" via the Lost filter): note visible. Open a Warehousing record from a link: access refused.

## 9.7 Privacy check

* All names, companies, addresses, amounts are fictional; e-mail domains end in `.example` (reserved, undeliverable); no phone numbers, no Tax IDs, no bank data.
* Users have no e-mail address; notifications go to the Odoo inbox only.
* No engagement or client information appears in any file.

## 9.8 Evidence index

| File in `evidence/` | Content |
|---|---|
| file_validation.txt | Result of 9.1 |
| import_report.json | Server-side import of 19 files (test run + import), auto-mapping of every header |
| verify_report.json | 49 checks, story A chatter listing |
| verify_report_ui_imported_db.json | 44 checks on the database imported through the browser |
| ui_import_results.json | 19 browser imports, loader run from the menu |
| ui_results.json + 01-14 *.png | 30 browser checks and screenshots |
| rerun_counts_before_after.txt | Record counts before / after re-import |
| unit_tests.log | Module tests |
