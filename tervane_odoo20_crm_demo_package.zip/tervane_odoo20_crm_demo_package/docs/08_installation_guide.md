# 8. Installation guide (Odoo 20 on Odoo.sh)

This is the exact sequence that was run end to end on a local Odoo 20.0 Community database, through the browser (all 19 files via the Import screen, then the loader via its menu). Steps marked **[Odoo.sh: verify]** could not be tested on Odoo.sh itself.

Time: about 60-75 minutes the first time.

## 8.0 Before you start

| Check | How | Blocker if no |
|---|---|---|
| Dedicated database, no Odoo demo data, no other CRM / Sales / Project records | Q1 in doc 01 | Yes |
| Mail neutralised (non-production branch or no outgoing server) | Odoo.sh branch type; Settings > Technical > Outgoing Mail Servers (developer mode) | Yes |
| Installation date | If not 2 Nov 2026: `cd tools && python3 build_docs_tables.py --as-of YYYY-MM-DD` | No (dates age) |
| You are an administrator with access to all companies you create | | Yes |
| English (en_US) active | Settings > Languages | No, but labels in this guide are English |

## 8.1 Deploy the module [Odoo.sh: verify]

1. Copy the folder `module/logistics_crm_demo` into the Odoo.sh project repository of the demo branch (repository root, or the folder your project uses for custom addons).
2. Commit and push to that branch. Odoo.sh builds the branch; open the build log and check there is no error for `logistics_crm_demo`. The module's 4 unit tests (tagged post_install) run in Odoo.sh test builds.
3. In the database: **Apps** > **Update Apps List** > search "Logistics CRM Demo" > **Activate**. This also installs CRM, Sales (sale_crm) and Project if they are missing.
4. **Check:** menu **CRM > Reporting > Commercial Management** and **CRM > Configuration > Demo Story Items** exist.

On Odoo.sh, whether a newly pushed module is installed automatically depends on the branch type; installing it from Apps is always safe.

## 8.2 Pre-import configuration

| Step | Path | Check |
|---|---|---|
| P1 Enable Leads | CRM > Configuration > Settings > tick **Leads** > Save | Menu **CRM > Leads** appears |
| P2 (after file 01) Allowed companies | Your user form: Allowed Companies = the 3 Tervane companies + your own (Odoo added them automatically to the importing admin in our test) | Company switcher (top right) lists them |
| P3 (after file 01) Activate all companies | Company switcher: tick all three Tervane companies (and keep your own) | Switcher shows several companies ticked |

Keep all companies ticked for the rest of the installation and during the management part of the demo. Odoo switches the active company when you open a record of another company; re-tick all if a total looks too low.

## 8.3 How to import one file

1. Open the list view given in the table below.
2. Click **⋮** (Actions, next to the view title) > **Import**.
3. **Upload** the CSV. Keep "Use first row as header" ticked and "Track changes in chatter" **unticked** (Odoo 20 default; this keeps the chatter free of import noise).
4. Check that every column is mapped (the headers are technical field names and map automatically).
5. Click **Test**. Expected: "Everything seems valid." If not, see 8.6.
6. Click **Import**. Expected notification: "N records successfully imported".

## 8.4 File sequence

| # | File | Open this list (menu) | Tested URL | Records | Check right after |
|---|---|---|---|---|---|
| 1 | 01_res_company.csv | Settings > Users & Companies > Companies | `/odoo/action-base.action_res_company_form` | 3 | 3 Tervane companies; then do P2 and P3 |
| 2 | 02_res_users.csv | Settings > Users & Companies > Users | `/odoo/action-base.action_res_users` | 11 | Users without e-mail; Jonas and Markus only GmbH |
| 3 | 03_crm_team.csv | CRM > Configuration > Sales Teams | `/odoo/action-sales_team.crm_team_action_config` | 3 | Germany team has company GmbH |
| 4 | 04_crm_stage.csv | CRM > Configuration > Stages | `/odoo/action-crm.crm_stage_action` | 6 | 6 stages, no duplicate "New" |
| 5 | 05_crm_lost_reason.csv | CRM > Configuration > Lost Reasons | `/odoo/action-crm.crm_lost_reason_action` | 5 | |
| 6 | 06_crm_tag.csv | CRM > Configuration > Tags | `/odoo/action-sales_team.sales_team_crm_tag_action` | 8 | |
| 7 | 07a_res_partner_groups.csv | Contacts (switch to list view) | `/odoo/action-contacts.action_contacts` | 4 | Filter "Customer Groups" = 4 |
| 8 | 07b_res_partner_legal.csv | Contacts | same | 34 | Valcrest group > Account Development tab lists 3 legal customers |
| 9 | 07c_res_partner_sites.csv | Contacts | same | 9 | |
| 10 | 07d_res_partner_contacts.csv | Contacts | same | 32 | |
| 11 | 08_product_template.csv | Sales > Products > Products | `/odoo/action-sale.product_template_action` | 8 | 8 services with codes WH-..., TR-..., VAS |
| 12 | 09_project_project.csv | Project (list view) | `/odoo/action-project.open_view_project_all` | 3 | One project per entity |
| 13 | 10_project_task_type.csv | Project > Configuration > Task Stages (developer mode) | `/odoo/action-project.open_task_type_form` | 4 | "Accepted" has Handover Accepted Stage ticked |
| 14 | 11a_crm_lead_opportunities.csv | CRM > Leads (list) | `/odoo/action-crm.crm_lead_all_leads` | 51 | Commercial Management, Mgmt 1 total 5,638,000 (weighted) |
| 15 | 11b_crm_lead_leads.csv | CRM > Leads | same | 5 | 5 leads |
| 16 | 12_sale_order.csv | Sales > Orders > Quotations | `/odoo/action-sale.action_quotations` | 6 | 6 quotations; untaxed totals = deal values |
| 17 | 13_project_task.csv | Project > tasks list | `/odoo/action-project.action_view_all_task` | 6 | Opportunity A: Handover = Accepted by Operations |
| 18 | 14_project_subtask.csv | same | same | 6 | HO-A has 6 sub-tasks |
| 19 | 90_demo_story_items.csv | CRM > Configuration > Demo Story Items | `/odoo/action-logistics_crm_demo.action_lg_demo_story_item` | 65 | 65 rows Pending |

Menu labels can differ slightly between Community and Enterprise; the URLs were tested on Odoo 20.0 Community (append them to the database URL).

## 8.5 Post the Log notes, activities and proposal confirmations

1. **Decide who runs it.** The runner's name is shown as author of all 40 story notes. Use a recognisable admin user (for example rename one to "Demo Story Loader").
2. All three Tervane companies ticked in the switcher.
3. **CRM > Configuration > Demo Story Items** > button **Run All Pending** (or select rows > Actions > Run all pending demo story items).
4. Expected: notification "Run finished: 65 done, 0 target missing, 0 error." All rows green (Done).
5. If rows are *Target missing*: an import was skipped or an ID changed. Import the missing file, then run again; Done rows are skipped.
6. Check S6-S8 in doc 09 before calling the notes verified.

## 8.6 Errors and how to fix them

| Symptom | Cause | Fix |
|---|---|---|
| Test shows "No matching record found for external id ..." | A previous file was not imported, or the ID was edited | Import the earlier file; never rename `id` values |
| "...company..." or access errors on leads, quotations or tasks | Not all Tervane companies are active, or the importing user lacks them | P2 and P3 |
| A column is not mapped | Odoo version difference or a hidden field | Do not import until resolved; check doc 05 §5.2 |
| Duplicate stage "New" | 04 was imported before CRM created its default stages, or IDs were changed | Delete the duplicate (no deals on it), re-import 04 |
| Many inbox notifications | "Track changes in chatter" was ticked | Harmless; untick it next time |
| Queued e-mails in Settings > Technical > Emails | Users re-imported (login written again) or a user got an e-mail address | Delete the queued mails; do not re-import 02 |
| Loader row in Error | See the row's Log field | Fix the cause, Reset Selected to Pending, run again |

## 8.7 Safe reruns

* Any file except 02 can be imported again: records with the same external ID are updated, nothing is duplicated (tested). Order lines have their own IDs.
* The loader never runs a Done row twice; a reset note row is matched by its marker before posting.
* Re-import does not delete anything.

## 8.8 After each client demo (reset)

| Live action in the script | Reset |
|---|---|
| Quick-created opportunity "LIVE DEMO - ..." | Delete it |
| Lead "Ops signal: Lumora weekend loading peaks" converted | Re-import `11b_crm_lead_leads.csv` (sets type back to Lead) |
| Westbrook handover accepted live | Re-import `13_project_task.csv` (clears Accepted By, stage back to To Accept). The live "Handover accepted" note stays in the chatter as real history; delete it if you want a clean rerun |
| Log notes posted live | Delete them in the chatter |

## 8.9 Removing the demo

Uninstalling the module removes its fields, views and favourites, not the imported business records. For a clean slate, drop the Odoo.sh database or branch.
