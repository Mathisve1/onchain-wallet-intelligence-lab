# 11. Demo script (English)

**Length:** about 55 minutes plus questions (core path 40 minutes: scenes 1-6 and 10).
**Presenters:** P1 = Sales lead (plays Ruben, Amira, Sophie). P2 = Operations / solution lead (plays Pieter, Lotte). P3 (optional) = manager view.
**Golden rule for every scene:** existing strength → today hard to share or transfer → what we do in Odoo → better collaboration or management insight. Do not tour menus.

**Readiness.** Every scene below was run on a local Odoo 20.0 Community copy of the package. On the target Odoo.sh database a scene is **not ready for a client demo** until the smoke tests listed under it pass there (doc 09 §9.4). A fallback never replaces missing Log notes: if the notes are not visible on the record, the scene is not shown.

**Before the client joins (5 min):** log in as the presenting admin user; tick the three Tervane companies in the company switcher; open the Pipeline and remove the "My Pipeline" facet; keep one tab per scene ready if you like. Say upfront: *"All companies, people and figures are fictional. Dates in the story are business dates; Odoo's own timestamps show when we loaded the demo."*

---

## Scene 1 - One group, three entities, one customer view (4 min)

| | |
|---|---|
| Presenter | P1 |
| Strength | Account managers know the Valcrest group well, across countries |
| As-is friction (illustrative) | Each entity keeps its own customer list; nobody sees the group as a whole |
| Records | Contact **Valcrest Polymers Group**; favourite **Mgmt 5** |
| Click path | Contacts > search "Valcrest Polymers Group" > open > tab **Account Development** → three legal customers. Then CRM > Reporting > Commercial Management > Favorites > More... > **Mgmt 5 - Customer group x contracting entity (open + won last 12 months)** > expand Valcrest Polymers Group |
| Visible result | Group with Valcrest Polymers Belgium NV, Valcrest Polymers Deutschland GmbH, Valcrest Compounds BV; revenue 5,850,000 split Transport 2,850,000 / Warehousing 1,850,000 / Logistik GmbH 1,150,000 |
| Say | "Legal entities are companies in Odoo. Segments (Polyolefins, Food & Feed, Circular Polymers) are a classification, and sales teams are a third, separate axis. A customer group is a grouping, not the invoicing party: each legal customer stays its own commercial entity." |
| Benefit | One relationship view across entities, without merging customer accounts |
| Log notes | none in this scene |
| Fallback | If the totals differ: check the company switcher (all three ticked). Otherwise show the group form only and skip the pivot |
| Smoke tests | S10 |

## Scene 2 - Operations spots it, Sales captures it in seconds (6 min)

| | |
|---|---|
| Presenter | P2 (Pieter), then P1 (Ruben) |
| Strength | Drivers and planners see what the customer struggles with |
| As-is friction | The signal ends up in a planning e-mail or a corridor chat |
| Records | Opportunity **Valcrest Belgium - warehousing, bagging and plant shuttle (Antwerp)** (story A); lead **Ops signal: Lumora weekend loading peaks - buffer storage?** |
| Click path | Pipeline > search "Valcrest Belgium - warehousing" > open > scroll the chatter to the bottom → note **A-01** (Business date 04 Mar 2026, Pieter's signal). Then CRM > Leads > Filters > **Raised by Operations** → open the Lumora lead → note **X-02**. **Live:** click **Convert to Opportunity** (with a linked customer Odoo 20 converts directly, no wizard). Set Probability to 10 % by hand and save |
| Live capture variant | Pipeline > "+" on column **New** > title "LIVE DEMO - Valcrest Koeln storage", customer, Expected Annual Revenue 400,000 > **Add**. Then **Log note**: "Signal from Koeln plant: overflow storage at a third party. Ruben to qualify." Delete after the demo |
| Visible result | The signal, who raised it and when, on the opportunity itself; a lead converted in one click |
| Say | "Pieter did not fill in a form. He logged what he saw on the customer's record, and Ruben owns it from there." |
| Benefit | Operational signals become pipeline instead of getting lost |
| Log notes | A-01, X-02 (open); one live note (post) |
| Fallback | If conversion misbehaves, show the lead and its note; do not improvise data entry. Odoo's predictive probability will propose a high value for a converted lead (trained on demo history): always set it manually |
| Smoke tests | S2, S6 |

## Scene 3 - Qualification with five fields and one next action (3 min)

| | |
|---|---|
| Presenter | P1 (Ruben) |
| Strength | Ruben knows within one call whether it is real |
| As-is friction | Long CRM forms nobody completes, so the CRM is empty and the real info is in his notebook |
| Records | Story A, note **A-02** |
| Click path | Story A > chatter note A-02 ("Only five fields filled in Odoo...") > look at the header: customer, title, owner, Expected Annual Revenue, and the planned activity |
| Visible result | Owner Ruben Daelman, revenue, one concrete next action |
| Say | "We ask for five things and one next action. The rest comes when it is useful, not when the form says so." |
| Benefit | Low entry effort, still a manageable pipeline. Filter **Open, No Next Action** shows the one deal without a next step (Castellan) |
| Log notes | A-02 |
| Fallback | Show the filter Open, No Next Action instead |
| Smoke tests | S2, S5, S6 |

## Scene 4 - Solution design before the price: Operations, QHSE, Finance, IT (6 min)

| | |
|---|---|
| Presenter | P2 (Lotte), P1 |
| Strength | Operations knows what is feasible |
| As-is friction | Operations input comes late or by e-mail; quotes promise what the warehouse cannot do |
| Records | Story A notes **A-03, A-04, A-05**; Commercial Journey tab; pipeline filter |
| Click path | Story A > tab **Commercial Journey** → Signal Raised By Pieter Vandaele, Feasibility Reviewer Lotte Verhaegen, Feasibility "Feasible with conditions", Delivering Entities Transport + Warehousing. Chatter: A-03 (request), A-04 (Lotte: Hall 3, second shift, loading window; QHSE fire load), A-05 (Finance credit and billing; IT EDI). Then Pipeline > Filters > **Feasibility Input Needed** → 4 deals still waiting for Operations |
| Visible result | Feasibility status and reviewer on the deal; every discipline's input in one thread |
| Say | "No quotation before Operations says yes, and 'yes with conditions' is a valid answer. The conditions go into the proposal." |
| Benefit | Fewer unworkable quotes, faster internal alignment, visible workload for Operations |
| Log notes | A-03, A-04, A-05 |
| Fallback | none needed beyond the notes; if a filter is missing, use Group By > Feasibility |
| Smoke tests | S3, S6 |

## Scene 5 - Price calculated outside Odoo, decision managed inside (4 min)

| | |
|---|---|
| Presenter | P1 (Ruben, Sophie) |
| Strength | A solid group costing model |
| As-is friction | Versions of proposals in mailboxes; nobody knows which one the customer has |
| Records | Story A notes **A-06, A-07**; smart button **Orders** → **Proposal v2 - warehousing, bagging and shuttle (annual values)** |
| Click path | Chatter A-06 (v1 1.92 M, costing model, approved by Sophie) and A-07 (negotiation, v2 1.85 M). Smart button Orders > open the order: three annual lines (storage 1,180,000, bagging 380,000, shuttle 290,000 delivered by Transport NV) = 1,850,000 |
| Visible result | The commercial outcome and the proposal content, traceable to the opportunity |
| Say | "We are not replacing your costing model. Odoo keeps the outcome: which proposal, which annual value, which conditions." |
| Benefit | One version of the truth for the proposal; management sees the value that was actually offered |
| Do NOT show | Quote approval workflow, e-signature, PDF layout: not configured |
| Log notes | A-06, A-07 |
| Fallback | If the order is missing, stay in the chatter (the amounts are in the notes) and mark scene as not fully ready |
| Smoke tests | S4 |

## Scene 6 - Won, and Operations accepts a detailed handover (6 min)

| | |
|---|---|
| Presenter | P1 then P2 (Lotte) |
| Strength | Operations delivers well once it knows exactly what was sold |
| As-is friction | "Who owns the customer now?" Informal handover, details in a forwarded mail |
| Records | Story A notes **A-08, A-09, A-12**; smart button **Handovers** → task **HO-A Valcrest Belgium - warehousing, bagging & shuttle** with notes **A-10, A-11** and 6 sub-tasks |
| Click path | Chatter A-08 (won, Expansion, TCV 5.55 M), A-09 (handover created). Smart button Handovers > task > tab **Handover**: Commercial Owner Ruben, Accepted By Lotte Verhaegen; chatter A-10 (volumes, KPIs, open points) and A-11 (accepted, go-live); sub-tasks per workstream (layout, second shift, shuttle, EDI, billing, QHSE). Back on the opportunity: Commercial Journey shows **Handover: Accepted by Operations**; A-12 + planned QBR activity |
| Visible result | The moment Operations took ownership, and the commercial owner still visible |
| Say | "Ruben stays responsible until Lotte accepts. After that, Operations owns delivery and Ruben still owns the relationship." |
| Benefit | Clear ownership, no lost details, Finance and IT in the same plan |
| Log notes | A-08, A-09, A-10, A-11, A-12 |
| End-of-story check | Ask the audience: who raised it (Pieter), who owns it (Ruben), next action (QBR), who reviewed feasibility (Lotte), which proposal (v2, 1.85 M), expected annual revenue (1,850,000), who accepted the handover (Lotte). All on screen |
| Fallback | If the task notes are missing the scene is not client-ready |
| Smoke tests | S4, S6, S7 |

## Scene 7 - New Food & Feed customer: target account first, lead only after a signal (6 min)

| | |
|---|---|
| Presenter | P1 (Amira), P2 (Pieter) |
| Strength | Business development picks its targets deliberately |
| As-is friction | Prospect lists in spreadsheets; every name becomes a "lead", so the funnel is noise |
| Records | Contacts filter **Target Accounts Awaiting First Action**; contact **Marlowe Feed Ingredients NV** (notes B-01, B-02); opportunity **Marlowe - dedicated food-grade tankers Ghent** (B-03..B-07); task **HO-B Marlowe** (B-08, B-09); task **HO Westbrook Malt - silo transport** |
| Click path | Contacts > Filters > Target Accounts Awaiting First Action → 4 accounts, no leads. Open Marlowe contact > Account Development tab (target since 12 Jan, first contact 5 Feb) + notes B-01, B-02 ("still no lead"). Open the Marlowe opportunity: B-03 (concrete signal → lead), B-04..B-07 (qualified, feasible, proposal 620,000, won New business). Handovers > HO-B: simple handover B-08, accepted B-09. **Live:** open task HO Westbrook Malt (won in October, awaiting) > click **Accept Handover** as Pieter's stand-in → real-time note "Handover accepted by ..."; opportunity now shows Accepted |
| Visible result | Target account ≠ lead; a simple handover for a simple deal; the acceptance happening live |
| Say | "A name on a list is a target, not a lead. A lead starts when something concrete happens." |
| Benefit | Clean funnel, prospecting effort visible without polluting the forecast |
| Log notes | B-01..B-09 (open); live acceptance note (posted by the button) |
| Fallback | Skip the live click if the button is missing; never claim acceptance without the field and note visible |
| Smoke tests | S8, S11, S12 |

## Scene 8 - Strategic deal in negotiation, learning from a loss (5 min)

| | |
|---|---|
| Presenter | P1 (Sophie), P2 |
| Strength | Long relationships survive a lost bid |
| As-is friction | Loss reasons are "price" in a spreadsheet; the follow-up depends on one person's memory |
| Records | Pipeline (list view) > Filters > **Lost** > **Kordis Circular - Duisburg plant transport (2025 bid)** (C-01); open opportunity **Kordis - integrated logistics, new Ghent pellet plant + Duisburg** (C-02..C-07, activities) |
| Click path | Lost bid: lost reason "Price - competitor or incumbent lower", note C-01 with feedback and the follow-up. Current deal: owner Sophie Marchal, stage Negotiation, probability 60 %, Expected Annual Revenue 3,200,000, weighted 1,920,000, TCV 16,000,000 (60 months); notes C-03 QHSE permit condition, C-04 capacity, C-05 Finance payment terms, C-07 best-and-final; planned activities "BAFO call ... index clause" (Sophie, in 3 days) and "Confirm environmental permit ..." (Thomas) |
| Visible result | Owner, next action, forecast, and how the earlier loss led to this opportunity |
| Say | "The 2025 loss was not the end: the follow-up in the note is why we were invited to this tender." |
| Benefit | Loss analysis that drives action; strategic deals with multidisciplinary conditions in view |
| Log notes | C-01..C-07 |
| Fallback | none |
| Smoke tests | S8 |

## Scene 9 - Renewal and real growth, without double counting (4 min)

| | |
|---|---|
| Presenter | P1 (Ruben) |
| Strength | Long-term customers who renew and grow |
| As-is friction | Renewals and extra volume in one number; growth looks bigger than it is |
| Records | **Halden - warehousing & bagging renewal 2027-2029** (D-01..D-03); **Halden - +2,000 pallet positions and export container stuffing** (D-04, D-05, activity) |
| Click path | Renewal: Won, Revenue Type Retained, 1,430,000 = current scope incl. 3.5 % indexation (D-01); D-02 "not added to the renewal value"; D-03 no handover needed. Expansion: Proposal, Revenue Type Expansion, 340,000, weighted 170,000, follow-up call in 6 days |
| Visible result | Two records, two revenue types, no overlap |
| Say | "Indexation on the same scope is retained revenue. New scope is expansion, in its own opportunity." |
| Benefit | Honest growth figures |
| Log notes | D-01..D-05 |
| Smoke tests | S8 |

## Scene 10 - Manager walkthrough: the numbers add up (8 min)

| | |
|---|---|
| Presenter | P3 or P1 (Sophie) |
| Strength | Management knows the business |
| As-is friction | Pipeline and forecast rebuilt by hand from fragments every month |
| Start | CRM > Reporting > Commercial Management, all three companies ticked |
| Step 1 | Favorites > **Mgmt 1 - Weighted forecast by segment x revenue type** → total weighted **5,638,000** (unweighted 9,840,000): New 2,277,000, Expansion 771,000, Retained 2,590,000; Circular Polymers 2,091,000 driven by Kordis |
| Step 2 | Click the Circular Polymers x New business cell → Kordis (1,920,000 weighted) + Greenmill (72,000). "Every number has records behind it." |
| Step 3 | **Mgmt 2** by region → Benelux 4,824,000 of 5,638,000 weighted |
| Step 4 | **Mgmt 3 - Won by decision year x revenue type** → 2024 6,520,000; 2025 4,090,000; 2026 6,000,000 (of which Expansion 1,850,000 = story A only). TCV in a separate column |
| Step 5 | More... > **Mgmt 4 - Renewals** → 2026: kept 3,060,000, lost 430,000 (Ostrava) → 87.7 % retained by value |
| Step 6 | Add columns "Created on" and "Decision Date (business)" in the list view: "History uses business dates; Odoo's own dates show when we loaded this demo. We never backdate." |
| Step 7 (optional) | Log in as Jonas Kessler (GmbH only) in a private window: pipeline search "Valcrest" → only the two Logistik GmbH deals |
| Benefit | Reliable, explainable management insight without extra data entry |
| Fallback | If a total differs: company switcher; then Demo Story Items / extra records. Do not present figures that do not reconcile |
| Smoke tests | S9, S10 |

## Close (2 min)

What a project would add next (second iteration): dashboards, renewal calendar, automated revenue-type check, approval flow if needed, Outlook / mobile once configured, Dutch-language data.

## Statements presales must NOT make without verification on the target

1. "This runs exactly like this in your Enterprise / Odoo.sh environment." (Tested on Odoo 20.0 Community locally only.)
2. "Odoo replaces your TMS / WMS / costing tool / invoicing." It does not, and nothing here integrates with them.
3. "Outlook / Microsoft 365, the mobile app, e-signature, quote approval, Studio customisation work out of the box." Not configured, not tested.
4. "Odoo calculates the revenue type" or "Odoo prevents double counting automatically." The rules are human discipline supported by fields and filters.
5. "The notes were written by Pieter / Lotte at these dates." They were loaded by the demo package; author and time in Odoo are the loader's.
6. "This environment has three years of real history." It has three years of fictional business dates and is days old.
7. "The predictive probability shows real win chances." It learned from fictional data.
8. "No customisation is needed." The segment, revenue type, signal, feasibility, customer-group, handover and business-date fields come from a small module.
9. "All users can see everything." Access depends on allowed companies; shown for one GmbH-only user.
10. Any figure not reconciled in smoke test S9 / S10.
