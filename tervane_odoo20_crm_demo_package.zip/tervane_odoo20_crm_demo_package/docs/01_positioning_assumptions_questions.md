# 1. Commercial positioning, assumptions and environment questions

## 1.1 Positioning

**Start from the strength.** Tervane's account managers and Operations people know their customers. Odoo does not replace that with a funnel machine; it makes what they already know shareable, so it survives holidays, job changes and handovers.

**Narrative for every scene:** existing strength → today hard to share or transfer → what we do in Odoo → better collaboration or management insight.

| Theme | Illustrative as-is (not a fact about any real company) | What the demo shows in Odoo 20 |
|---|---|---|
| Customer knowledge | Spread over inboxes, prospect spreadsheets, personal notes | One customer group view across three legal entities, chatter per opportunity |
| Signals from Operations | Mentioned in a call or a planning e-mail, then forgotten | Operations raises a lead or a note; "Raised by Operations" filter |
| Qualification | Long forms nobody fills in | Five fields and one next action |
| Solution design | Operations input arrives late or by mail | Feasibility reviewer and status on the opportunity, before the quotation |
| Pricing | Costing spreadsheets | Stays outside Odoo; Odoo holds the commercial outcome and the proposal summary |
| Handover | Informal; unclear when Operations "owns" the customer | Handover task that Operations explicitly accepts; commercial owner stays visible |
| Management | Pipeline rebuilt by hand, renewals and growth mixed | Annual revenue, weighted forecast, revenue type and customer group, reconciled to records |

**Not in scope of the claim:** transport planning, warehouse execution, invoicing and accounting stay in their own systems. The demo illustrates the commercial handover to those systems; it does not replace them.

## 1.2 Assumptions (all fictional, all challengeable)

| # | Assumption | Effect if wrong |
|---|---|---|
| A1 | Three legal entities: Tervane Transport NV (BE), Tervane Warehousing NV (BE), Tervane Logistik GmbH (DE), all EUR | Regenerate companies; leads reference company IDs |
| A2 | Segments Polyolefins, Food & Feed, Circular Polymers are a classification on opportunities and customers, not companies and not sales teams | None for the demo; it is the point being made |
| A3 | Three sales teams cut across segments: Key Accounts West, Key Accounts Germany & CEE, New Business Development | Teams CSV only |
| A4 | Primary financial measure = expected annual revenue, held in Odoo's native "Expected Revenue" field (relabelled "Expected Annual Revenue") | Doc 03 lists the alternative (recurring revenue fields) |
| A5 | Revenue type is set by the account owner using fixed rules (doc 03 §3.5); Odoo does not derive it | Manual discipline; could be automated later |
| A6 | Complex price calculation stays in the group costing model outside Odoo | No pricing engine is shown |
| A7 | A handover is a Project task; Operations accepts it explicitly | If Project is not wanted, fallback = activity + note (doc 02, gap G4) |
| A8 | The demo database is clean and dedicated to this demo | See E1 / Q1 |
| A9 | English is the only active language for this phase | Dutch data is a later phase; nothing is translated now |
| A10 | Business dates are relative to installation on 2 Nov 2026 (regenerate if different) | Use `tools/build_docs_tables.py --as-of` |

## 1.3 Targeted environment questions

Only the facts that block import or a live demo.

| # | Question | Blocks | Default if no answer |
|---|---|---|---|
| Q1 | Which Odoo.sh branch and database do we use, and is it free of Odoo demo data and other CRM / Sales / Project records? | E1: reconciled totals | Ask for a dedicated staging branch on an empty database |
| Q2 | Can we push the module folder `logistics_crm_demo` to that branch's repository (and who reviews it)? | E2 | No fallback for the Log notes as required; see doc 07 §7.6 |
| Q3 | Are CRM, Sales and Project installed or installable? Any other CRM-related custom modules? | E3 | Install them; check for field-name clashes with `lg_` |
| Q4 | Are 11 additional internal demo users acceptable? | E4 | Reduced variant: 4 users (doc 06, item C8) |
| Q5 | Is outgoing mail neutralised on that branch (mail catcher / no outgoing server)? | E5 | Our users have no e-mail address and Inbox notifications, but confirm anyway |
| Q6 | Community or Enterprise? Studio installed? | E6 | Run smoke test S1-S12; Enterprise may change some screens |
| Q7 | Is the multi-company setup ours to create (3 new companies) or must we reuse existing companies? | Import 01 | Create 3 new companies |
| Q8 | Planned installation date | Business dates | 2 Nov 2026; otherwise regenerate |
| Q9 | Who runs the Log-note loader? Its name will show as the author of all story notes | Chatter readability | A dedicated admin user named e.g. "Demo Story Loader" |
