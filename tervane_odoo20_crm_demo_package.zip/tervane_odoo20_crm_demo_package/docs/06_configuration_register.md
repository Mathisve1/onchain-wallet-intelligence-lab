# 6. Manual configuration and non-importable items

Everything that is not an ordinary CSV import. "Provisional" = the exact step depends on the target environment and must be checked there before calling it done.

| # | Item | How it is delivered | Who / rights | Status | Outstanding check on the target |
|---|---|---|---|---|---|
| C1 | Clean Odoo 20 database on Odoo.sh, no Odoo demo data | Odoo.sh branch choice | Odoo.sh project admin | **Provisional** | Q1: which branch; confirm CRM / Sales / Project have no records |
| C2 | Install apps CRM, Sales, Project (Contacts comes with them) | Apps menu, or automatically as dependencies of the module | Administrator | Tested locally | Q3, Q6 (Enterprise adds modules such as crm_enterprise; check screens) |
| C3 | Deploy module `logistics_crm_demo` | Copy folder into the branch repository (root or an addons folder), push, wait for the build, then Apps > Update Apps List > install | Odoo.sh developer + Administrator | **Provisional** | Q2; on Odoo.sh confirm whether the build installs it or you install it in Apps |
| C4 | CRM setting "Leads" | CRM > Configuration > Settings > Leads | Administrator | Tested locally | none |
| C5 | Allowed companies for the person importing and presenting | After file 01: Settings > Users > (your user) > Allowed Companies = 3 Tervane companies + own; then tick all in the company switcher | Administrator | Tested locally (Odoo added new companies to the creating admin automatically) | Check the switcher shows all 3 before importing file 02 |
| C6 | Pipeline stages | CSV 04 renames the 4 default stages (by external ID) and adds 2 | CRM manager | Tested locally | **Provisional** if the target already has stages or pipelines per team; then map instead of rename |
| C7 | Users without e-mail, Inbox notifications | CSV 02 | Administrator | Tested locally (no invitation, no e-mail queued) | Q4 licences; Q5 mail neutralised anyway |
| C8 | Reduced-users variant (if 11 users are not acceptable) | Keep Sophie, Ruben, Pieter, Lotte; map the other owners/roles to them before import (edit CSV 02, 03, 11a, 11b, 13, 14, 90) | Package owner | Not built | Decide after Q4. Notes keep their role text, so the story still reads correctly |
| C9 | Passwords for role tests | Set manually (Settings > Users > Change Password) only for users you log in with | Administrator | Done locally for one user | Never put passwords in files or chat |
| C10 | Shared favourites Mgmt 1-8 | Module data (`ir.filters`), attached to CRM > Reporting > Commercial Management | Module | Tested locally (server + UI) | Favorites menu shows 3, the rest under "More..." |
| C11 | Search filters and group-bys | Module view inheritance on Pipeline, Pipeline Analysis, Leads, Contacts, Tasks | Module | Tested locally | Enterprise view overrides may move them; S10 |
| C12 | Menu CRM > Reporting > Commercial Management | Module action (pivot, graph, list) | Module | Tested locally | Menu visibility for non-managers (CRM reporting menus may be manager-only) |
| C13 | Menu CRM > Configuration > Demo Story Items + server action "Run all pending demo story items" | Module | Administrator only | Tested locally | none |
| C14 | Log notes, activities, proposal confirmations | Import 90, then run the loader (doc 07) | Administrator | Tested locally | Must run on the target; until then the notes are **not live-verified** |
| C15 | Handover stage "Accepted" flag | CSV 10 (`lg_is_accepted_stage`) | Project manager | Tested locally | none |
| C16 | Predictive lead scoring (native) | Left as is; demo probabilities are set manually in the CSV | n/a | Observed locally: Odoo proposes ~99 % for a freshly converted lead, learned from the demo history | Presenter sets probability by hand in live scenes |
| C17 | Native "rotting" (Odoo 20 stage setting "Days to rot") | Left at 0 (off) | CRM manager | Observed locally | Turning it on would mark all deals as rotting a few weeks after install, because system stage dates are the install day |
| C18 | Outgoing mail | Not configured; rely on Odoo.sh neutralisation for non-production branches | Odoo.sh | **Provisional** | Q5; check Settings > Technical > Emails after import for queued mails |
| C19 | Languages | English only (en_US) | Administrator | Tested locally | If the target uses another default language, labels in docs refer to English UI |
| C20 | Outlook / Microsoft 365, mobile app, Odoo AI features | Not configured | n/a | Not tested | Show only as "possible with configuration" |
| C21 | Quote approval, e-signature, PDF layout, document workflow | Not configured | n/a | Not tested | Do not show as working |
| C22 | Dashboards beyond pivot favourites | Not built | n/a | Second iteration | |
| C23 | Attachments (costing files, contracts) | None delivered (no documents in scope) | n/a | n/a | Notes say the costing model was used, no file is shown |
| C24 | Chatter tracking during import | Keep "Track changes in chatter" unticked in the Import screen (Odoo 20 default). Then the import leaves no creation or assignment messages; only the story notes appear | Person importing | Tested locally through the browser | If it was ticked: owners get "You have been assigned..." in their Inbox (no e-mail with our user setup); harmless |
