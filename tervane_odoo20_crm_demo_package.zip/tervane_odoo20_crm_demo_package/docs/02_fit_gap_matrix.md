# 2. Fit-gap matrix

**Classification.** STD = standard with the installed app · CFG = needs configuration · DEP = depends on another app or field · CUS = limited customisation (the demo module `logistics_crm_demo`) · INT = needs an integration · SIM = simulated / illustrative only · UNV = unverified.

**Test status.** "Local 20.0" = tested on Odoo 20.0 Community built from source (server checks and/or headless browser), see doc 09. Nothing is tested on the target Odoo.sh environment or on Enterprise.

| # | Capability needed | How it is covered | Class | Test status | Note / gap |
|---|---|---|---|---|---|
| F1 | Legal entities separate from segments and teams | 3 companies (multi-company), selection field Segment, 3 sales teams | STD + CFG + CUS | Local 20.0 (server + UI) | Segment is a module field (selection) |
| F2 | Customer group → legal customer → site → contact | Partners; link legal customer → group with module field; sites and contacts as children of the legal customer | STD + CUS | Local 20.0 | **Odoo 20 change:** the top of the parent chain becomes the commercial entity, so the group can NOT be the parent of its legal customers (it would become the invoicing entity). See doc 03 §3.3 |
| F3 | Customer group doing business with several entities | Opportunities carry Company (contracting entity) + Delivering Entities; favourite Mgmt 5 | STD + CUS | Local 20.0 (server + UI) | |
| F4 | Shared customer records, company-specific deals | Partners without company (shared); leads, quotations, tasks with company; standard multi-company access rule | STD | Local 20.0 (GmbH-only user tested in UI) | Rule is Odoo 20's `ir.access` restriction `company_id in company_ids + [False]` |
| F5 | Target account ≠ lead | Account Status on contacts (target / prospect / customer / former), first-contact date; lead only after a signal | CUS | Local 20.0 | |
| F6 | Qualification lead ≠ opportunity stage | "Leads" setting (type = lead) + pipeline stages without a stage called "Lead" | STD + CFG | Local 20.0 | Stage names: New, Qualified, Solution Design, Proposal, Negotiation, Won |
| F7 | Low-friction capture | Kanban quick create (name, customer, revenue) or a lead from Operations | STD | Local 20.0 UI | |
| F8 | Operations as signal originator | Signal Source / Signal Raised By / Signal Date fields + Log note + filter "Raised by Operations" | CUS | Local 20.0 | Operations users need CRM "All documents" rights |
| F9 | One concrete next action | Standard activities; filter "Open, No Next Action"; native late-activity filter | STD + CUS | Local 20.0 | |
| F10 | Feasibility before quotation, multidisciplinary input | Feasibility status + reviewer fields, stage "Solution Design", activities for QHSE / Finance / IT, Log notes | STD + CUS | Local 20.0 | No approval workflow; it is a status the reviewer sets |
| F11 | Combined services in one opportunity | Service tags + quotation lines per service | STD | Local 20.0 | Never sum revenue grouped by tag (a deal with 3 tags counts 3 times) |
| F12 | Price calculation outside Odoo | Not in Odoo; outcome entered as annual quotation lines | SIM (process) | n/a | No pricing engine, no costing import |
| F13 | Traceable proposal | Sales quotation linked to the opportunity (sale_crm), annual values, confirmed on win | STD (DEP Sales) | Local 20.0 | **Odoo 20 behaviour:** confirming a quotation raises the opportunity's expected revenue to the quotation's untaxed total if that is higher. Lines must therefore be ANNUAL values, never TCV |
| F14 | Quote approval / document workflow / e-signature | Not configured | GAP (CFG/INT) | Not tested | Do not show as working |
| F15 | Won / lost with meaningful reason and follow-up | Standard won/lost + 5 demo loss reasons + Log note with follow-up | STD + CFG | Local 20.0 | |
| F16 | Commercial owner responsible until Operations accepts | Handover task in Project; "Accept Handover" button records who and when; opportunity shows handover status | DEP Project + CUS | Local 20.0 UI (live click tested) | |
| F17 | Simple and detailed handover | Simple = one task; detailed = task with workstream sub-tasks (6) | STD (Project) | Local 20.0 | |
| F18 | Expected annual revenue | Native Expected Revenue, relabelled "Expected Annual Revenue" | STD + CUS (label) | Local 20.0 UI | Convention, enforced by training, not by Odoo |
| F19 | Probability-weighted forecast | Native prorated revenue, relabelled "Weighted Annual Revenue" | STD | Local 20.0 (reconciled) | Odoo's predictive lead scoring proposes probabilities from history; demo values are set manually |
| F20 | Total contract value | Computed: annual x term / 12 | CUS | Local 20.0 | Reported separately; never added to annual figures |
| F21 | New / expansion / retained | Revenue Type field with written rules | CUS | Local 20.0 (reconciled) | Classification is human; no automatic check |
| F22 | Views by segment, region, revenue type | Pivot + module fields + shared favourites in CRM > Reporting > Commercial Management | STD + CUS | Local 20.0 (server + UI) | Favourites 4-8 sit under "More..." in the Favorites menu |
| F23 | Won / lost / retention / expansion over 3 years | Business decision date field + favourites Mgmt 3, 4, 8 | CUS | Local 20.0 | Native Closed Date = system date (install day) |
| F24 | Business dates distinct from system dates | Separate business-date fields; nothing backdated | CUS | Local 20.0 | Creation dates, stage durations and chatter times all show the install day |
| F25 | Stalled opportunities | Filter on "Last Customer Interaction (business)" older than 60 days | CUS | Local 20.0 | Odoo 20 native "rotting" works on system stage dates, so it cannot show history; left off |
| F26 | Visible Log notes on the right records | Module register + loader using `message_post` (Log note) | CUS | Local 20.0 (server + UI) | Author = user who runs the loader; time = run time (by design) |
| F27 | Mobile use | Odoo mobile app / browser | UNV | Not tested | Illustrative only |
| F28 | Microsoft 365 / Outlook | Outlook add-in / mail integration | INT + UNV | Not tested | Illustrative only |
| F29 | Approval rules, key-user customisation (Studio) | Not configured; Studio is Enterprise | UNV | Not tested | Do not show live |
| F30 | Dashboards beyond pivots | Not built in this iteration | Second iteration | n/a | Core reports are pivots + favourites |
| F31 | TMS / WMS / ERP integration | Out of scope | SIM | n/a | Say "handover to the operational systems", nothing more |

## Gaps and simplest workable variants

| Gap | Simplest variant in this package | What a real project would add |
|---|---|---|
| G1 Revenue type is manual | Rules in doc 03 + filters to spot errors | Automated check on customer history |
| G2 No quote approval | Commercial Director approval written in a Log note (A-06) | Approval flow (configuration or module), only if needed |
| G3 Costing outside Odoo | Annual quotation lines, note says the costing model was used | Attach the costing file or integrate the costing tool |
| G4 Handover needs Project | Project tasks per entity | Without Project: activity "Accept handover" + note on the opportunity |
| G5 Operations users need CRM rights | Operations users get "All documents" in CRM | Lighter capture route (e-mail alias to a leads team), not tested here |
| G6 Note author is the loader user | Role and business date written inside each note | Not solvable honestly; it is the point of not forging history |
