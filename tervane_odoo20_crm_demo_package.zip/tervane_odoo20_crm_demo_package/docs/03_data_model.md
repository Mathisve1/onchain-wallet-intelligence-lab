# 3. Data model and fictional corporate structure

## 3.1 The fictional group

| Legal entity (res.company) | Country | Main services | Handover project |
|---|---|---|---|
| Tervane Transport NV | BE (Antwerpen) | Bulk silo, packed and food-grade tank transport, intermodal | Operations Handover - Tervane Transport NV |
| Tervane Warehousing NV | BE (Beveren) | Warehousing, bagging & packing, container stuffing, value-added handling | Operations Handover - Tervane Warehousing NV |
| Tervane Logistik GmbH | DE (Duisburg) | Transport and warehousing Germany / CEE | Operations Handover - Tervane Logistik GmbH |

**Segments** (field `lg_segment`, on opportunities and customers): Polyolefins, Food & Feed, Circular Polymers. **Regions** (`lg_region`): Benelux, Germany, France, Southern Europe, Central & Eastern Europe. **Sales teams** (crm.team): Key Accounts West (Benelux, France, Southern Europe), Key Accounts Germany & CEE (company GmbH), New Business Development. Three independent axes: an opportunity has one contracting entity, one segment, one team, one region.

**Fictional users and roles**

| User | Role | Companies | CRM rights | In the stories |
|---|---|---|---|---|
| Sophie Marchal | Commercial Director | all 3 | Sales administrator | Owner of strategic story C |
| Ruben Daelman | Key Account Manager Benelux | Transport, Warehousing | All documents | Owner of A and D |
| Camille Fontaine | KAM France & Southern Europe | Transport, Warehousing | All documents | |
| Amira Benali | Business Developer Food & Feed | Transport, Warehousing | All documents | Owner of B |
| Jonas Kessler | KAM Germany & CEE | GmbH only | All documents | Raised C; access test user |
| Pieter Vandaele | Transport Operations Manager | Transport, Warehousing | All documents | Signal of A; accepts B |
| Lotte Verhaegen | Warehouse Operations Manager | Transport, Warehousing | All documents | Feasibility and acceptance of A |
| Markus Brandt | Operations Manager GmbH | GmbH only | All documents | Signals in Germany |
| Elif Aydin | Finance Business Partner | all 3 | All documents | Credit, billing, payment terms |
| Thomas Wouters | QHSE Manager | all 3 | All documents | Fire load, permits, cleaning certificates |
| Nina Hoffmann | IT & EDI Lead | all 3 | All documents | EDI stock report |

All users are created without e-mail address and with Inbox notifications (no invitation or assignment e-mails).

## 3.2 Business concept → Odoo object

| Business concept | Odoo 20 object | Key fields |
|---|---|---|
| Legal entity | `res.company` | name, country, currency EUR |
| Customer group | `res.partner` with Customer Group (parent) = true | Account status, segment, account owner |
| Legal customer / prospect / target account | `res.partner` (top level) | Belongs to Customer Group, Account Status, First Contact (business) |
| Site | `res.partner` child, type Delivery address | parent = legal customer |
| Contact person | `res.partner` child, type Contact | parent = legal customer (or group) |
| Lead (not yet qualified) | `crm.lead` type Lead | signal fields |
| Opportunity | `crm.lead` type Opportunity | stage, owner, team, company, expected annual revenue, probability, `lg_*` fields |
| Service combination | `crm.tag` (service tags) + quotation lines | |
| Proposal | `sale.order` linked by `opportunity_id` | annual lines per service |
| Next action | `mail.activity` | summary, assignee, deadline |
| Journey narrative | `mail.message` Log notes | posted by the loader |
| Handover | `project.task` in the entity's handover project | Opportunity, type, Accepted By, Accepted On, Planned Go-live; sub-tasks for detailed handovers |
| Loss | `crm.lead` archived with lost reason | `crm.lost.reason` |

## 3.3 Customer structure in Odoo 20

Odoo 20 makes **the top of the `parent_id` chain the commercial entity** of every child (it no longer stops at a "company"), and it derives "is a company" from the Tax ID. So if a customer group were the parent of its legal customers, the group would become the invoicing entity for all of them. The package therefore uses:

```
Valcrest Polymers Group                 (customer group: grouping only)
   ^ Belongs to Customer Group (lg_customer_group_id)
   |-- Valcrest Polymers Belgium NV     (legal customer = commercial entity)
   |      |-- Valcrest Antwerp Plant        (site, delivery address)
   |      |-- Isabelle Moreau, Koen Lambrechts (contacts)
   |-- Valcrest Polymers Deutschland GmbH
   |      |-- Valcrest Koeln Plant, Stefan Kraemer
   |-- Valcrest Compounds BV
          |-- Valcrest Venlo Compounding Plant, Marloes de Vries
Group-level contact: Laurent Dubois (Group Procurement), child of the group record
```

A computed field **Customer Group** (`lg_group_id`, stored) resolves every contact, site and legal customer to its group (or to the legal customer itself when there is no group). Opportunities copy it (`lg_customer_group_id`) together with **Legal Customer** (= Odoo's commercial entity). The group form shows "Legal Customers in this Group".

**Tax IDs are left empty on purpose.** A valid-looking fictional VAT number could belong to a real company. Effect: Odoo 20 shows the generic contact avatar instead of the company avatar. Commercial-entity logic is not affected.

Valcrest business by entity: Tervane Transport NV (bulk transport Belgium since 2022, packed transport Venlo), Tervane Logistik GmbH (Koeln transport since 2024), Tervane Warehousing NV (story A, won June 2026).

## 3.4 Fields added by the module `logistics_crm_demo`

| Model | Field | Type | Label | Purpose |
|---|---|---|---|---|
| crm.lead | expected_revenue | (native) | Expected Annual Revenue | Relabelled only |
| crm.lead | prorated_revenue | (native) | Weighted Annual Revenue | Relabelled only |
| crm.lead | lg_segment | selection | Segment | Polyolefins / Food & Feed / Circular Polymers |
| crm.lead | lg_region | selection | Region | 5 regions |
| crm.lead | lg_revenue_type | selection | Revenue Type | New business / Expansion / Retained (renewal) |
| crm.lead | lg_signal_source, lg_signal_user_id, lg_signal_date | selection, many2one user, date | Signal Source / Raised By / Date | Who spotted it, from where, when (business) |
| crm.lead | lg_feasibility_state, lg_feasibility_user_id | selection, many2one user | Feasibility / Feasibility Reviewer | Solution design before the quotation |
| crm.lead | lg_decision_date | date | Decision Date (business) | Won/lost date in the fictional history |
| crm.lead | lg_last_touch_date | date | Last Customer Interaction (business) | Stalled filter |
| crm.lead | lg_contract_start, lg_contract_months | date, integer | Contract Start / Term | |
| crm.lead | lg_tcv | monetary, computed stored | Total Contract Value | annual x months / 12 |
| crm.lead | lg_customer_group_id, lg_legal_customer_id | many2one partner, related stored | Customer Group / Legal Customer | Group reporting |
| crm.lead | lg_site_id | many2one partner | Operational Site | |
| crm.lead | lg_delivering_company_ids | many2many company | Delivering Entities | Who delivers; revenue stays on the contracting entity |
| crm.lead | lg_handover_task_ids, lg_handover_state, lg_handover_accepted_by_id | one2many, computed stored | Handovers / Handover / Accepted By | From the handover task |
| res.partner | lg_account_status | selection | Account Status | target / prospect / customer / former |
| res.partner | lg_segment | selection | Primary Segment | |
| res.partner | lg_is_customer_group, lg_customer_group_id, lg_group_member_ids | boolean, many2one, one2many | Customer group link | See 3.3 |
| res.partner | lg_target_since, lg_first_contact_date | date | Target Since / First Contact (business) | "Awaiting first action" = target without first contact |
| res.partner | lg_group_id | many2one, computed stored recursive | Customer Group | |
| project.task | lg_lead_id, lg_handover_type, lg_accepted_by_id, lg_accepted_date, lg_go_live_date | | Handover fields | + button Accept Handover |
| project.task.type | lg_is_accepted_stage | boolean | Handover Accepted Stage | Target stage of the button |
| lg.demo.story.item | (model) | | Demo Story Items | Log-note / activity register, doc 07 |

## 3.5 Revenue definitions and counting rules

| Measure | Definition | Odoo field |
|---|---|---|
| Expected annual revenue | Revenue in a normal full contract year once ramp-up is done, excl. VAT | `expected_revenue` (relabelled) |
| Probability-weighted forecast | Expected annual revenue x probability | `prorated_revenue` (native, relabelled) |
| Total contract value (TCV) | Expected annual revenue x term in months / 12 | `lg_tcv` |
| New business | First contract with a **customer group** that had no contract with any Tervane entity | `lg_revenue_type = new` |
| Expansion | Incremental annual revenue at an existing customer group: new service, site, legal entity or extra volume | `expansion` |
| Retained (renewal) | Renewal of the existing contracted scope, including price indexation | `retained` |

**Rules that prevent double counting**

1. One opportunity = one scope and one revenue type. A renewal that also adds volume is split: renewal (retained) + separate expansion opportunity (story D: D1 and D2).
2. Revenue type is judged at **customer-group** level: the first contract with Valcrest Deutschland was Expansion, because the Valcrest group was already a customer (record "Valcrest Deutschland - road transport Koeln").
3. Revenue is reported once, on the contracting entity (`company_id`). Delivering entities are informative.
4. Quotation lines carry annual values; the quotation total equals the opportunity's expected annual revenue. (Odoo 20 raises the opportunity revenue to the confirmed quotation total if that is higher.)
5. TCV is never added to annual figures. Weighted and unweighted figures are never added together.
6. Never sum revenue grouped by service tags (many2many: a deal appears under each tag).
7. A view that mixes periods (customer group footprint, Mgmt 5) only counts open deals and deals won in the last 12 months, so a contract and its renewal are not both counted.

## 3.6 Shared versus company-specific records, access

| Record | Company | Visible to |
|---|---|---|
| Customer groups, legal customers, sites, contacts | none (shared) | all internal users |
| Products (service lines) | none (shared) | all |
| Opportunities and leads | contracting entity | users whose active companies include it (Odoo 20 rule `company_id in company_ids + [False]`) |
| Quotations | contracting entity | same |
| Handover tasks | entity of the handover project | same, plus project visibility |
| Sales teams | Germany team = GmbH; others none | |
| Demo story items | none | administrators (read for sales managers) |

Access rules tested locally (doc 09): Jonas (GmbH only) sees 2 of the 8 Valcrest opportunities and cannot open the Warehousing NV quotation; Ruben does not see GmbH deals; Sophie sees all 8 when all companies are active. **To test on the target:** the same three checks, plus project visibility of handover tasks for Operations users.

## 3.7 The journey in Odoo

| Business step | In Odoo | Example |
|---|---|---|
| Target account | Contact with Account Status = Target account; no crm.lead | Sunvale, Polaris, Hexley, Fenwick (awaiting first action), Brightwater (first contact done) |
| Lead | crm.lead type Lead after a concrete signal | 5 open leads, 2 from Operations |
| Qualified opportunity | Converted; stage New → Qualified | |
| Solution design | Stage Solution Design; feasibility reviewer + status | Story A, Nordwerk, Tessaro |
| Proposal | Stage Proposal; quotation with annual lines | Story A v2, Story B, D2 |
| Negotiation | Stage Negotiation | Story C (60 %) |
| Won / lost | Won stage / Lost with reason (archived) | 26 won, 12 lost |
| Operational handover | Project task; Accept Handover | A (detailed), B (simple), Westbrook (awaiting) |
| Account development | Renewal and expansion opportunities, QBR activity | Story D, Valcrest QBR |

## 3.8 History and system dates

* Business history: 51 opportunities with decisions from Nov 2023 to Oct 2026 (2023: 2, 2024: 13, 2025: 14, 2026: 22 incl. open deals), see doc 05.
* All Odoo system dates are real: creation date, Closed Date, stage duration badges and chatter timestamps show the installation moment. Nothing is backdated and no historical e-mail or approval is fabricated.
* History is visible through the business-date fields and the "Business date" line inside each Log note.
* Where the young database shows: "Created on" columns, stage duration badges (e.g. "Won 3m"), chatter times, and the predictive probability hint next to the probability field.
