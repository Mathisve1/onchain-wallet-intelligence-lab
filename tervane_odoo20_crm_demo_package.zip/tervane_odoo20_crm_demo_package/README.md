# Tervane Logistics Group: Odoo 20 CRM demo package

Everything in this package is **fictional**: the Tervane group, its customers, people, amounts and dates. Names were invented for the demo; run a quick name check before using them outside the team.

## Commercial thesis

Tervane wins business through people: account managers who know their customers and Operations colleagues who notice what a customer needs next. That strength stays. What is weak today (illustrative as-is) is that the knowledge sits in inboxes, spreadsheets and heads, so signals get lost, Operations input before a quote is invisible, handovers are informal and management rebuilds the pipeline by hand.

The demo shows Odoo 20 as the shared layer on top of that relationship selling: one customer view across legal entities, a signal captured in seconds, Operations involved before the price, a traceable proposal, a handover that Operations explicitly accepts, and management figures that add up.

**Core demonstration question.** Can an Operations colleague identify an opportunity with an existing customer; can Sales qualify it with little data entry; can the teams jointly develop a feasible solution and proposal; can Operations accept the handover after a win; and can management see its economic value without double counting?

Primary story A answers it on one record: *Valcrest Belgium - warehousing, bagging and plant shuttle (Antwerp)*. At the end a viewer can read, on the opportunity and in its chatter: signal raised by **Pieter Vandaele** (Transport Operations), commercial owner **Ruben Daelman**, next action **quarterly business review**, feasibility reviewer **Lotte Verhaegen**, proposal **Proposal v2 (1,850,000/year)**, expected annual revenue **1,850,000** (TCV 5,550,000, revenue type Expansion) and handover accepted by **Lotte Verhaegen**.

## Critical environment dependencies (blocking for a client demo)

| # | Dependency | Why it blocks | Status |
|---|---|---|---|
| E1 | A clean Odoo 20 database on Odoo.sh **without Odoo demo data** and without other CRM data | Reports would mix other records into the reconciled totals | Unknown, see question Q1 |
| E2 | Permission to deploy the small module `logistics_crm_demo` (Git push to the Odoo.sh branch) | Custom fields, filters, favourites and the Log-note loader come from it | Unknown, Q2 |
| E3 | Apps CRM, Sales and Project installable | Opportunities, proposals and handovers | Unknown, Q3 |
| E4 | 11 extra internal users acceptable (licences) | Owners, Operations roles, access test | Unknown, Q4; fallback described in doc 06 |
| E5 | Outgoing mail neutralised (staging / mail catcher) | Users and assignments must never e-mail anyone | Unknown, Q5 |
| E6 | Enterprise edition behaviour | Everything was tested on **Odoo 20.0 Community** only | Unverified on Enterprise, Q6 |

Nothing else blocks. All files below were built and tested without access to the target environment.

## What was tested, and where

Tested on a local **Odoo 20.0 Community** instance built from the official 20.0 source (commit 0af7f93, 24 Oct 2026), with CRM, Sales, Project and Contacts:

* all 19 CSV files imported from scratch twice: once through the browser Import screen (Upload, Test, Import: 19 of 19), once through the same import engine server-side; 269 records, 0 errors. Re-import of all files except users: no duplicates;
* the module installed, upgraded and its 4 unit tests passed;
* the Log-note loader posted 40 notes and 21 activities, rerun and reset produced no duplicates;
* 49 server-side checks passed (records, chatter, proposals, 8 favourites reconciled to the expected figures, multi-company access, no e-mail), and 44 of 44 on the browser-imported database;
* 30 browser checks passed in headless Chromium (chatter, forms, pivots, filters, live actions, a GmbH-only user's view). Screenshots in `evidence/`.

**Not tested:** the target Odoo.sh environment, Enterprise edition, mobile, Outlook / Microsoft 365, any integration. Until smoke test S1-S12 (doc 09) passes on the target, every scene in the demo script is "not client-ready".

## Package contents

| Deliverable | Where |
|---|---|
| 1 Commercial positioning, assumptions, environment questions | `docs/01_positioning_assumptions_questions.md` |
| 2 Fit-gap matrix | `docs/02_fit_gap_matrix.md` |
| 3 Data model and fictional corporate structure | `docs/03_data_model.md` |
| 4 Import files | `import/*.csv` (19 files) |
| 5 Manifest and volume matrix | `docs/05_manifest_and_volume_matrix.md`, `docs/generated/manifest.csv`, `docs/generated/volume_matrix.csv` |
| 6 Manual-configuration and non-importable items | `docs/06_configuration_register.md` |
| 7 Log-note register and posting mechanism | `docs/07_log_note_register_and_mechanism.md`, `docs/generated/log_note_register.csv`, `module/logistics_crm_demo/` |
| 8 Installation instructions | `docs/08_installation_guide.md` |
| 9 Validation and smoke tests | `docs/09_validation_and_smoke_tests.md`, `evidence/` |
| 10 Search, filter and report definitions with expected results | `docs/10_search_filter_report_definitions.md` |
| 11 Demo script | `docs/11_demo_script.md` |
| 12 Unverified claims and statements not to make | `docs/12_unverified_claims.md` |
| Tools (generator, test harness) | `tools/` |

## Regenerating for a different installation date

Business dates are written relative to **2 November 2026**. If you install on another day, regenerate so the history stays "the last three years" and open deals stay in the future:

```
cd tools
python3 build_docs_tables.py --as-of 2027-01-11
```

This rewrites `import/*.csv`, `tools/expected_results.json` and `docs/generated/*` in one go. Amounts and counts do not change, only the dates (and the date inside the note texts). Python 3.10+ with the standard library only.
