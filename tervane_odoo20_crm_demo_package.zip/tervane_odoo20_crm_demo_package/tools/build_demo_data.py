#!/usr/bin/env python3
"""Build the fictional Tervane Logistics Group demo data package for Odoo 20.

Everything here is FICTIONAL. Company names, people, amounts and dates are
invented for a presales demonstration and describe no real organisation.

Usage:
    python3 build_demo_data.py --out ../import --as-of 2026-11-02

--as-of is the planned installation date. All business dates (signals,
decisions, contract starts, expected closings) are authored relative to
2026-11-02 and shifted by the difference, so the history always covers the
~3 years before installation and open deals stay in the future.
"""
import argparse
import csv
import datetime as dt
import json
import os
from collections import defaultdict

BASE_AS_OF = dt.date(2026, 11, 2)

# ---------------------------------------------------------------------------
# Master data
# ---------------------------------------------------------------------------
COMPANIES = [
    # key, name, street, zip, city, country
    ("tr", "Tervane Transport NV", "Northport Business Park 4", "2030", "Antwerpen", "base.be"),
    ("wh", "Tervane Warehousing NV", "Scheldeweg Logistics Zone 12", "9130", "Beveren-Kruibeke-Zwijndrecht", "base.be"),
    ("de", "Tervane Logistik GmbH", "Hafenpark Ost 7", "47119", "Duisburg", "base.de"),
]
COMPANY_NAME = {c[0]: c[1] for c in COMPANIES}

G_SALES_ALL = "sales_team.group_sale_salesman_all_leads"
G_SALES_MGR = "sales_team.group_sale_manager"
G_PROJECT = "project.group_project_user"
G_MULTI = "base.group_multi_company"
G_USER = "base.group_user"

USERS = [
    # key, name, login, function, default company, companies, groups
    ("sophie", "Sophie Marchal", "sophie.marchal", "Commercial Director", "tr", ["tr", "wh", "de"], [G_USER, G_SALES_MGR, G_PROJECT, G_MULTI]),
    ("ruben", "Ruben Daelman", "ruben.daelman", "Key Account Manager Benelux", "wh", ["tr", "wh"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
    ("camille", "Camille Fontaine", "camille.fontaine", "Key Account Manager France & Southern Europe", "tr", ["tr", "wh"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
    ("amira", "Amira Benali", "amira.benali", "Business Developer Food & Feed", "tr", ["tr", "wh"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
    ("jonas", "Jonas Kessler", "jonas.kessler", "Key Account Manager Germany & CEE", "de", ["de"], [G_USER, G_SALES_ALL, G_PROJECT]),
    ("pieter", "Pieter Vandaele", "pieter.vandaele", "Transport Operations Manager, Tervane Transport NV", "tr", ["tr", "wh"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
    ("lotte", "Lotte Verhaegen", "lotte.verhaegen", "Warehouse Operations Manager, Tervane Warehousing NV", "wh", ["tr", "wh"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
    ("markus", "Markus Brandt", "markus.brandt", "Operations Manager, Tervane Logistik GmbH", "de", ["de"], [G_USER, G_SALES_ALL, G_PROJECT]),
    ("elif", "Elif Aydin", "elif.aydin", "Finance Business Partner", "tr", ["tr", "wh", "de"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
    ("thomas", "Thomas Wouters", "thomas.wouters", "QHSE Manager", "wh", ["tr", "wh", "de"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
    ("nina", "Nina Hoffmann", "nina.hoffmann", "IT & EDI Lead", "tr", ["tr", "wh", "de"], [G_USER, G_SALES_ALL, G_PROJECT, G_MULTI]),
]
USER_NAME = {u[0]: u[1] for u in USERS}
USER_FUNCTION = {u[0]: u[3] for u in USERS}
USER_COMPANIES = {u[0]: u[5] for u in USERS}

TEAMS = [
    # key, name, leader, company, members
    ("kaw", "Key Accounts West (Benelux, France, Southern Europe)", "sophie", "", ["ruben", "camille"]),
    ("kag", "Key Accounts Germany & CEE", "jonas", "de", []),
    ("nbd", "New Business Development", "sophie", "", ["amira"]),
]
TEAM_COMPANY = {t[0]: t[3] for t in TEAMS}

STAGES = [
    # id, name, sequence, is_won, fold, requirements
    ("crm.stage_lead1", "New", 1, False, False, "Genuine opportunity registered with a customer, an owner and one concrete next action."),
    ("crm.stage_lead2", "Qualified", 2, False, False, "Need, scope, timing and decision makers confirmed with the customer."),
    ("lg_stage_solution", "Solution Design", 3, False, False, "Operations (and QHSE / IT / Finance where relevant) assess feasibility BEFORE any quotation."),
    ("crm.stage_lead3", "Proposal", 4, False, False, "Price calculated outside Odoo (costing model); proposal summary held as a quotation."),
    ("lg_stage_negotiation", "Negotiation", 5, False, False, "Commercial validation and negotiation with the customer."),
    ("crm.stage_lead4", "Won", 70, True, False, "Customer decision received. Commercial owner stays responsible until Operations accepts the handover."),
]
STAGE_ID = {"new": "crm.stage_lead1", "qualified": "crm.stage_lead2", "solution": "lg_stage_solution",
            "proposal": "crm.stage_lead3", "negotiation": "lg_stage_negotiation", "won": "crm.stage_lead4"}
STAGE_LABEL = {"new": "New", "qualified": "Qualified", "solution": "Solution Design", "proposal": "Proposal",
               "negotiation": "Negotiation", "won": "Won"}

LOST_REASONS = [
    ("lg_lr_price", "Price - competitor or incumbent lower"),
    ("lg_lr_coverage", "Lane or site not covered by our network"),
    ("lg_lr_postponed", "Customer postponed or cancelled the project"),
    ("lg_lr_inhouse", "Customer chose an in-house solution"),
    ("lg_lr_scope", "Not our core business (disqualified)"),
]
LOST_REASON_NAME = dict(LOST_REASONS)

TAGS = [
    ("lg_tag_bulk", "Bulk road transport", 1),
    ("lg_tag_packed", "Packed road transport", 2),
    ("lg_tag_food", "Food-grade tank transport", 3),
    ("lg_tag_intermodal", "Intermodal", 4),
    ("lg_tag_wh", "Warehousing", 5),
    ("lg_tag_bagging", "Bagging & packing", 6),
    ("lg_tag_stuffing", "Container stuffing", 7),
    ("lg_tag_vas", "Value-added handling", 8),
]

SEGMENT_LABEL = {"polyolefins": "Polyolefins", "food_feed": "Food & Feed", "circular": "Circular Polymers"}
REGION_LABEL = {"benelux": "Benelux", "germany": "Germany", "france": "France",
                "southern_europe": "Southern Europe", "cee": "Central & Eastern Europe"}
RTYPE_LABEL = {"new": "New business", "expansion": "Expansion", "retained": "Retained (renewal)"}

# Customer groups (parents of several legal customers)
GROUPS = [
    # key, name, city, zip, country, status, segment, owner
    ("g_valcrest", "Valcrest Polymers Group", "Brussel", "1000", "base.be", "customer", "polyolefins", "ruben"),
    ("g_nordwerk", "Nordwerk Group", "Marl", "45770", "base.de", "customer", "polyolefins", "jonas"),
    ("g_grainfield", "Grainfield Milling Group", "Rotterdam", "3011", "base.nl", "customer", "food_feed", "amira"),
    ("g_kordis", "Kordis Circular Group", "Gent", "9000", "base.be", "prospect", "circular", "sophie"),
]

# Legal customers / prospects / target accounts (companies). parent = group key or ""
LEGAL = [
    # key, name, parent, city, zip, country, status, segment, owner, target_since, first_contact, email_domain
    ("p_valcrest_be", "Valcrest Polymers Belgium NV", "g_valcrest", "Antwerpen", "2040", "base.be", "customer", "polyolefins", "ruben", "", "", "valcrest.example"),
    ("p_valcrest_de", "Valcrest Polymers Deutschland GmbH", "g_valcrest", "Koeln", "50997", "base.de", "customer", "polyolefins", "jonas", "", "", "valcrest.example"),
    ("p_valcrest_nl", "Valcrest Compounds BV", "g_valcrest", "Venlo", "5928", "base.nl", "customer", "polyolefins", "ruben", "", "", "valcrest.example"),
    ("p_halden", "Halden Polyolefins NV", "", "Antwerpen", "2030", "base.be", "customer", "polyolefins", "ruben", "", "", "halden-poly.example"),
    ("p_nordwerk_de", "Nordwerk Kunststoffe AG", "g_nordwerk", "Marl", "45772", "base.de", "customer", "polyolefins", "jonas", "", "", "nordwerk.example"),
    ("p_nordwerk_pl", "Nordwerk Polska Sp. z o.o.", "g_nordwerk", "Plock", "09-400", "base.pl", "prospect", "polyolefins", "jonas", "", "", "nordwerk.example"),
    ("p_lumora", "Lumora Packaging Films NV", "", "Gent", "9042", "base.be", "customer", "polyolefins", "ruben", "", "", "lumora-films.example"),
    ("p_castellan", "Castellan Plastiques SA", "", "Lyon", "69007", "base.fr", "customer", "polyolefins", "camille", "", "", "castellan.example"),
    ("p_aurelia", "Aurelia Polimeros SL", "", "Tarragona", "43006", "base.es", "customer", "polyolefins", "camille", "", "", "aurelia-pol.example"),
    ("p_brevik", "Brevik Masterbatch NV", "", "Genk", "3600", "base.be", "customer", "polyolefins", "ruben", "", "", "brevik-mb.example"),
    ("p_durand", "Durand Compounds SAS", "", "Rouen", "76000", "base.fr", "prospect", "polyolefins", "camille", "", "2026-08-27", "durand-compounds.example"),
    ("p_kemora", "Kemora Films SA", "", "Valencia", "46024", "base.es", "prospect", "polyolefins", "camille", "", "2024-05-15", "kemora.example"),
    ("p_hoven", "Hoven Resins BV", "", "Moerdijk", "4782", "base.nl", "prospect", "polyolefins", "ruben", "", "2025-07-14", "hoven-resins.example"),
    ("p_fiorenza", "Fiorenza Plast SpA", "", "Bergamo", "24126", "base.it", "prospect", "polyolefins", "camille", "", "2026-03-11", "fiorenza.example"),
    ("p_marlowe", "Marlowe Feed Ingredients NV", "", "Gent", "9000", "base.be", "customer", "food_feed", "amira", "2026-01-12", "2026-02-05", "marlowe-feed.example"),
    ("p_grainfield_nl", "Grainfield Milling BV", "g_grainfield", "Rotterdam", "3089", "base.nl", "customer", "food_feed", "amira", "", "", "grainfield.example"),
    ("p_grainfield_fr", "Grainfield Meunerie SAS", "g_grainfield", "Lille", "59000", "base.fr", "customer", "food_feed", "amira", "", "", "grainfield.example"),
    ("p_bakeline", "Bakeline Foods NV", "", "Kortrijk", "8500", "base.be", "customer", "food_feed", "amira", "", "", "bakeline.example"),
    ("p_pelton", "Pelton Petfood GmbH", "", "Muenster", "48155", "base.de", "customer", "food_feed", "jonas", "", "", "pelton.example"),
    ("p_westbrook", "Westbrook Malt BV", "", "Terneuzen", "4538", "base.nl", "customer", "food_feed", "amira", "2026-03-02", "2026-05-21", "westbrook-malt.example"),
    ("p_tessaro", "Tessaro Feed SpA", "", "Verona", "37135", "base.it", "prospect", "food_feed", "camille", "", "2026-09-16", "tessaro.example"),
    ("p_zellner", "Zellner Getreide GmbH", "", "Mannheim", "68159", "base.de", "prospect", "food_feed", "jonas", "", "2024-09-02", "zellner.example"),
    ("p_kordis_be", "Kordis Recycling NV", "g_kordis", "Gent", "9042", "base.be", "prospect", "circular", "sophie", "", "2025-02-10", "kordis.example"),
    ("p_kordis_de", "Kordis Circular GmbH", "g_kordis", "Duisburg", "47138", "base.de", "prospect", "circular", "jonas", "", "2025-02-10", "kordis.example"),
    ("p_reform", "ReForm Polymers BV", "", "Eindhoven", "5652", "base.nl", "customer", "circular", "ruben", "", "", "reform-polymers.example"),
    ("p_verdant", "Verdant Regrind SAS", "", "Valenciennes", "59300", "base.fr", "customer", "circular", "camille", "", "", "verdant-regrind.example"),
    ("p_ostrava", "Ostrava Polymer Recycling s.r.o.", "", "Ostrava", "70200", "base.cz", "former", "circular", "jonas", "", "", "ostrava-recycling.example"),
    ("p_greenmill", "Greenmill Recycling GmbH", "", "Essen", "45141", "base.de", "prospect", "circular", "jonas", "", "2026-06-11", "greenmill.example"),
    # Target accounts: deliberately selected, NOT leads
    ("t_circulex", "Circulex Polymers BV", "", "Rotterdam", "3197", "base.nl", "prospect", "circular", "amira", "2026-08-03", "2026-09-24", "circulex.example"),
    ("t_brightwater", "Brightwater Oils & Fats NV", "", "Gent", "9000", "base.be", "target", "food_feed", "amira", "2026-06-15", "2026-08-20", "brightwater.example"),
    ("t_sunvale", "Sunvale Sweeteners BV", "", "Roosendaal", "4703", "base.nl", "target", "food_feed", "amira", "2026-09-01", "", "sunvale.example"),
    ("t_polaris", "Polaris Polyolefins Iberia SA", "", "Bilbao", "48001", "base.es", "target", "polyolefins", "camille", "2026-07-01", "", "polaris-iberia.example"),
    ("t_hexley", "Hexley Compounds GmbH", "", "Krefeld", "47829", "base.de", "target", "polyolefins", "jonas", "2026-05-11", "", "hexley.example"),
    ("t_fenwick", "Fenwick Starch NV", "", "Aalst", "9300", "base.be", "target", "food_feed", "amira", "2026-10-05", "", "fenwick-starch.example"),
]

SITES = [
    # key, name, parent legal, city, zip, country
    ("s_valcrest_antwerp", "Valcrest Antwerp Plant", "p_valcrest_be", "Beveren-Kruibeke-Zwijndrecht", "9130", "base.be"),
    ("s_valcrest_koeln", "Valcrest Koeln Plant", "p_valcrest_de", "Koeln", "50997", "base.de"),
    ("s_valcrest_venlo", "Valcrest Venlo Compounding Plant", "p_valcrest_nl", "Venlo", "5928", "base.nl"),
    ("s_halden", "Halden Antwerp Plant", "p_halden", "Antwerpen", "2030", "base.be"),
    ("s_lumora", "Lumora Ghent Film Plant", "p_lumora", "Gent", "9042", "base.be"),
    ("s_marlowe", "Marlowe Ghent Plant", "p_marlowe", "Gent", "9000", "base.be"),
    ("s_kordis_ghent", "Kordis Ghent Pellet Plant (new, 2027)", "p_kordis_be", "Gent", "9042", "base.be"),
    ("s_kordis_duisburg", "Kordis Duisburg Plant", "p_kordis_de", "Duisburg", "47138", "base.de"),
    ("s_nordwerk_marl", "Nordwerk Marl Plant", "p_nordwerk_de", "Marl", "45772", "base.de"),
]

CONTACTS = [
    # key, name, parent, function
    ("c_valcrest_grp", "Laurent Dubois", "g_valcrest", "Group Procurement Director"),
    ("c_valcrest_be", "Isabelle Moreau", "p_valcrest_be", "Supply Chain Manager"),
    ("c_valcrest_be_site", "Koen Lambrechts", "p_valcrest_be", "Plant Logistics Lead"),
    ("c_valcrest_de", "Stefan Kraemer", "p_valcrest_de", "Logistics Manager"),
    ("c_valcrest_nl", "Marloes de Vries", "p_valcrest_nl", "Logistics Coordinator"),
    ("c_halden", "Wim Goossens", "p_halden", "Logistics Manager"),
    ("c_nordwerk_de", "Anja Vogel", "p_nordwerk_de", "Head of Logistics"),
    ("c_nordwerk_pl", "Tomasz Nowicki", "p_nordwerk_pl", "Logistics Manager"),
    ("c_lumora", "Sarah Willems", "p_lumora", "Supply Chain Lead"),
    ("c_castellan", "Julien Martin", "p_castellan", "Logistics Manager"),
    ("c_aurelia", "Marta Ruiz", "p_aurelia", "Logistics Manager"),
    ("c_brevik", "Bram Hendrickx", "p_brevik", "Operations Manager"),
    ("c_durand", "Nathalie Roux", "p_durand", "Supply Chain Manager"),
    ("c_kemora", "Javier Ortega", "p_kemora", "Logistics Manager"),
    ("c_hoven", "Erik Smits", "p_hoven", "Plant Manager"),
    ("c_fiorenza", "Luca Bianchi", "p_fiorenza", "Logistics Manager"),
    ("c_marlowe", "Elise Vandenberghe", "p_marlowe", "Logistics Manager"),
    ("c_grainfield_nl", "Joost Bakker", "p_grainfield_nl", "Transport Manager"),
    ("c_grainfield_fr", "Claire Lefevre", "p_grainfield_fr", "Supply Chain Manager"),
    ("c_bakeline", "Tine Desmet", "p_bakeline", "Logistics Manager"),
    ("c_pelton", "Lena Schulz", "p_pelton", "Supply Chain Manager"),
    ("c_westbrook", "Ruud Jansen", "p_westbrook", "Operations Manager"),
    ("c_tessaro", "Giulia Romano", "p_tessaro", "Logistics Manager"),
    ("c_zellner", "Markus Engel", "p_zellner", "Head of Purchasing"),
    ("c_kordis_be", "Hannah De Wilde", "p_kordis_be", "Procurement Manager"),
    ("c_kordis_de", "Felix Wagner", "p_kordis_de", "Plant Logistics Manager"),
    ("c_reform", "Femke Visser", "p_reform", "Logistics Lead"),
    ("c_verdant", "Antoine Girard", "p_verdant", "Operations Manager"),
    ("c_ostrava", "Petr Dvorak", "p_ostrava", "Plant Manager"),
    ("c_greenmill", "Jan Becker", "p_greenmill", "Head of Operations"),
    ("c_circulex", "Noor Hendriks", "t_circulex", "Supply Chain Manager"),
    ("c_brightwater", "Pauline Maes", "t_brightwater", "Logistics Manager"),
]

PRODUCTS = [
    # key, default_code, name
    ("lg_prod_wh_storage", "WH-STOR", "Warehousing - pallet storage (annual estimate)"),
    ("lg_prod_wh_bagging", "WH-BAG", "Bagging & packing (annual estimate)"),
    ("lg_prod_wh_stuffing", "WH-STUF", "Container stuffing (annual estimate)"),
    ("lg_prod_tr_bulk", "TR-BULK", "Bulk road transport (annual estimate)"),
    ("lg_prod_tr_shuttle", "TR-SHUT", "Plant shuttle transport (annual estimate)"),
    ("lg_prod_tr_food", "TR-FOOD", "Food-grade tank transport (annual estimate)"),
    ("lg_prod_tr_clean", "TR-CLEAN", "Tank cleaning & certification (annual estimate)"),
    ("lg_prod_vas", "VAS", "Value-added handling (annual estimate)"),
]

# ---------------------------------------------------------------------------
# Opportunities and leads. One dict per crm.lead record.
# outcome: open | won | lost | lead
# ---------------------------------------------------------------------------
def O(key, name, partner, owner, team, company, stage, prob, rev, outcome, segment, region, rtype,
      signal_source, signal_user, signal_date, feas="", feas_user="", decision="", deadline="",
      last_touch="", start="", months=0, delivering=None, tags=None, site="", lost_reason="",
      priority="1", story="", description=""):
    return dict(key=key, name=name, partner=partner, owner=owner, team=team, company=company, stage=stage,
                prob=prob, rev=rev, outcome=outcome, segment=segment, region=region, rtype=rtype,
                signal_source=signal_source, signal_user=signal_user, signal_date=signal_date,
                feas=feas, feas_user=feas_user, decision=decision, deadline=deadline,
                last_touch=last_touch, start=start, months=months, delivering=delivering or [company],
                tags=tags or [], site=site, lost_reason=lost_reason, priority=priority, story=story,
                description=description)


LEADS = [
    # ---------------- OPEN PIPELINE ----------------
    O("lg_opp_v6", "Valcrest Belgium - bulk transport renewal 2027-2028", "c_valcrest_be", "ruben", "kaw", "tr",
      "negotiation", 75, 2420000, "open", "polyolefins", "benelux", "retained", "sales", "ruben", "2026-08-18",
      feas="not_needed", deadline="2026-11-27", last_touch="2026-10-22", start="2027-01-01", months=24,
      tags=["lg_tag_bulk"], site="s_valcrest_antwerp", priority="2",
      description="Renewal of the existing bulk silo transport scope only (run-rate 2.35 M EUR + indexation). "
                  "The warehousing deal won in June is a separate expansion and is not part of this value."),
    O("lg_opp_d2", "Halden - +2,000 pallet positions and export container stuffing", "c_halden", "ruben", "kaw", "wh",
      "proposal", 50, 340000, "open", "polyolefins", "benelux", "expansion", "customer", "ruben", "2026-09-10",
      feas="conditional", feas_user="lotte", deadline="2026-12-15", last_touch="2026-10-21", start="2027-02-01",
      months=35, tags=["lg_tag_wh", "lg_tag_stuffing"], site="s_halden", story="D",
      description="Incremental scope requested during the renewal talks. Kept separate from the renewal (retained) "
                  "so retained and expansion revenue are not double counted. Co-terminates with the renewal."),
    O("lg_opp_n3", "Nordwerk - warehousing Duisburg for export flows", "c_nordwerk_de", "jonas", "kag", "de",
      "solution", 35, 720000, "open", "polyolefins", "germany", "expansion", "operations", "markus", "2026-08-26",
      feas="requested", feas_user="markus", deadline="2027-01-29", last_touch="2026-10-07", start="2027-04-01",
      months=36, tags=["lg_tag_wh"]),
    O("lg_opp_ca3", "Castellan - consignment stock near Lyon", "c_castellan", "camille", "kaw", "tr",
      "qualified", 20, 250000, "open", "polyolefins", "france", "expansion", "customer", "camille", "2026-05-19",
      feas="requested", feas_user="lotte", deadline="2026-10-30", last_touch="2026-07-14", start="2027-01-01",
      months=24, tags=["lg_tag_wh"],
      description="Needs a partner warehouse in the Lyon area (no own site). No next action planned."),
    O("lg_opp_au2", "Aurelia - export packing in Antwerp", "c_aurelia", "camille", "kaw", "wh",
      "proposal", 50, 310000, "open", "polyolefins", "southern_europe", "expansion", "operations", "lotte", "2026-07-30",
      feas="feasible", feas_user="lotte", deadline="2026-12-10", last_touch="2026-10-16", start="2027-01-15",
      months=24, tags=["lg_tag_bagging", "lg_tag_stuffing"]),
    O("lg_opp_g3", "Grainfield Milling - food-grade tanker renewal 2026-2028", "c_grainfield_nl", "amira", "nbd", "tr",
      "negotiation", 70, 850000, "open", "food_feed", "benelux", "retained", "sales", "amira", "2026-07-01",
      feas="not_needed", deadline="2026-11-20", last_touch="2026-10-19", start="2026-12-01", months=24,
      tags=["lg_tag_food"], description="Current contract ran until end of July; rolling extension while the renewal is negotiated."),
    O("lg_opp_bk3", "Bakeline - cross-dock Kortrijk", "c_bakeline", "amira", "nbd", "tr",
      "qualified", 25, 180000, "open", "food_feed", "benelux", "expansion", "operations", "pieter", "2026-06-02",
      feas="requested", feas_user="pieter", deadline="2026-12-18", last_touch="2026-06-30", start="2027-02-01",
      months=24, tags=["lg_tag_vas"]),
    O("lg_opp_c", "Kordis - integrated logistics, new Ghent pellet plant + Duisburg", "c_kordis_be", "sophie", "nbd", "wh",
      "negotiation", 60, 3200000, "open", "circular", "benelux", "new", "tender", "jonas", "2025-12-03",
      feas="conditional", feas_user="lotte", deadline="2026-12-18", last_touch="2026-10-28", start="2027-07-01",
      months=60, delivering=["wh", "tr", "de"], tags=["lg_tag_wh", "lg_tag_bulk", "lg_tag_vas"], site="s_kordis_ghent",
      priority="3", story="C",
      description="Strategic multi-entity tender. Contracting entity: Tervane Warehousing NV; Transport NV and "
                  "Logistik GmbH deliver parts of the scope. Revenue reported once, on this opportunity."),
    O("lg_opp_r4", "ReForm - bale storage before sorting", "c_reform", "ruben", "kaw", "wh",
      "proposal", 45, 220000, "open", "circular", "benelux", "expansion", "operations", "lotte", "2026-09-03",
      feas="feasible", feas_user="lotte", deadline="2027-01-15", last_touch="2026-10-09", start="2027-03-01",
      months=24, tags=["lg_tag_wh"]),
    O("lg_opp_brevik_ren", "Brevik - warehousing renewal 2027-2028", "c_brevik", "ruben", "kaw", "wh",
      "proposal", 60, 300000, "open", "polyolefins", "benelux", "retained", "sales", "ruben", "2026-09-15",
      feas="not_needed", deadline="2026-12-05", last_touch="2026-10-14", start="2027-01-01", months=24,
      tags=["lg_tag_wh"]),
    O("lg_opp_greenmill", "Greenmill - bale transport Essen region", "c_greenmill", "jonas", "kag", "de",
      "qualified", 20, 360000, "open", "circular", "germany", "new", "marketing", "jonas", "2026-06-11",
      feas="not_needed", deadline="2027-02-26", last_touch="2026-08-02", start="2027-04-01", months=24,
      tags=["lg_tag_bulk"]),
    O("lg_opp_durand", "Durand Compounds - Antwerp to Normandy packed transport", "c_durand", "camille", "kaw", "tr",
      "proposal", 50, 290000, "open", "polyolefins", "france", "new", "customer", "camille", "2026-08-27",
      feas="not_needed", deadline="2026-12-12", last_touch="2026-10-23", start="2027-01-04", months=24,
      tags=["lg_tag_packed"]),
    O("lg_opp_tessaro", "Tessaro Feed - feed additives Antwerp to North Italy", "c_tessaro", "camille", "kaw", "tr",
      "solution", 35, 400000, "open", "food_feed", "southern_europe", "new", "marketing", "camille", "2026-09-16",
      feas="in_review", feas_user="pieter", deadline="2027-01-22", last_touch="2026-10-12", start="2027-03-01",
      months=24, tags=["lg_tag_food", "lg_tag_intermodal"]),

    # ---------------- WON ----------------
    O("lg_opp_a", "Valcrest Belgium - warehousing, bagging and plant shuttle (Antwerp)", "c_valcrest_be", "ruben", "kaw", "wh",
      "won", 100, 1850000, "won", "polyolefins", "benelux", "expansion", "operations", "pieter", "2026-03-04",
      feas="conditional", feas_user="lotte", decision="2026-06-19", deadline="2026-06-19", last_touch="2026-10-20",
      start="2026-09-01", months=36, delivering=["wh", "tr"], tags=["lg_tag_wh", "lg_tag_bagging", "lg_tag_bulk"],
      site="s_valcrest_antwerp", priority="2", story="A",
      description="Warehousing (11,500 pallet positions, Hall 3), bagging of PE granulate and a plant shuttle next "
                  "to the existing bulk transport contract. Contracting entity Tervane Warehousing NV; the shuttle "
                  "is delivered by Tervane Transport NV."),
    O("lg_opp_b", "Marlowe - dedicated food-grade tankers Ghent", "c_marlowe", "amira", "nbd", "tr",
      "won", 100, 620000, "won", "food_feed", "benelux", "new", "customer", "amira", "2026-03-17",
      feas="feasible", feas_user="pieter", decision="2026-05-27", deadline="2026-05-27", last_touch="2026-10-06",
      start="2026-07-01", months=24, tags=["lg_tag_food"], site="s_marlowe", story="B"),
    O("lg_opp_d1", "Halden - warehousing & bagging renewal 2027-2029", "c_halden", "ruben", "kaw", "wh",
      "won", 100, 1430000, "won", "polyolefins", "benelux", "retained", "sales", "ruben", "2026-06-30",
      feas="not_needed", decision="2026-10-08", deadline="2026-10-08", last_touch="2026-10-21", start="2027-01-01",
      months=36, tags=["lg_tag_wh", "lg_tag_bagging"], site="s_halden", story="D",
      description="Renewal of the current scope (9,000 positions + bagging) at the indexed price. "
                  "Additional positions and container stuffing are in a separate expansion opportunity."),
    O("lg_opp_h1", "Halden - warehousing & bagging Antwerp (initial contract)", "c_halden", "ruben", "kaw", "wh",
      "won", 100, 1380000, "won", "polyolefins", "benelux", "new", "tender", "ruben", "2023-09-12",
      decision="2023-11-28", deadline="2023-11-28", last_touch="2023-12-15", start="2024-01-01", months=36,
      tags=["lg_tag_wh", "lg_tag_bagging"], site="s_halden"),
    O("lg_opp_h2", "Halden - second bagging shift", "c_halden", "ruben", "kaw", "wh",
      "won", 100, 160000, "won", "polyolefins", "benelux", "expansion", "operations", "lotte", "2025-01-20",
      feas="feasible", feas_user="lotte", decision="2025-02-17", deadline="2025-02-17", last_touch="2025-03-03",
      start="2025-03-01", months=22, tags=["lg_tag_bagging"]),
    O("lg_opp_v1", "Valcrest Belgium - bulk transport renewal 2025-2026", "c_valcrest_be", "ruben", "kaw", "tr",
      "won", 100, 2350000, "won", "polyolefins", "benelux", "retained", "sales", "ruben", "2024-07-02",
      feas="not_needed", decision="2024-10-15", deadline="2024-10-15", last_touch="2024-11-04", start="2025-01-01",
      months=24, tags=["lg_tag_bulk"], site="s_valcrest_antwerp"),
    O("lg_opp_v2", "Valcrest Compounds - packed transport Venlo to France", "c_valcrest_nl", "ruben", "kaw", "tr",
      "won", 100, 420000, "won", "polyolefins", "benelux", "expansion", "customer", "ruben", "2024-01-29",
      decision="2024-03-12", deadline="2024-03-12", last_touch="2024-03-20", start="2024-04-01", months=24,
      tags=["lg_tag_packed"], site="s_valcrest_venlo"),
    O("lg_opp_v2r", "Valcrest Compounds - packed transport renewal 2026-2027", "c_valcrest_nl", "ruben", "kaw", "tr",
      "won", 100, 430000, "won", "polyolefins", "benelux", "retained", "sales", "ruben", "2025-12-08",
      feas="not_needed", decision="2026-02-24", deadline="2026-02-24", last_touch="2026-03-10", start="2026-04-01",
      months=24, tags=["lg_tag_packed"], site="s_valcrest_venlo"),
    O("lg_opp_v3", "Valcrest Deutschland - road transport Koeln", "c_valcrest_de", "jonas", "kag", "de",
      "won", 100, 1100000, "won", "polyolefins", "germany", "expansion", "sales", "ruben", "2023-10-10",
      decision="2023-12-05", deadline="2023-12-05", last_touch="2023-12-18", start="2024-01-01", months=24,
      tags=["lg_tag_bulk"], site="s_valcrest_koeln",
      description="First contract with the German legal entity of an existing customer group: expansion, not new business."),
    O("lg_opp_v4", "Valcrest Deutschland - road transport renewal 2026-2027", "c_valcrest_de", "jonas", "kag", "de",
      "won", 100, 1150000, "won", "polyolefins", "germany", "retained", "sales", "jonas", "2025-08-25",
      feas="not_needed", decision="2025-11-20", deadline="2025-11-20", last_touch="2025-12-02", start="2026-01-01",
      months=24, tags=["lg_tag_bulk"], site="s_valcrest_koeln"),
    O("lg_opp_lu1", "Lumora - packed film transport Benelux / France", "c_lumora", "ruben", "kaw", "tr",
      "won", 100, 540000, "won", "polyolefins", "benelux", "new", "customer", "ruben", "2023-12-11",
      decision="2024-02-08", deadline="2024-02-08", last_touch="2024-02-20", start="2024-03-01", months=24,
      tags=["lg_tag_packed"], site="s_lumora"),
    O("lg_opp_lub", "Lumora - seasonal buffer storage", "c_lumora", "ruben", "kaw", "wh",
      "won", 100, 120000, "won", "polyolefins", "benelux", "expansion", "operations", "pieter", "2024-07-22",
      feas="feasible", feas_user="lotte", decision="2024-08-21", deadline="2024-08-21", last_touch="2024-09-02",
      start="2024-09-15", months=12, tags=["lg_tag_wh"]),
    O("lg_opp_lu2", "Lumora - packed transport renewal 2026-2027", "c_lumora", "ruben", "kaw", "tr",
      "won", 100, 560000, "won", "polyolefins", "benelux", "retained", "sales", "ruben", "2025-11-17",
      feas="not_needed", decision="2026-01-20", deadline="2026-01-20", last_touch="2026-02-02", start="2026-03-01",
      months=24, tags=["lg_tag_packed"]),
    O("lg_opp_n1", "Nordwerk - road transport Marl to Benelux / Germany", "c_nordwerk_de", "jonas", "kag", "de",
      "won", 100, 950000, "won", "polyolefins", "germany", "new", "tender", "jonas", "2024-02-15",
      decision="2024-04-22", deadline="2024-04-22", last_touch="2024-05-06", start="2024-06-01", months=36,
      tags=["lg_tag_bulk"], site="s_nordwerk_marl"),
    O("lg_opp_g1", "Grainfield Milling - food-grade bulk flour tankers", "c_grainfield_nl", "amira", "nbd", "tr",
      "won", 100, 820000, "won", "food_feed", "benelux", "new", "marketing", "amira", "2024-04-03",
      decision="2024-06-12", deadline="2024-06-12", last_touch="2024-06-28", start="2024-08-01", months=24,
      tags=["lg_tag_food"]),
    O("lg_opp_g2", "Grainfield Meunerie - tankers Lille region", "c_grainfield_fr", "amira", "nbd", "tr",
      "won", 100, 360000, "won", "food_feed", "france", "expansion", "operations", "pieter", "2025-02-24",
      feas="feasible", feas_user="pieter", decision="2025-04-02", deadline="2025-04-02", last_touch="2025-04-15",
      start="2025-05-01", months=24, tags=["lg_tag_food"]),
    O("lg_opp_o1", "Ostrava Polymer Recycling - pellet transport CZ to DE", "c_ostrava", "jonas", "kag", "de",
      "won", 100, 410000, "won", "circular", "cee", "new", "marketing", "jonas", "2024-02-01",
      decision="2024-03-27", deadline="2024-03-27", last_touch="2024-04-10", start="2024-05-01", months=24,
      tags=["lg_tag_bulk"]),
    O("lg_opp_r1", "ReForm - recycled pellet storage", "c_reform", "ruben", "kaw", "wh",
      "won", 100, 620000, "won", "circular", "benelux", "new", "customer", "ruben", "2023-12-04",
      decision="2024-01-24", deadline="2024-01-24", last_touch="2024-02-05", start="2024-03-01", months=24,
      tags=["lg_tag_wh"]),
    O("lg_opp_r3", "ReForm - storage renewal 2026-2027", "c_reform", "ruben", "kaw", "wh",
      "won", 100, 640000, "won", "circular", "benelux", "retained", "sales", "ruben", "2025-11-24",
      feas="not_needed", decision="2026-01-28", deadline="2026-01-28", last_touch="2026-02-09", start="2026-03-01",
      months=24, tags=["lg_tag_wh"]),
    O("lg_opp_brevik", "Brevik - masterbatch warehousing Genk", "c_brevik", "ruben", "kaw", "wh",
      "won", 100, 290000, "won", "polyolefins", "benelux", "new", "customer", "ruben", "2024-10-08",
      decision="2024-12-03", deadline="2024-12-03", last_touch="2024-12-16", start="2025-01-01", months=24,
      tags=["lg_tag_wh"]),
    O("lg_opp_p1", "Pelton - pet food distribution Germany", "c_pelton", "jonas", "kag", "de",
      "won", 100, 570000, "won", "food_feed", "germany", "new", "marketing", "jonas", "2024-11-06",
      decision="2025-01-15", deadline="2025-01-15", last_touch="2025-02-10", start="2025-03-01", months=36,
      tags=["lg_tag_packed"]),
    O("lg_opp_ca2", "Castellan - Antwerp to Lyon packed transport", "c_castellan", "camille", "kaw", "tr",
      "won", 100, 450000, "won", "polyolefins", "france", "new", "customer", "camille", "2025-01-21",
      decision="2025-03-18", deadline="2025-03-18", last_touch="2025-03-31", start="2025-04-01", months=24,
      tags=["lg_tag_packed"], description="Second attempt after the 2024 bid was lost on price."),
    O("lg_opp_bk2", "Bakeline - ambient food distribution Benelux", "c_bakeline", "amira", "nbd", "tr",
      "won", 100, 390000, "won", "food_feed", "benelux", "new", "marketing", "amira", "2025-06-12",
      decision="2025-08-26", deadline="2025-08-26", last_touch="2025-09-08", start="2025-10-01", months=24,
      tags=["lg_tag_packed"]),
    O("lg_opp_au1", "Aurelia - intermodal Antwerp to Tarragona", "c_aurelia", "camille", "kaw", "tr",
      "won", 100, 680000, "won", "polyolefins", "southern_europe", "new", "tender", "camille", "2025-06-30",
      feas="feasible", feas_user="pieter", decision="2025-09-09", deadline="2025-09-09", last_touch="2025-09-22",
      start="2025-10-01", months=36, tags=["lg_tag_intermodal"]),
    O("lg_opp_vr1", "Verdant Regrind - regrind collection northern France", "c_verdant", "camille", "kaw", "tr",
      "won", 100, 330000, "won", "circular", "france", "new", "customer", "camille", "2025-08-19",
      feas="feasible", feas_user="pieter", decision="2025-10-14", deadline="2025-10-14", last_touch="2025-10-24",
      start="2025-11-01", months=24, tags=["lg_tag_bulk"]),
    O("lg_opp_wb", "Westbrook Malt - malt silo transport Terneuzen", "c_westbrook", "amira", "nbd", "tr",
      "won", 100, 470000, "won", "food_feed", "benelux", "new", "marketing", "amira", "2026-05-21",
      feas="feasible", feas_user="pieter", decision="2026-10-13", deadline="2026-10-13", last_touch="2026-10-27",
      start="2026-12-01", months=24, tags=["lg_tag_bulk"],
      description="Won in October. Simple handover created; still awaiting acceptance by Transport Operations."),

    # ---------------- LOST ----------------
    O("lg_opp_cprev", "Kordis Circular - Duisburg plant transport (2025 bid)", "c_kordis_de", "jonas", "kag", "de",
      "negotiation", 0, 900000, "lost", "circular", "germany", "new", "tender", "jonas", "2025-02-10",
      decision="2025-04-29", deadline="2025-04-30", last_touch="2025-04-29", start="2025-07-01", months=36,
      tags=["lg_tag_bulk"], lost_reason="lg_lr_price", site="s_kordis_duisburg", story="C"),
    O("lg_opp_v5", "Valcrest Compounds - warehousing Venlo", "c_valcrest_nl", "ruben", "kaw", "wh",
      "solution", 0, 600000, "lost", "polyolefins", "benelux", "expansion", "customer", "ruben", "2025-03-31",
      feas="not_feasible", feas_user="lotte", decision="2025-05-14", deadline="2025-06-30", last_touch="2025-05-14",
      start="2025-09-01", months=36, tags=["lg_tag_wh"], lost_reason="lg_lr_coverage", site="s_valcrest_venlo"),
    O("lg_opp_n2", "Nordwerk Polska - domestic transport Poland", "c_nordwerk_pl", "jonas", "kag", "de",
      "proposal", 0, 380000, "lost", "polyolefins", "cee", "expansion", "customer", "jonas", "2025-04-14",
      decision="2025-06-10", deadline="2025-06-30", last_touch="2025-06-10", start="2025-09-01", months=24,
      tags=["lg_tag_bulk"], lost_reason="lg_lr_price"),
    O("lg_opp_r2", "ReForm - outbound transport", "c_reform", "ruben", "kaw", "tr",
      "proposal", 0, 280000, "lost", "circular", "benelux", "expansion", "operations", "lotte", "2025-05-20",
      decision="2025-07-08", deadline="2025-07-15", last_touch="2025-07-08", start="2025-09-01", months=24,
      tags=["lg_tag_bulk"], lost_reason="lg_lr_price"),
    O("lg_opp_p2", "Pelton - warehousing Duisburg", "c_pelton", "jonas", "kag", "de",
      "solution", 0, 440000, "lost", "food_feed", "germany", "expansion", "operations", "markus", "2026-02-17",
      feas="feasible", feas_user="markus", decision="2026-04-22", deadline="2026-04-30", last_touch="2026-04-22",
      start="2026-07-01", months=36, tags=["lg_tag_wh"], lost_reason="lg_lr_inhouse"),
    O("lg_opp_o2", "Ostrava - pellet transport renewal 2026-2027", "c_ostrava", "jonas", "kag", "de",
      "negotiation", 0, 430000, "lost", "circular", "cee", "retained", "sales", "jonas", "2026-01-12",
      feas="not_needed", decision="2026-03-16", deadline="2026-03-31", last_touch="2026-03-16", start="2026-05-01",
      months=24, tags=["lg_tag_bulk"], lost_reason="lg_lr_price"),
    O("lg_opp_ca1", "Castellan - Antwerp to Lyon packed transport (2024 bid)", "c_castellan", "camille", "kaw", "tr",
      "proposal", 0, 480000, "lost", "polyolefins", "france", "new", "customer", "camille", "2024-03-25",
      decision="2024-05-30", deadline="2024-06-15", last_touch="2024-05-30", start="2024-07-01", months=24,
      tags=["lg_tag_packed"], lost_reason="lg_lr_price"),
    O("lg_opp_bk1", "Bakeline - food distribution (2024 bid)", "c_bakeline", "amira", "nbd", "tr",
      "qualified", 0, 350000, "lost", "food_feed", "benelux", "new", "marketing", "amira", "2024-06-20",
      decision="2024-09-18", deadline="2024-09-30", last_touch="2024-09-18", start="2025-01-01", months=24,
      tags=["lg_tag_packed"], lost_reason="lg_lr_postponed"),
    O("lg_opp_x1", "Kemora Films - Antwerp to Valencia transport", "c_kemora", "camille", "kaw", "tr",
      "qualified", 0, 260000, "lost", "polyolefins", "southern_europe", "new", "marketing", "camille", "2024-05-15",
      decision="2024-07-10", deadline="2024-07-31", last_touch="2024-07-10", start="2024-10-01", months=24,
      tags=["lg_tag_packed"], lost_reason="lg_lr_coverage"),
    O("lg_opp_x2", "Zellner Getreide - grain tankers Rhine-Neckar", "c_zellner", "jonas", "kag", "de",
      "proposal", 0, 520000, "lost", "food_feed", "germany", "new", "tender", "jonas", "2024-09-02",
      decision="2024-11-05", deadline="2024-11-15", last_touch="2024-11-05", start="2025-01-01", months=36,
      tags=["lg_tag_food"], lost_reason="lg_lr_price"),
    O("lg_opp_x3", "Hoven Resins - warehousing Moerdijk", "c_hoven", "ruben", "kaw", "wh",
      "solution", 0, 410000, "lost", "polyolefins", "benelux", "new", "customer", "ruben", "2025-07-14",
      feas="feasible", feas_user="lotte", decision="2025-09-30", deadline="2025-10-15", last_touch="2025-09-30",
      start="2026-01-01", months=36, tags=["lg_tag_wh"], lost_reason="lg_lr_postponed"),
    O("lg_opp_x4", "Fiorenza Plast - Antwerp to Bergamo intermodal", "c_fiorenza", "camille", "kaw", "tr",
      "qualified", 0, 300000, "lost", "polyolefins", "southern_europe", "new", "marketing", "camille", "2026-03-11",
      decision="2026-05-06", deadline="2026-05-31", last_touch="2026-05-06", start="2026-09-01", months=24,
      tags=["lg_tag_intermodal"], lost_reason="lg_lr_coverage"),

    # ---------------- LEADS (not yet qualified) ----------------
    O("lg_lead_l1", "Circulex - pellet storage near Rotterdam (trade fair contact)", "c_circulex", "amira", "nbd", "wh",
      "", 0, 0, "lead", "circular", "benelux", "new", "marketing", "amira", "2026-09-24", last_touch="2026-09-24",
      tags=["lg_tag_wh"]),
    O("lg_lead_l2", "Ops signal: Nordwerk Polska asks for domestic distribution", "c_nordwerk_pl", "jonas", "kag", "de",
      "", 0, 0, "lead", "polyolefins", "cee", "expansion", "operations", "markus", "2026-10-12", last_touch="2026-10-12",
      tags=["lg_tag_bulk"]),
    O("lg_lead_l3", "Website request: ADR chemical tank transport UK", "", "", "nbd", "",
      "", 0, 0, "lead", "", "", "", "customer", "", "2026-10-21"),
    O("lg_lead_l4", "Ops signal: Lumora weekend loading peaks - buffer storage?", "c_lumora", "ruben", "kaw", "wh",
      "", 0, 0, "lead", "polyolefins", "benelux", "expansion", "operations", "pieter", "2026-10-20",
      last_touch="2026-10-20", tags=["lg_tag_wh"]),
    O("lg_lead_l5", "Castellan - flows for new Grenoble site", "c_castellan", "camille", "kaw", "tr",
      "", 0, 0, "lead", "polyolefins", "france", "expansion", "customer", "camille", "2026-10-15",
      last_touch="2026-10-15", tags=["lg_tag_packed"]),
]

# ---------------------------------------------------------------------------
# Proposals (sale.order quotations) - ANNUAL values only (see fit-gap: sale_crm
# raises expected revenue to the quotation total on confirmation).
# ---------------------------------------------------------------------------
QUOTES = [
    # key, partner, company, lead, owner, date, validity, ref, confirm, lines[(product, description, amount)]
    ("lg_so_a", "c_valcrest_be", "wh", "lg_opp_a", "ruben", "2026-05-29", "2026-06-30",
     "Proposal v2 - warehousing, bagging and shuttle (annual values)", True, [
         ("lg_prod_wh_storage", "Pallet storage, 11,500 positions in Hall 3", 1180000),
         ("lg_prod_wh_bagging", "Bagging of PE granulate in 25 kg bags, line 2", 380000),
         ("lg_prod_tr_shuttle", "Plant shuttle, 14 trips/day (delivered by Tervane Transport NV)", 290000)]),
    ("lg_so_b", "c_marlowe", "tr", "lg_opp_b", "amira", "2026-04-28", "2026-05-31",
     "Proposal - dedicated food-grade tankers (annual values)", True, [
         ("lg_prod_tr_food", "2 dedicated food-grade tankers, Ghent to feed mills NL / FR", 560000),
         ("lg_prod_tr_clean", "Tank cleaning with certificates per load", 60000)]),
    ("lg_so_c", "c_kordis_be", "wh", "lg_opp_c", "sophie", "2026-10-02", "2026-12-18",
     "BAFO baseline - integrated logistics Ghent + Duisburg (annual values)", False, [
         ("lg_prod_wh_storage", "Storage of bales and pellets, Hall 5 (permit conditions apply)", 1450000),
         ("lg_prod_tr_shuttle", "Shuttle Ghent pellet plant to Beveren warehouse", 650000),
         ("lg_prod_tr_bulk", "Bulk transport Duisburg plant (delivered by Tervane Logistik GmbH)", 820000),
         ("lg_prod_vas", "Sampling, re-bagging and labelling", 280000)]),
    ("lg_so_d1", "c_halden", "wh", "lg_opp_d1", "ruben", "2026-09-22", "2026-10-31",
     "Renewal 2027-2029 - current scope at indexed price (annual values)", True, [
         ("lg_prod_wh_storage", "Pallet storage, 9,000 positions (current scope)", 1050000),
         ("lg_prod_wh_bagging", "Bagging (current scope)", 380000)]),
    ("lg_so_d2", "c_halden", "wh", "lg_opp_d2", "ruben", "2026-10-15", "2026-12-15",
     "Expansion - additional positions and export container stuffing (annual values)", False, [
         ("lg_prod_wh_storage", "Additional 2,000 pallet positions, Hall 2", 230000),
         ("lg_prod_wh_stuffing", "Export container stuffing", 110000)]),
    ("lg_so_wb", "c_westbrook", "tr", "lg_opp_wb", "amira", "2026-09-29", "2026-10-31",
     "Proposal - malt silo transport (annual values)", True, [
         ("lg_prod_tr_bulk", "Silo transport malt, Terneuzen to breweries Benelux", 470000)]),
]

# ---------------------------------------------------------------------------
# Handover projects, stages and tasks
# ---------------------------------------------------------------------------
PROJECTS = [
    ("lg_proj_ho_wh", "Operations Handover - Tervane Warehousing NV", "wh"),
    ("lg_proj_ho_tr", "Operations Handover - Tervane Transport NV", "tr"),
    ("lg_proj_ho_de", "Operations Handover - Tervane Logistik GmbH", "de"),
]
TASK_STAGES = [
    ("lg_tstage_toaccept", "To Accept", 1, False, False),
    ("lg_tstage_accepted", "Accepted", 2, False, True),
    ("lg_tstage_onboarding", "Onboarding", 3, False, False),
    ("lg_tstage_live", "Live", 4, True, False),
]
TASKS = [
    # key, name, project, stage, users, partner, lead, type, accepted_by, accepted_date, go_live, description
    ("lg_task_a", "HO-A Valcrest Belgium - warehousing, bagging & shuttle", "lg_proj_ho_wh", "lg_tstage_live",
     ["lotte"], "p_valcrest_be", "lg_opp_a", "detailed", "lotte", "2026-07-03", "2026-09-01",
     "<p><b>Detailed handover (integrated solution).</b> Scope: 11,500 pallet positions in Hall 3, bagging line 2 "
     "(second shift), plant shuttle 14 trips/day by Tervane Transport NV, daily EDI stock report.</p>"
     "<p>Workstreams are sub-tasks. Commercial owner stays responsible until Operations accepts.</p>"),
    ("lg_task_b", "HO-B Marlowe - dedicated food-grade tankers", "lg_proj_ho_tr", "lg_tstage_live",
     ["pieter"], "p_marlowe", "lg_opp_b", "simple", "pieter", "2026-06-05", "2026-07-01",
     "<p><b>Simple handover.</b> Two dedicated food-grade tankers from 1 July, cleaning certificate per load, "
     "customer contacts and KPIs listed in the Log note.</p>"),
    ("lg_task_wb", "HO Westbrook Malt - silo transport", "lg_proj_ho_tr", "lg_tstage_toaccept",
     ["pieter"], "p_westbrook", "lg_opp_wb", "simple", "", "", "2026-12-01",
     "<p><b>Simple handover - awaiting acceptance.</b> Silo transport of malt Terneuzen to breweries.</p>"),
    ("lg_task_vr1", "HO Verdant Regrind - regrind collection", "lg_proj_ho_tr", "lg_tstage_live",
     ["pieter"], "p_verdant", "lg_opp_vr1", "simple", "pieter", "2025-10-24", "2025-11-01",
     "<p><b>Simple handover.</b> Weekly collection rounds northern France.</p>"),
    ("lg_task_au1", "HO Aurelia - intermodal Antwerp to Tarragona", "lg_proj_ho_tr", "lg_tstage_live",
     ["pieter"], "p_aurelia", "lg_opp_au1", "simple", "pieter", "2025-09-22", "2025-10-01",
     "<p><b>Simple handover.</b> Intermodal departures twice weekly.</p>"),
    ("lg_task_p1", "HO Pelton - pet food distribution", "lg_proj_ho_de", "lg_tstage_live",
     ["markus"], "p_pelton", "lg_opp_p1", "simple", "markus", "2025-02-10", "2025-03-01",
     "<p><b>Simple handover.</b> Distribution from Duisburg to retail DCs.</p>"),
]
SUBTASKS = [
    # key, name, parent, user, stage
    ("lg_task_a_1", "Hall 3 layout and 11,500 positions ready", "lg_task_a", "lotte"),
    ("lg_task_a_2", "Bagging line 2 - second shift staffing", "lg_task_a", "lotte"),
    ("lg_task_a_3", "Shuttle schedule plant to warehouse (Tervane Transport NV)", "lg_task_a", "pieter"),
    ("lg_task_a_4", "EDI stock report and order interface", "lg_task_a", "nina"),
    ("lg_task_a_5", "Billing set-up: per position / month and per bag", "lg_task_a", "elif"),
    ("lg_task_a_6", "QHSE check: fire load and housekeeping for PE pellets", "lg_task_a", "thomas"),
]


# ---------------------------------------------------------------------------
# Log note / activity register (rendered after date shifting)
# ---------------------------------------------------------------------------
def story_items(fd):
    """fd(date_str) -> formatted shifted date, e.g. '04 Mar 2026'."""
    R = USER_FUNCTION
    L = "__import__."
    items = []

    def note(key, story, seq, model, target, role_user, bdate, body, decision, verify):
        role = ("%s (fictional: %s)" % (R[role_user], USER_NAME[role_user])) if role_user in R else role_user
        items.append(dict(id="lg_item_" + key.replace("-", "_").lower(), name=key, story=story, sequence=seq,
                          kind="note", target_model=model, target_xmlid=L + target, role=role,
                          business_date=bdate, body=body, decision=decision, verification=verify))

    def activity(key, story, seq, model, target, user, days, summary, body, act_type="mail.mail_activity_data_todo"):
        items.append(dict(id="lg_item_" + key.replace("-", "_").lower(), name=key, story=story, sequence=seq,
                          kind="activity", target_model=model, target_xmlid=L + target,
                          activity_type_xmlid=act_type, activity_summary=summary,
                          activity_user_xmlid=L + "lg_user_" + user, activity_deadline_days=days, body=body,
                          verification="Activity '%s' visible on the record, assigned to %s" % (summary, USER_NAME[user])))

    def confirm(key, story, seq, target):
        items.append(dict(id="lg_item_" + key.replace("-", "_").lower(), name=key, story=story, sequence=seq,
                          kind="confirm_order", target_model="sale.order", target_xmlid=L + target,
                          verification="Quotation is a confirmed Sales Order; opportunity revenue unchanged"))

    # ---------------- Story A (primary) ----------------
    A, T = "lg_opp_a", "lg_task_a"
    note("A-01", "A", 10, "crm.lead", A, "pieter", "2026-03-04",
         "Signal from Operations. Our drivers at the Valcrest Antwerp plant wait 2 to 3 hours per loading because "
         "finished bags are stacked in the loading area. Valcrest rents overflow storage from a third party for about "
         "6,000 pallets and that contract ends in the summer.\n\nThis looks like a warehousing need next to the transport "
         "we already run for them. I raised it with Ruben (account owner) instead of keeping it in a planning e-mail.",
         "Pass to the account owner for qualification; no quote yet.",
         "Opportunity chatter shows the Operations signal as the first demo note")
    note("A-02", "A", 20, "crm.lead", A, "ruben", "2026-03-09",
         "Qualified on a call with Isabelle Moreau (Supply Chain Manager, Valcrest Belgium). Need confirmed: 10,000 to "
         "12,000 pallet positions, bagging of PE granulate in 25 kg bags, and a shuttle between plant and warehouse. "
         "Start wanted from %s. Valcrest Belgium decides; Group Procurement in Brussels signs.\n\nOnly five fields filled "
         "in Odoo: customer, title, owner, expected annual revenue (first estimate 1.9 M EUR) and the next action." % fd("2026-09-01"),
         "Move to Solution Design. Next action: feasibility review by Warehouse Operations within 10 days.",
         "Owner, first estimate and next action are visible on the opportunity")
    note("A-03", "A", 30, "crm.lead", A, "ruben", "2026-03-10",
         "Feasibility requested from Lotte Verhaegen (Warehouse Operations). Questions: free capacity in Hall 3 from "
         "%s, bagging line availability, shuttle timing with the existing bulk flows of Tervane Transport NV. "
         "QHSE, IT and Finance asked to add their input on this opportunity, not by e-mail." % fd("2026-09-01"),
         "Feasibility reviewer set on the opportunity; no quotation before the answer.",
         "Feasibility reviewer field = Lotte Verhaegen")
    note("A-04", "A", 40, "crm.lead", A, "lotte", "2026-03-20",
         "Feasible with conditions. Hall 3 can hold 11,500 positions from %s. Bagging line 2 needs a second shift "
         "from October; recruitment lead time 8 weeks. Shuttle of 14 trips a day fits the Transport NV fleet if the "
         "plant loading window moves to 06:00 to 22:00.\n\nQHSE (Thomas Wouters): fire load for PE pellets within the "
         "permit of Hall 3, standard housekeeping rules apply." % fd("2026-09-01"),
         "Feasibility = feasible with conditions. Conditions go into the proposal.",
         "Note visible, feasibility status 'Feasible with conditions'")
    note("A-05", "A", 50, "crm.lead", A, "elif", "2026-03-24",
         "Finance: credit limit for Valcrest Polymers Belgium NV is sufficient for the extra volume. Billing proposal: "
         "per pallet position per month plus per bag; shuttle billed by Tervane Warehousing NV and recharged internally "
         "to Transport NV. IT (Nina Hoffmann): the existing EDI link with Transport NV can carry a daily stock report.",
         "Commercial structure: one contract with Tervane Warehousing NV as contracting entity.",
         "Finance and IT input visible in the same chatter")
    note("A-06", "A", 60, "crm.lead", A, "ruben", "2026-04-24",
         "Price calculated in the group costing model (outside Odoo) and approved by Sophie Marchal. Proposal v1 sent: "
         "1.92 M EUR expected annual revenue, 36 months. Odoo holds the commercial outcome, not the cost calculation.",
         "Stage Proposal. Next action: proposal walkthrough with Valcrest supply chain and procurement.",
         "Proposal v1 amount mentioned; costing stays outside Odoo")
    note("A-07", "A", 70, "crm.lead", A, "ruben", "2026-05-29",
         "Negotiation: Group Procurement asked for 4 percent off the storage rate. Agreed 2.5 percent in exchange for a "
         "36-month term and an indexation clause. Proposal v2 sent and attached as quotation: 1.85 M EUR per year. "
         "Expected annual revenue updated to 1.85 M EUR.",
         "Stage Negotiation. Wait for signature; Sophie informed.",
         "Quotation smart button shows Proposal v2 with 1,850,000 total")
    note("A-08", "A", 80, "crm.lead", A, "ruben", "2026-06-19",
         "Valcrest Belgium signed. Won. Revenue type: Expansion, because the Valcrest group has been a customer since "
         "2022; this is not new business. Expected annual revenue 1.85 M EUR, total contract value 5.55 M EUR over 36 months.",
         "Create a detailed handover for Warehouse Operations. Ruben stays commercial owner until acceptance.",
         "Stage Won, revenue type Expansion, TCV 5,550,000")
    note("A-09", "A", 90, "crm.lead", A, "ruben", "2026-06-22",
         "Detailed handover created as task 'HO-A Valcrest Belgium' in the Warehousing handover project, with six "
         "workstreams (layout, second shift, shuttle, EDI, billing, QHSE). Waiting for acceptance by Lotte Verhaegen.",
         "Handover status: awaiting Operations acceptance (at that business date).",
         "Handovers smart button = 1")
    note("A-10", "A", 100, "project.task", T, "ruben", "2026-06-22",
         "Handover content. Customer contacts: Isabelle Moreau (supply chain), Koen Lambrechts (plant logistics). "
         "Volumes: 11,500 positions, about 95,000 bags a year, 14 shuttle trips a day. KPIs: dock-to-stock under 4 h, "
         "stock accuracy 99.8 percent, shuttle on-time 98 percent. Open points: second-shift recruitment, loading window "
         "06:00 to 22:00 to be confirmed by the plant.",
         "Operations to confirm the open points and accept.",
         "Handover task chatter shows the handover content note")
    note("A-11", "A", 110, "project.task", T, "lotte", "2026-07-03",
         "Handover accepted. Open points closed: second shift recruited, plant confirmed the 06:00 to 22:00 loading "
         "window. Go-live %s. Warehouse Operations owns delivery from today; Ruben remains the commercial owner of "
         "the Valcrest relationship." % fd("2026-09-01"),
         "Accepted by Lotte Verhaegen. Stage moves on to Onboarding / Live.",
         "Accepted By = Lotte Verhaegen on the task; opportunity shows 'Accepted by Operations'")
    note("A-12", "A", 120, "crm.lead", A, "ruben", "2026-10-20",
         "Live since %s. First quarterly review to prepare with the Valcrest group: storage needs at the Koeln and "
         "Venlo plants (Venlo warehousing was lost in 2025 because we had no site there)." % fd("2026-09-01"),
         "Next action: quarterly business review with the Valcrest group.",
         "Next action visible as planned activity")
    activity("A-13", "A", 130, "crm.lead", A, "ruben", 21,
             "Quarterly business review with Valcrest group",
             "Prepare QBR: KPIs of the first months, storage options Koeln and Venlo.", "mail.mail_activity_data_meeting")

    # ---------------- Story B ----------------
    B, TB = "lg_opp_b", "lg_task_b"
    note("B-01", "B", 10, "res.partner", "lg_p_marlowe", "amira", "2026-01-12",
         "Selected as a Food & Feed target account: certified feed-ingredient producer in Ghent, fits our food-grade "
         "tanker fleet and the Ghent cleaning station. No lead created: there is no concrete need yet.",
         "Target account with owner Amira; first outreach within a month.",
         "Contact form shows account status history and this note")
    note("B-02", "B", 20, "res.partner", "lg_p_marlowe", "amira", "2026-02-05",
         "First contact with Elise Vandenberghe (Logistics Manager) at a feed industry event. Current carrier performs "
         "well; agreed to stay in touch. Still no lead: a contact is not an opportunity.",
         "First contact date set. Follow up in the spring.",
         "First Contact (business) date filled on the contact")
    note("B-03", "B", 30, "crm.lead", B, "amira", "2026-03-17",
         "Concrete signal: Marlowe's current carrier withdraws two food-grade tankers from the Ghent region from %s. "
         "Elise asked us for an alternative. Lead created now, not before." % fd("2026-07-01"),
         "Qualify within a week.",
         "Signal source Customer request, signal date set")
    note("B-04", "B", 40, "crm.lead", B, "amira", "2026-03-25",
         "Qualified and converted to an opportunity: 2 dedicated food-grade tankers, about 1,900 loads a year from Ghent "
         "to feed mills in the Netherlands and northern France, cleaning certificate required per load, start %s." % fd("2026-07-01"),
         "Next action: tank availability and cleaning check with Transport Operations and QHSE.",
         "Opportunity in Solution Design, owner Amira")
    note("B-05", "B", 50, "crm.lead", B, "pieter", "2026-04-08",
         "Feasible. Two tankers can be freed from the spot pool from %s. QHSE confirmed the Ghent cleaning station "
         "issues the certificates Marlowe needs." % fd("2026-06-15"),
         "Feasibility = feasible. Price can be calculated.",
         "Feasibility reviewer = Pieter Vandaele")
    note("B-06", "B", 60, "crm.lead", B, "amira", "2026-04-28",
         "Proposal sent: 620,000 EUR expected annual revenue, 24 months. Price from the costing model; quotation in Odoo "
         "holds the annual summary.",
         "Follow-up call in two weeks.",
         "Quotation total 620,000")
    note("B-07", "B", 70, "crm.lead", B, "amira", "2026-05-27",
         "Marlowe signed. Won. Revenue type: New business (first contract with this customer). Simple handover to "
         "Transport Operations created.",
         "Handover to Pieter Vandaele; Amira stays owner until accepted.",
         "Stage Won, revenue type New business")
    note("B-08", "B", 80, "project.task", TB, "amira", "2026-05-28",
         "Simple handover. Contacts: Elise Vandenberghe. Volumes: about 1,900 loads a year, 2 dedicated tankers. "
         "Requirements: cleaning certificate per load, loading slots 05:00 to 21:00. Start %s." % fd("2026-07-01"),
         "Transport Operations to accept.",
         "Task chatter shows the handover note")
    note("B-09", "B", 90, "project.task", TB, "pieter", "2026-06-05",
         "Handover accepted. Tankers and drivers assigned, cleaning schedule set with the Ghent station.",
         "Accepted by Pieter Vandaele.",
         "Accepted By = Pieter Vandaele")
    activity("B-10", "B", 100, "crm.lead", B, "amira", 35,
             "First KPI review with Marlowe", "Loads, on-time rate and cleaning certificates over the first months.")

    # ---------------- Story C ----------------
    C, CP = "lg_opp_c", "lg_opp_cprev"
    note("C-01", "C", 10, "crm.lead", CP, "jonas", "2025-04-29",
         "Lost to the incumbent on price (about 7 percent below our offer). Customer feedback: our service model scored "
         "best, our index clause was too rigid.\n\nFollow-up: Kordis announced a new pellet plant in Ghent for 2027. "
         "Re-engage early and bring Operations feasibility in before the tender, not after.",
         "Lost reason Price. Follow-up: keep the relationship, watch the Ghent tender.",
         "Lost opportunity (filter Lost) shows reason and this note")
    note("C-02", "C", 20, "crm.lead", C, "jonas", "2025-12-03",
         "Kordis invited us to the tender for integrated logistics of the new Ghent pellet plant plus the Duisburg plant. "
         "The invitation came through the relationship kept after the 2025 loss.",
         "Strategic opportunity owned by Sophie Marchal; Jonas stays involved for Duisburg.",
         "Signal source Tender, raised by Jonas Kessler")
    note("C-03", "C", 30, "crm.lead", C, "thomas", "2026-02-11",
         "QHSE: storing plastic bales counts as waste storage. Hall 5 needs a check of the environmental permit, "
         "sprinklers are fine, maximum stack height 4 m. Feasible with conditions.",
         "Permit check is a condition of the offer.",
         "QHSE input visible on the opportunity")
    note("C-04", "C", 40, "crm.lead", C, "lotte", "2026-02-19",
         "Warehouse Operations: Hall 5 capacity fits the ramp-up from %s. Shuttle Ghent to Beveren by Transport NV; "
         "Duisburg flows by Logistik GmbH (Markus Brandt confirmed fleet capacity)." % fd("2027-07-01"),
         "Feasibility = feasible with conditions.",
         "Feasibility reviewer = Lotte Verhaegen")
    note("C-05", "C", 50, "crm.lead", C, "elif", "2026-03-05",
         "Finance: Kordis asks for 60-day payment terms. Maximum 45 days; credit insurance covers up to 1.2 M EUR.",
         "Payment terms 45 days in the offer.",
         "Finance input visible")
    note("C-06", "C", 60, "crm.lead", C, "sophie", "2026-06-12",
         "Offer submitted: 3.4 M EUR expected annual revenue, 60 months, price from the group costing model.",
         "Wait for the shortlist.",
         "Offer amount mentioned")
    note("C-07", "C", 70, "crm.lead", C, "sophie", "2026-10-28",
         "Best and final round. Kordis wants an index clause on diesel and energy and a 5-year term. Our BAFO baseline is "
         "3.2 M EUR per year, held as the draft quotation. Probability 60 percent.",
         "Next action: commercial validation call on the index clause with Elif (Finance).",
         "Stage Negotiation, probability 60, weighted 1,920,000")
    activity("C-08", "C", 80, "crm.lead", C, "sophie", 3,
             "BAFO call with Kordis procurement: index clause",
             "Agree the diesel/energy index formula with Finance before the call.", "mail.mail_activity_data_call")
    activity("C-09", "C", 90, "crm.lead", C, "thomas", 10,
             "Confirm environmental permit scope for bale storage (Hall 5)", "Condition of the offer.")

    # ---------------- Story D ----------------
    D1, D2 = "lg_opp_d1", "lg_opp_d2"
    note("D-01", "D", 10, "crm.lead", D1, "ruben", "2026-06-30",
         "Contract ends %s. This renewal covers the current scope only: 9,000 pallet positions plus bagging. Current "
         "run-rate 1.38 M EUR; renewed price with 3.5 percent indexation 1.43 M EUR. Revenue type: Retained." % fd("2026-12-31"),
         "Renewal opportunity created six months before expiry.",
         "Revenue type Retained (renewal)")
    note("D-02", "D", 20, "crm.lead", D1, "ruben", "2026-09-10",
         "Halden asked for 2,000 extra positions and export container stuffing from 2027. That is NOT added to the "
         "renewal value: it is logged as a separate Expansion opportunity, so retained and new revenue are not double counted.",
         "Separate expansion opportunity created.",
         "Second opportunity for Halden exists with revenue type Expansion")
    note("D-03", "D", 30, "crm.lead", D1, "ruben", "2026-10-08",
         "Renewal signed for 36 months from %s. Retained annual revenue 1.43 M EUR. No handover needed: scope unchanged, "
         "Operations informed." % fd("2027-01-01"),
         "Won. Account development continues on the expansion opportunity.",
         "Stage Won, no handover required")
    note("D-04", "D", 40, "crm.lead", D2, "lotte", "2026-09-24",
         "Feasible with conditions: 2,000 positions free in Hall 2 from %s; container stuffing needs one extra FTE." % fd("2027-02-01"),
         "Feasibility = feasible with conditions.",
         "Feasibility reviewer = Lotte Verhaegen")
    note("D-05", "D", 50, "crm.lead", D2, "ruben", "2026-10-15",
         "Proposal sent: 340,000 EUR incremental annual revenue, co-terminating with the renewal.",
         "Follow-up call next week.",
         "Quotation total 340,000")
    activity("D-06", "D", 60, "crm.lead", D2, "ruben", 6,
             "Follow up on expansion proposal with Halden", "Check decision timing with Wim Goossens.", "mail.mail_activity_data_call")

    # ---------------- Supporting notes ----------------
    note("X-01", "X", 10, "res.partner", "lg_p_valcrest_be", "pieter", "2026-10-14",
         "Operational request: extra Saturday pick-ups for two weeks. Handled by planning in the transport system. "
         "Not an opportunity, so no pipeline record.",
         "No CRM action.",
         "Shows the boundary: not every request is an opportunity")
    note("X-02", "X", 20, "crm.lead", "lg_lead_l4", "pieter", "2026-10-20",
         "Lumora loads peak on Fridays; trucks wait up to 2 hours. They asked whether we can buffer about 400 pallets "
         "over the weekend. Raising it as a lead for Ruben.",
         "Ruben to qualify.",
         "Lead chatter shows the Operations signal")
    note("X-03", "X", 30, "crm.lead", "lg_opp_v6", "ruben", "2026-08-18",
         "Renewal of the bulk transport scope only. The warehousing deal won in June is a separate expansion and is "
         "not included here.",
         "No double counting between renewal and expansion.",
         "Note visible on the renewal")
    note("X-04", "X", 40, "crm.lead", "lg_opp_o2", "jonas", "2026-03-16",
         "Renewal lost to a competitor with a lower price. Retained revenue lost: 430,000 EUR per year. Account status "
         "set to Former customer.",
         "Lost reason Price. Win-back review in 12 months.",
         "Lost renewal visible in the retention report")
    note("X-05", "X", 50, "crm.lead", "lg_opp_wb", "amira", "2026-10-13",
         "Westbrook signed. Won, New business. Simple handover created for Transport Operations; not yet accepted, so "
         "Amira stays responsible.",
         "Pieter to accept the handover.",
         "Opportunity shows 'Awaiting Operations acceptance'")
    note("X-06", "X", 60, "project.task", "lg_task_wb", "amira", "2026-10-14",
         "Simple handover. Contact Ruud Jansen. About 900 silo loads a year from Terneuzen; start %s." % fd("2026-12-01"),
         "Transport Operations to accept.",
         "Task chatter shows the handover note")
    note("X-07", "X", 70, "crm.lead", "lg_opp_n3", "markus", "2026-08-26",
         "Nordwerk export volumes through Duisburg are growing; they store in third-party sheds. Possible warehousing "
         "opportunity next to our transport.",
         "Jonas to qualify; feasibility needed on Duisburg capacity.",
         "Signal raised by Markus Brandt")

    # Activities on the remaining open records (next actions)
    acts = [
        ("X-10", "lg_opp_v6", "ruben", 4, "Send final renewal contract for signature", "mail.mail_activity_data_todo"),
        ("X-11", "lg_opp_n3", "markus", 7, "Feasibility: Duisburg hall capacity from Q2", "mail.mail_activity_data_todo"),
        ("X-12", "lg_opp_au2", "camille", 8, "Proposal walkthrough with Aurelia", "mail.mail_activity_data_meeting"),
        ("X-13", "lg_opp_g3", "amira", 2, "Negotiate tank-cleaning surcharge with Grainfield", "mail.mail_activity_data_call"),
        ("X-14", "lg_opp_bk3", "amira", -9, "Call Bakeline about cross-dock volumes", "mail.mail_activity_data_call"),
        ("X-15", "lg_opp_r4", "thomas", 12, "Check fire-safety limits for bale storage", "mail.mail_activity_data_todo"),
        ("X-16", "lg_opp_brevik_ren", "ruben", 9, "Renewal proposal follow-up with Brevik", "mail.mail_activity_data_call"),
        ("X-17", "lg_opp_greenmill", "jonas", 15, "Send reference case for bale transport", "mail.mail_activity_data_email"),
        ("X-18", "lg_opp_durand", "camille", 5, "Follow-up call on proposal", "mail.mail_activity_data_call"),
        ("X-19", "lg_opp_tessaro", "pieter", 6, "Feasibility: tank availability for feed additives", "mail.mail_activity_data_todo"),
        ("X-20", "lg_lead_l1", "amira", 3, "Qualification call with Circulex", "mail.mail_activity_data_call"),
        ("X-21", "lg_lead_l2", "jonas", 5, "Qualify domestic volumes with Nordwerk Polska", "mail.mail_activity_data_call"),
        ("X-22", "lg_lead_l4", "ruben", 2, "Qualify Lumora buffer storage need", "mail.mail_activity_data_call"),
        ("X-23", "lg_lead_l5", "camille", 7, "Clarify Grenoble flows with Castellan", "mail.mail_activity_data_todo"),
    ]
    for i, (key, target, user, days, summary, typ) in enumerate(acts):
        activity(key, "X", 100 + i, "crm.lead", target, user, days, summary, "", typ)
    activity("X-30", "X", 200, "res.partner", "lg_t_polaris", "camille", 10,
             "First outreach: introduction call", "Target account selected in July; no contact yet.",
             "mail.mail_activity_data_call")
    activity("X-31", "X", 210, "project.task", "lg_task_wb", "pieter", 2,
             "Review and accept the Westbrook handover", "")

    # Proposal confirmations (won deals) - standard action_confirm()
    confirm("A-20", "A", 200, "lg_so_a")
    confirm("B-20", "B", 200, "lg_so_b")
    confirm("D-20", "D", 200, "lg_so_d1")
    confirm("X-40", "X", 300, "lg_so_wb")
    return items


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------
def write_csv(path, header, rows):
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh, quoting=csv.QUOTE_MINIMAL, lineterminator="\n")
        w.writerow(header)
        for r in rows:
            w.writerow(["" if v is None else v for v in r])
    return len(rows)


def b(v):
    return "True" if v else "False"


def build(out_dir, as_of):
    shift = as_of - BASE_AS_OF

    def d(s):
        return (dt.date.fromisoformat(s) + shift).isoformat() if s else ""

    def fd(s):
        return (dt.date.fromisoformat(s) + shift).strftime("%d %b %Y")

    os.makedirs(out_dir, exist_ok=True)
    counts = {}
    U = lambda k: "lg_user_" + k if k else ""
    CO = lambda k: "lg_co_" + k if k else ""
    TEAM = lambda k: "lg_team_" + k if k else ""
    P = lambda k: "lg_" + k if k else ""   # partner external ids: lg_p_..., lg_c_..., lg_s_..., lg_g_..., lg_t_...

    counts["01_res_company.csv"] = write_csv(
        os.path.join(out_dir, "01_res_company.csv"),
        ["id", "name", "street", "zip", "city", "country_id/id", "currency_id/id"],
        [[CO(k), n, s, z, c, cty, "base.EUR"] for k, n, s, z, c, cty in COMPANIES])

    counts["02_res_users.csv"] = write_csv(
        os.path.join(out_dir, "02_res_users.csv"),
        ["id", "name", "login", "function", "company_id/id", "company_ids/id", "group_ids/id",
         "notification_type", "tz"],
        [[U(k), n, login, fn, CO(dc), ",".join(CO(c) for c in cs), ",".join(gs), "inbox", "Europe/Brussels"]
         for k, n, login, fn, dc, cs, gs in USERS])

    counts["03_crm_team.csv"] = write_csv(
        os.path.join(out_dir, "03_crm_team.csv"),
        ["id", "name", "user_id/id", "company_id/id", "use_leads", "use_opportunities", "member_ids/id"],
        [[TEAM(k), n, U(lead), CO(co), "True", "True", ",".join(U(m) for m in mem)] for k, n, lead, co, mem in TEAMS])

    counts["04_crm_stage.csv"] = write_csv(
        os.path.join(out_dir, "04_crm_stage.csv"),
        ["id", "name", "sequence", "is_won", "fold", "requirements"],
        [[i, n, s, b(w), b(f), r] for i, n, s, w, f, r in STAGES])

    counts["05_crm_lost_reason.csv"] = write_csv(
        os.path.join(out_dir, "05_crm_lost_reason.csv"), ["id", "name"], [[i, n] for i, n in LOST_REASONS])

    counts["06_crm_tag.csv"] = write_csv(
        os.path.join(out_dir, "06_crm_tag.csv"), ["id", "name", "color"], [[i, n, c] for i, n, c in TAGS])

    counts["07a_res_partner_groups.csv"] = write_csv(
        os.path.join(out_dir, "07a_res_partner_groups.csv"),
        ["id", "name", "lg_is_customer_group", "lg_account_status", "lg_segment", "user_id/id",
         "city", "zip", "country_id/id"],
        [[P(k), n, "True", st, seg, U(o), c, z, cty] for k, n, c, z, cty, st, seg, o in GROUPS])

    counts["07b_res_partner_legal.csv"] = write_csv(
        os.path.join(out_dir, "07b_res_partner_legal.csv"),
        ["id", "name", "lg_customer_group_id/id", "lg_account_status", "lg_segment", "user_id/id",
         "city", "zip", "country_id/id", "email", "lg_target_since", "lg_first_contact_date"],
        [[P(k), n, P(par), st, seg, U(o), c, z, cty, "info@" + dom, d(ts), d(fc)]
         for k, n, par, c, z, cty, st, seg, o, ts, fc, dom in LEGAL])

    counts["07c_res_partner_sites.csv"] = write_csv(
        os.path.join(out_dir, "07c_res_partner_sites.csv"),
        ["id", "name", "type", "parent_id/id", "city", "zip", "country_id/id"],
        [[P(k), n, "delivery", P(par), c, z, cty] for k, n, par, c, z, cty in SITES])

    dom_of = {k: dom for k, n, par, c, z, cty, st, seg, o, ts, fc, dom in LEGAL}
    dom_of.update({k: "valcrest.example" for k, *_ in GROUPS if k == "g_valcrest"})

    def email(name, parent):
        return "%s@%s" % (name.lower().replace(" ", ".").replace("'", ""), dom_of.get(parent, "customer.example"))

    counts["07d_res_partner_contacts.csv"] = write_csv(
        os.path.join(out_dir, "07d_res_partner_contacts.csv"),
        ["id", "name", "type", "parent_id/id", "function", "email"],
        [[P(k), n, "contact", P(par), fn, email(n, par)] for k, n, par, fn in CONTACTS])

    counts["08_product_template.csv"] = write_csv(
        os.path.join(out_dir, "08_product_template.csv"),
        ["id", "name", "default_code", "type", "list_price", "sale_ok", "purchase_ok", "description_sale"],
        [[k, n, code, "service", "0", "True", "False",
          "Annual value estimate. Price is calculated outside Odoo in the costing model."] for k, code, n in PRODUCTS])

    counts["09_project_project.csv"] = write_csv(
        os.path.join(out_dir, "09_project_project.csv"),
        ["id", "name", "company_id/id"], [[k, n, CO(c)] for k, n, c in PROJECTS])

    counts["10_project_task_type.csv"] = write_csv(
        os.path.join(out_dir, "10_project_task_type.csv"),
        ["id", "name", "sequence", "fold", "lg_is_accepted_stage", "project_ids/id"],
        [[k, n, s, b(f), b(acc), ",".join(p[0] for p in PROJECTS)] for k, n, s, f, acc in TASK_STAGES])

    contact_info = {k: (n, par) for k, n, par, fn in CONTACTS}
    legal_names = {k: n for k, n, *_ in LEGAL}
    legal_names.update({k: n for k, n, *_ in GROUPS})

    opp_rows, lead_rows = [], []
    for o in LEADS:
        if o["outcome"] == "lead":
            if o["partner"]:
                cname, par = contact_info[o["partner"]]
                pname, mail = legal_names[par], email(cname, par)
            else:
                cname, pname, mail = "Mark Evans", "Orchard Chemicals Ltd", "m.evans@orchard-chem.example"
            lead_rows.append([
                o["key"], "lead", o["name"], P(o["partner"]), pname, cname, mail, U(o["owner"]), TEAM(o["team"]),
                CO(o["company"]), ",".join(o["tags"]), o["segment"], o["region"], o["rtype"], o["signal_source"],
                U(o["signal_user"]), d(o["signal_date"]), d(o["last_touch"])])
            continue
        opp_rows.append([
            o["key"], "opportunity", o["name"], P(o["partner"]), P(o["site"]), U(o["owner"]), TEAM(o["team"]),
            CO(o["company"]), STAGE_ID[o["stage"]], o["prob"], o["rev"], d(o["deadline"]),
            "False" if o["outcome"] == "lost" else "True", o["lost_reason"], ",".join(o["tags"]), o["priority"],
            o["segment"], o["region"], o["rtype"], o["signal_source"], U(o["signal_user"]), d(o["signal_date"]),
            o["feas"], U(o["feas_user"]), d(o["decision"]), d(o["last_touch"]), d(o["start"]),
            o["months"] or "", ",".join(CO(c) for c in o["delivering"] if c), o["description"]])
    counts["11a_crm_lead_opportunities.csv"] = write_csv(
        os.path.join(out_dir, "11a_crm_lead_opportunities.csv"),
        ["id", "type", "name", "partner_id/id", "lg_site_id/id", "user_id/id", "team_id/id", "company_id/id",
         "stage_id/id", "probability", "expected_revenue", "date_deadline", "active", "lost_reason_id/id",
         "tag_ids/id", "priority", "lg_segment", "lg_region", "lg_revenue_type", "lg_signal_source",
         "lg_signal_user_id/id", "lg_signal_date", "lg_feasibility_state", "lg_feasibility_user_id/id",
         "lg_decision_date", "lg_last_touch_date", "lg_contract_start", "lg_contract_months",
         "lg_delivering_company_ids/id", "description"],
        opp_rows)
    counts["11b_crm_lead_leads.csv"] = write_csv(
        os.path.join(out_dir, "11b_crm_lead_leads.csv"),
        ["id", "type", "name", "partner_id/id", "partner_name", "contact_name", "email_from", "user_id/id",
         "team_id/id", "company_id/id", "tag_ids/id", "lg_segment", "lg_region", "lg_revenue_type",
         "lg_signal_source", "lg_signal_user_id/id", "lg_signal_date", "lg_last_touch_date"],
        lead_rows)

    so_rows = []
    code_of = {key: code for key, code, _n in PRODUCTS}
    for k, partner, co, lead, owner, date, valid, ref, _confirm, lines in QUOTES:
        for i, (prod, desc, amount) in enumerate(lines):
            line_id = "%s_line_%d" % (k, i + 1)   # line external IDs make re-import idempotent
            if i == 0:
                so_rows.append([k, P(partner), CO(co), lead, U(owner), d(date) + " 09:00:00", d(valid), ref,
                                line_id, code_of[prod], desc, 1, amount])
            else:
                so_rows.append(["", "", "", "", "", "", "", "", line_id, code_of[prod], desc, 1, amount])
    counts["12_sale_order.csv"] = write_csv(
        os.path.join(out_dir, "12_sale_order.csv"),
        ["id", "partner_id/id", "company_id/id", "opportunity_id/id", "user_id/id", "date_order", "validity_date",
         "client_order_ref", "order_line/id", "order_line/product_id", "order_line/name", "order_line/product_uom_qty",
         "order_line/price_unit"], so_rows)
    counts["12_sale_order.csv"] = len(QUOTES)

    counts["13_project_task.csv"] = write_csv(
        os.path.join(out_dir, "13_project_task.csv"),
        ["id", "name", "project_id/id", "stage_id/id", "user_ids/id", "partner_id/id", "lg_lead_id/id",
         "lg_handover_type", "lg_accepted_by_id/id", "lg_accepted_date", "lg_go_live_date", "description"],
        [[k, n, proj, st, ",".join(U(u) for u in users), P(partner), lead, typ, U(acc), d(accd), d(gl), desc]
         for k, n, proj, st, users, partner, lead, typ, acc, accd, gl, desc in TASKS])

    counts["14_project_subtask.csv"] = write_csv(
        os.path.join(out_dir, "14_project_subtask.csv"),
        ["id", "name", "parent_id/id", "project_id/id", "stage_id/id", "user_ids/id"],
        [[k, n, par, "lg_proj_ho_wh", "lg_tstage_live", U(u)] for k, n, par, u in SUBTASKS])

    items = story_items(fd)
    item_rows = []
    for it in items:
        item_rows.append([it["id"], it["name"], it["story"], it["sequence"], it["kind"], it["target_model"],
                          it["target_xmlid"], it.get("role", ""), d(it.get("business_date", "")), it.get("body", ""),
                          it.get("decision", ""), it.get("verification", ""), it.get("activity_type_xmlid", ""),
                          it.get("activity_summary", ""), it.get("activity_user_xmlid", ""),
                          it.get("activity_deadline_days", "")])
    counts["90_demo_story_items.csv"] = write_csv(
        os.path.join(out_dir, "90_demo_story_items.csv"),
        ["id", "name", "story", "sequence", "kind", "target_model", "target_xmlid", "role", "business_date",
         "body", "decision", "verification", "activity_type_xmlid", "activity_summary", "activity_user_xmlid",
         "activity_deadline_days"], item_rows)

    return dict(counts=counts, shift_days=shift.days, items=items, d=d)


# ---------------------------------------------------------------------------
# Expected results (pure Python, derived from the same records)
# ---------------------------------------------------------------------------
def expected_results(d):
    opps = [o for o in LEADS if o["outcome"] != "lead"]
    open_ = [o for o in opps if o["outcome"] == "open"]
    won = [o for o in opps if o["outcome"] == "won"]
    lost = [o for o in opps if o["outcome"] == "lost"]

    def weighted(o):
        return round(o["rev"] * o["prob"] / 100.0, 2)

    def pivot(records, row, col, measure):
        table = defaultdict(lambda: defaultdict(float))
        for o in records:
            table[row(o)][col(o)] += measure(o)
        return {r: dict(c) for r, c in table.items()}

    year = lambda o: d(o["decision"])[:4]
    res = {
        "counts": {"leads": sum(1 for o in LEADS if o["outcome"] == "lead"), "opportunities": len(opps),
                   "open": len(open_), "won": len(won), "lost": len(lost)},
        "R1_open_stage_x_segment_expected": pivot(open_, lambda o: STAGE_LABEL[o["stage"]], lambda o: SEGMENT_LABEL[o["segment"]], lambda o: o["rev"]),
        "R1_open_stage_x_segment_weighted": pivot(open_, lambda o: STAGE_LABEL[o["stage"]], lambda o: SEGMENT_LABEL[o["segment"]], weighted),
        "R2_open_segment_x_rtype_weighted": pivot(open_, lambda o: SEGMENT_LABEL[o["segment"]], lambda o: RTYPE_LABEL[o["rtype"]], weighted),
        "R2_open_segment_x_rtype_expected": pivot(open_, lambda o: SEGMENT_LABEL[o["segment"]], lambda o: RTYPE_LABEL[o["rtype"]], lambda o: o["rev"]),
        "R3_open_region_x_rtype_weighted": pivot(open_, lambda o: REGION_LABEL[o["region"]], lambda o: RTYPE_LABEL[o["rtype"]], weighted),
        "R4_won_year_x_rtype_expected": pivot(won, year, lambda o: RTYPE_LABEL[o["rtype"]], lambda o: o["rev"]),
        "R4_won_year_x_rtype_count": pivot(won, year, lambda o: RTYPE_LABEL[o["rtype"]], lambda o: 1),
        "R4_won_year_tcv": pivot(won, year, lambda o: "TCV", lambda o: o["rev"] * o["months"] / 12.0),
        "R5_lost_year_x_reason_expected": pivot(lost, year, lambda o: LOST_REASON_NAME[o["lost_reason"]], lambda o: o["rev"]),
        "R6_renewals_year_x_status_expected": pivot([o for o in won + lost if o["rtype"] == "retained"], year,
                                                   lambda o: "Won" if o["outcome"] == "won" else "Lost", lambda o: o["rev"]),
        "R8_open_owner_x_stage_expected": pivot(open_, lambda o: USER_NAME[o["owner"]], lambda o: STAGE_LABEL[o["stage"]], lambda o: o["rev"]),
        "totals": {
            "open_expected": sum(o["rev"] for o in open_),
            "open_weighted": round(sum(weighted(o) for o in open_), 2),
            "won_expected": sum(o["rev"] for o in won),
            "lost_expected": sum(o["rev"] for o in lost),
        },
    }
    # customer group (won + open)
    legal_parent = {k: par for k, n, par, *_ in LEGAL}
    contact_parent = {k: par for k, n, par, fn in CONTACTS}
    group_name = {k: n for k, n, *_ in GROUPS}
    legal_name = {k: n for k, n, *_ in LEGAL}

    def group_of(o):
        legal = contact_parent.get(o["partner"], o["partner"])
        grp = legal_parent.get(legal) or legal
        return group_name.get(grp) or legal_name.get(grp)

    cutoff = (lambda a: a.replace(year=a.year - 1))(dt.date.fromisoformat(d(BASE_AS_OF.isoformat())))
    recent_won = [o for o in won if dt.date.fromisoformat(d(o["decision"])) >= cutoff]
    res["R7_cutoff_won_decision_from"] = cutoff.isoformat()
    res["R7_group_x_entity_expected"] = pivot(recent_won + open_, group_of,
                                              lambda o: COMPANY_NAME[o["company"]], lambda o: o["rev"])
    res["valcrest_group_by_entity"] = res["R7_group_x_entity_expected"].get("Valcrest Polymers Group")
    # filters
    res["F_targets_awaiting_first_action"] = sorted(n for k, n, par, c, z, cty, st, seg, o, ts, fc, dom in LEGAL
                                                    if st == "target" and not fc)
    res["F_feasibility_needed"] = sorted(o["name"] for o in open_ if o["feas"] in ("requested", "in_review"))
    res["F_raised_by_operations_open_and_leads"] = sorted(o["name"] for o in LEADS
                                                          if o["signal_source"] == "operations" and o["outcome"] in ("open", "lead"))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(os.path.dirname(__file__), "..", "import"))
    ap.add_argument("--as-of", default=BASE_AS_OF.isoformat(), help="Planned installation date (YYYY-MM-DD)")
    ap.add_argument("--expected", default="", help="Write expected results JSON to this path")
    args = ap.parse_args()
    as_of = dt.date.fromisoformat(args.as_of)
    result = build(args.out, as_of)
    exp = expected_results(result["d"])
    exp["as_of"] = as_of.isoformat()
    exp["shift_days"] = result["shift_days"]
    if args.expected:
        with open(args.expected, "w", encoding="utf-8") as fh:
            json.dump(exp, fh, indent=2, ensure_ascii=False)
    print(json.dumps({"files": result["counts"], "shift_days": result["shift_days"],
                      "totals": exp["totals"], "counts": exp["counts"]}, indent=2))


if __name__ == "__main__":
    main()
