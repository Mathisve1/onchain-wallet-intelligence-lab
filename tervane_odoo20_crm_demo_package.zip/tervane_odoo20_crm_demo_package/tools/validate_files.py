#!/usr/bin/env python3
"""File-level validation of the import package (no Odoo needed).

Checks: unique external IDs, every /id reference resolves (inside the package or to a
known standard Odoo ID), quotation totals = opportunity annual revenue, register
targets exist, fictional-data rules (only .example e-mail domains, no phone, no VAT).
Usage: python3 validate_files.py ../import
"""
import csv
import os
import re
import sys
from collections import defaultdict

STANDARD_PREFIXES = ("base.", "crm.", "sales_team.", "project.", "mail.")
IMPORT_DIR = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "import")
problems, info = [], []

files = sorted(f for f in os.listdir(IMPORT_DIR) if f.endswith(".csv"))
ids_by_file, all_ids = {}, set()
rows_by_file = {}
for f in files:
    with open(os.path.join(IMPORT_DIR, f), encoding="utf-8") as fh:
        rows = list(csv.DictReader(fh))
    rows_by_file[f] = rows
    ids = [r["id"] for r in rows if r.get("id")]
    if len(ids) != len(set(ids)):
        problems.append(f"{f}: duplicate external IDs")
    for i in ids:
        if "." not in i and i in all_ids:
            problems.append(f"{f}: external ID {i} also used in another file")
    ids_by_file[f] = ids
    all_ids.update(i for i in ids if "." not in i)
    # line ids of sale orders
    for r in rows:
        if r.get("order_line/id"):
            all_ids.add(r["order_line/id"])

# references
for f, rows in rows_by_file.items():
    for r in rows:
        for col, val in r.items():
            if not col.endswith("/id") or col in ("id", "order_line/id") or not val:
                continue
            for ref in val.split(","):
                ref = ref.strip()
                if ref.startswith(STANDARD_PREFIXES):
                    continue
                if ref not in all_ids:
                    problems.append(f"{f}: {col} -> unknown external ID {ref}")
info.append(f"{len(files)} files, {sum(len(v) for v in ids_by_file.values())} records with external IDs")

# products referenced by code in quotations
codes = {r["default_code"] for r in rows_by_file.get("08_product_template.csv", [])}
for r in rows_by_file.get("12_sale_order.csv", []):
    if r["order_line/product_id"] not in codes:
        problems.append(f"12_sale_order.csv: unknown product code {r['order_line/product_id']}")

# quotation totals vs opportunity annual revenue
opp_rev = {r["id"]: float(r["expected_revenue"] or 0) for r in rows_by_file["11a_crm_lead_opportunities.csv"]}
totals, current = defaultdict(float), None
opp_of = {}
for r in rows_by_file["12_sale_order.csv"]:
    if r["id"]:
        current = r["id"]
        opp_of[current] = r["opportunity_id/id"]
    totals[current] += float(r["order_line/price_unit"]) * float(r["order_line/product_uom_qty"])
for so, tot in totals.items():
    if abs(tot - opp_rev[opp_of[so]]) > 0.005:
        problems.append(f"{so}: quotation total {tot} != opportunity annual revenue {opp_rev[opp_of[so]]}")
info.append(f"{len(totals)} quotations reconcile with their opportunity's expected annual revenue")

# register targets
for r in rows_by_file["90_demo_story_items.csv"]:
    t = r["target_xmlid"].replace("__import__.", "")
    if t not in all_ids:
        problems.append(f"90: {r['name']} target {t} not in the package")
    u = r.get("activity_user_xmlid", "").replace("__import__.", "")
    if u and u not in all_ids:
        problems.append(f"90: {r['name']} assignee {u} not in the package")
info.append("register targets and assignees resolve")

# fictional-data rules
email_re = re.compile(r"[\w.+-]+@([\w.-]+)")
for f, rows in rows_by_file.items():
    for r in rows:
        for col, val in r.items():
            if col in ("phone", "mobile", "vat") and val:
                problems.append(f"{f}: {col} filled ({val})")
            for m in email_re.finditer(val or ""):
                if not m.group(1).endswith(".example"):
                    problems.append(f"{f}: e-mail outside .example: {m.group(0)}")
info.append("only .example e-mail domains, no phone numbers, no Tax IDs")

# opportunity rules
for r in rows_by_file["11a_crm_lead_opportunities.csv"]:
    if r["stage_id/id"] == "crm.stage_lead4" and r["probability"] != "100":
        problems.append(f"{r['id']}: won but probability {r['probability']}")
    if r["active"] == "False" and (r["probability"] != "0" or not r["lost_reason_id/id"]):
        problems.append(f"{r['id']}: lost without probability 0 / lost reason")
    if r["active"] == "True" and r["stage_id/id"] != "crm.stage_lead4" and not (0 < float(r["probability"]) < 100):
        problems.append(f"{r['id']}: open with probability {r['probability']}")
    if r["active"] == "True" and r["stage_id/id"] != "crm.stage_lead4" and r["lg_decision_date"]:
        problems.append(f"{r['id']}: open deal with a decision date")
    if not r["lg_revenue_type"] or not r["lg_segment"] or not r["lg_region"]:
        problems.append(f"{r['id']}: missing segment / region / revenue type")
info.append("won = 100 %, lost = 0 % with reason, open between 0 and 100 %, every deal classified")

print("\n".join("OK   " + i for i in info))
print("\n".join("FAIL " + p for p in problems) if problems else "No problems found.")
sys.exit(1 if problems else 0)
