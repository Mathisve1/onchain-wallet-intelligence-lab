"""Browser smoke test (Playwright, headless Chromium) against a local Odoo 20 server.

Checks what a presenter will actually see: chatter Log notes on story records,
Commercial Journey tab, shared favourites in the pivot, partner filters, the live
'Accept Handover' button and lead conversion. Writes screenshots + JSON results.
Usage: python3 ui_smoke_test.py http://localhost:8069 admin admin <out_dir> <ids.json>
"""
import json
import re
import sys

from playwright.sync_api import sync_playwright

BASE, LOGIN, PWD, OUT, IDS = sys.argv[1:6]
ids = json.load(open(IDS))
results = []


def rec(name, ok, detail=""):
    results.append({"check": name, "ok": bool(ok), "detail": detail})
    print(("PASS " if ok else "FAIL ") + name, detail if not ok else "")


def open_panel(page):
    panel = page.locator(".o_search_bar_menu")
    if not panel.count() or not panel.first.is_visible():
        page.click(".o_searchview_dropdown_toggler")
    page.wait_for_selector(".o_search_bar_menu", timeout=15000)
    page.wait_for_timeout(400)


def close_panel(page):
    if page.locator(".o_search_bar_menu").count():
        page.keyboard.press("Escape")
        try:
            page.wait_for_selector(".o_search_bar_menu", state="detached", timeout=5000)
        except Exception:
            page.mouse.click(5, 900)
    page.wait_for_timeout(1500)


def pivot_text_fn(page):
    page.wait_for_selector(".o_pivot table", timeout=30000)
    return page.locator(".o_pivot table").inner_text()


def field_text(page, name):
    loc = page.locator(f'.o_form_sheet div[name="{name}"]').first
    if loc.locator("select").count():
        return loc.locator("select").evaluate("s => s.options[s.selectedIndex].text")
    if loc.locator("input").count():
        return loc.locator("input").first.input_value()
    return loc.inner_text()


def click_fav(page, name):
    open_panel(page)
    loc = page.get_by_text(name)
    if not loc.count():
        page.get_by_text("More...").first.click()
        page.wait_for_timeout(500)
        loc = page.get_by_text(name)
    loc.first.click()
    page.wait_for_timeout(2000)
    close_panel(page)


def set_all_companies(ctx, company_ids):
    # Same effect as ticking every company in the company switcher
    ctx.add_cookies([{"name": "cids", "value": "-".join(str(c) for c in company_ids), "url": BASE}])


def shot(page, name):
    page.screenshot(path=f"{OUT}/{name}.png", full_page=False)


with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1500, "height": 950}, locale="en-US", timezone_id="Europe/Brussels")
    page = ctx.new_page()
    page.goto(f"{BASE}/web/login")
    page.fill("input[name=login]", LOGIN)
    page.fill("input[name=password]", PWD)
    page.click("button[type=submit]")
    page.wait_for_selector(".o_main_navbar", timeout=60000)
    set_all_companies(ctx, ids["company_ids"])

    # 1. Story A opportunity: chatter + Commercial Journey tab
    page.goto(f"{BASE}/odoo/action-crm.crm_lead_action_pipeline/{ids['lg_opp_a']}")
    page.wait_for_selector(".o_form_view", timeout=60000)
    page.wait_for_selector(".o-mail-Message", timeout=60000)
    page.wait_for_timeout(1500)
    chatter = page.inner_text(".o-mail-Chatter")
    rec("A: chatter shows Operations signal note (A-01)", "[demo-note A-01]" in chatter and "Signal from Operations" in chatter)
    rec("A: chatter shows acceptance-relevant notes A-08/A-09 and next step A-12",
        all(f"[demo-note A-{n:02d}]" in chatter for n in (8, 9, 12)))
    rec("A: notes display as internal notes (Log note), not sent messages",
        page.locator(".o-mail-Message").count() >= 10)
    shot(page, "01_story_a_opportunity_chatter")
    page.get_by_role("tab", name="Commercial Journey").click()
    page.wait_for_timeout(800)
    form_text = page.inner_text(".o_form_sheet")
    for fname, value in [("lg_signal_user_id", "Pieter Vandaele"), ("lg_feasibility_user_id", "Lotte Verhaegen"),
                         ("lg_customer_group_id", "Valcrest Polymers Group"), ("lg_handover_accepted_by_id", "Lotte Verhaegen"),
                         ("lg_revenue_type", "Expansion"), ("lg_signal_source", "Operations"),
                         ("lg_feasibility_state", "Feasible with conditions"), ("user_id", "Ruben Daelman")]:
        got = field_text(page, fname)
        rec(f"A: form shows {fname} = {value}", value in got, got)
    rec("A: TCV 5,550,000 visible", "5,550,000" in form_text)
    rec("A: expected annual revenue label relabelled", "Expected Annual Revenue" in page.inner_text(".o_form_view") or "1,850,000" in page.inner_text(".o_form_view"))
    shot(page, "02_story_a_commercial_journey_tab")

    # 2. Handover task of story A (detailed) and its notes
    page.goto(f"{BASE}/odoo/action-project.action_view_all_task/{ids['lg_task_a']}")
    page.wait_for_selector(".o_form_view", timeout=60000)
    page.wait_for_selector(".o-mail-Message", timeout=60000)
    page.wait_for_timeout(1000)
    chatter = page.inner_text(".o-mail-Chatter")
    rec("A: handover task chatter shows content (A-10) and acceptance (A-11)",
        "[demo-note A-10]" in chatter and "[demo-note A-11]" in chatter)
    shot(page, "03_story_a_handover_task")

    # 3. Management favourite in pivot
    page.goto(f"{BASE}/odoo/action-logistics_crm_demo.action_lg_commercial_reporting")
    page.wait_for_selector(".o_pivot", timeout=60000)
    open_panel(page)
    fav = page.get_by_text("Mgmt 1 - Weighted forecast by segment x revenue type")
    rec("Favourites listed in search panel", fav.count() >= 1)
    fav.first.click()
    page.wait_for_timeout(2000)
    close_panel(page)
    pivot_text = pivot_text_of = pivot_text_fn(page)
    rec("Mgmt 1 pivot rendered with segments and revenue types",
        all(s in pivot_text for s in ("Polyolefins", "Food & Feed", "Circular Polymers", "Retained (renewal)", "Expansion", "New business")),
        pivot_text[:300])
    rec("Mgmt 1 pivot total weighted forecast 5,638,000", "5,638,000" in pivot_text, pivot_text[-400:])
    shot(page, "04_mgmt1_weighted_forecast_pivot")

    click_fav(page, "Mgmt 3 - Won by decision year x revenue type")
    pivot_text = pivot_text_fn(page)
    rec("Mgmt 3 pivot shows business years 2023-2026", all(y in pivot_text for y in ("2023", "2024", "2025", "2026")), pivot_text[:300])
    rec("Mgmt 3 total won annual revenue 19,090,000", "19,090,000" in pivot_text, pivot_text[-300:])
    shot(page, "05_mgmt3_won_by_year_pivot")

    click_fav(page, "Mgmt 5 - Customer group x contracting entity (open + won last 12 months)")
    pt = pivot_text_fn(page)
    rec("Mgmt 5 (behind 'More...') shows Valcrest group across 3 entities",
        "Valcrest Polymers Group" in pt and all(c in pt for c in ("Tervane Transport NV", "Tervane Warehousing NV", "Tervane Logistik GmbH")),
        pt[:300])
    rec("Mgmt 5: Valcrest group total 5,850,000 (open + won last 12 months, no period double count)", "5,850,000" in pt)
    shot(page, "05b_mgmt5_customer_group_entity_pivot")

    # 4. Pipeline search filter in kanban
    page.goto(f"{BASE}/odoo/action-crm.crm_lead_action_pipeline")
    page.wait_for_selector(".o_kanban_view", timeout=60000)
    while page.locator(".o_facet_remove").count():   # remove the default 'My Opportunities' facet
        page.locator(".o_facet_remove").first.click()
        page.wait_for_timeout(600)
    open_panel(page)
    page.get_by_text("Feasibility Input Needed").first.click()
    page.wait_for_timeout(1500)
    close_panel(page)
    k = page.inner_text(".o_kanban_view")
    rec("Pipeline filter 'Feasibility Input Needed' shows the 4 expected cards",
        all(n in k for n in ("Nordwerk - warehousing Duisburg", "Castellan - consignment", "Bakeline - cross-dock", "Tessaro Feed"))
        and "Kordis" not in k, k[:400])
    shot(page, "06_pipeline_feasibility_filter")

    # 5. Contacts: target accounts awaiting first action
    page.goto(f"{BASE}/odoo/action-contacts.action_contacts")
    page.wait_for_selector(".o_kanban_view, .o_list_view", timeout=60000)
    open_panel(page)
    page.get_by_text("Target Accounts Awaiting First Action").first.click()
    page.wait_for_timeout(1500)
    close_panel(page)
    t = page.inner_text(".o_content")
    rec("Contacts filter 'Target Accounts Awaiting First Action' = 4 targets",
        all(n in t for n in ("Sunvale", "Polaris", "Hexley", "Fenwick")) and "Brightwater" not in t, t[:400])
    shot(page, "07_contacts_targets_awaiting")

    # 6. Customer group form
    page.goto(f"{BASE}/odoo/action-contacts.action_contacts/{ids['lg_g_valcrest']}")
    page.wait_for_selector(".o_form_view", timeout=60000)
    page.get_by_role("tab", name="Account Development").click()
    page.wait_for_timeout(800)
    t = page.inner_text(".o_form_sheet")
    rec("Customer group form lists 3 legal customers",
        all(n in t for n in ("Valcrest Polymers Belgium NV", "Valcrest Polymers Deutschland GmbH", "Valcrest Compounds BV")))
    shot(page, "08_customer_group_form")

    # 7. Live action: accept Westbrook handover
    page.goto(f"{BASE}/odoo/action-project.action_view_all_task/{ids['lg_task_wb']}")
    page.wait_for_selector(".o_form_view", timeout=60000)
    btn = page.get_by_role("button", name="Accept Handover")
    rec("Westbrook task shows 'Accept Handover' button", btn.count() == 1)
    if btn.count():
        btn.click()
        page.wait_for_timeout(2500)
        chatter = page.inner_text(".o-mail-Chatter")
        rec("Accept Handover posts a real-time note by the current user", "Handover accepted by" in chatter)
        shot(page, "09_live_accept_handover")

    # 8. Live action: convert Operations lead L4 to opportunity
    page.goto(f"{BASE}/odoo/action-crm.crm_lead_all_leads/{ids['lg_lead_l4']}")
    page.wait_for_selector(".o_form_view", timeout=60000)
    conv = page.get_by_role("button", name=re.compile("Convert to Opportunity", re.I))
    rec("Lead L4 shows 'Convert to Opportunity'", conv.count() >= 1)
    if conv.count():
        conv.first.click()
        page.wait_for_timeout(2500)
        if page.locator(".o_dialog").count():   # wizard only when no customer is linked
            shot(page, "10_live_convert_lead_wizard")
            page.locator(".o_dialog footer button.btn-primary").first.click()
            page.wait_for_timeout(2500)
        chatter = page.inner_text(".o-mail-Chatter")
        rec("Lead L4 converted live to an opportunity (tracked Lead -> Opportunity)", "Opportunity" in chatter and "Lead" in chatter)
        shot(page, "11_live_converted_opportunity")

    # 8b. Live capture: kanban quick create of an opportunity with minimal data
    page.goto(f"{BASE}/odoo/action-crm.crm_lead_action_pipeline")
    page.wait_for_selector(".o_kanban_view", timeout=60000)
    page.locator(".o_kanban_group").first.locator(".o_kanban_quick_add").click()
    page.wait_for_selector(".o_kanban_quick_create", timeout=15000)
    qc = page.locator(".o_kanban_quick_create")
    qc.locator('div[name="name"] input').fill("LIVE DEMO - Valcrest Koeln storage (delete after demo)")
    if qc.locator('div[name="expected_revenue"] input').count():
        qc.locator('div[name="expected_revenue"] input').fill("400000")
    shot(page, "13_live_quick_create")
    qc.get_by_role("button", name=re.compile("^Add$")).click()
    page.wait_for_timeout(2000)
    rec("Live capture: quick-created opportunity appears in the New column",
        "LIVE DEMO - Valcrest Koeln storage" in page.locator(".o_kanban_group").first.inner_text())

    # 9. Access: a GmbH-only user sees only GmbH deals of the Valcrest group
    if ids.get("jonas_pwd"):
        ctx2 = browser.new_context(viewport={"width": 1500, "height": 950}, locale="en-US")
        pg = ctx2.new_page()
        pg.goto(f"{BASE}/web/login")
        pg.fill("input[name=login]", "jonas.kessler")
        pg.fill("input[name=password]", ids["jonas_pwd"])
        pg.click("button[type=submit]")
        pg.wait_for_selector(".o_main_navbar", timeout=60000)
        pg.goto(f"{BASE}/odoo/action-crm.crm_lead_action_pipeline?view_type=list")
        pg.wait_for_selector(".o_list_view, .o_kanban_view", timeout=60000)
        while pg.locator(".o_facet_remove").count():
            pg.locator(".o_facet_remove").first.click()
            pg.wait_for_timeout(600)
        pg.locator(".o_searchview_input").fill("Valcrest")
        pg.wait_for_timeout(800)
        pg.keyboard.press("Enter")
        pg.wait_for_timeout(2000)
        body = pg.inner_text(".o_content")
        rec("Access: Jonas (GmbH only) sees no Transport/Warehousing Valcrest deals (open pipeline, all owners)",
            "Valcrest Belgium - bulk transport renewal" not in body and "Valcrest Deutschland" in body, body[:400])
        shot(pg, "12_access_jonas_gmbh_only")
        ctx2.close()

    browser.close()

json.dump(results, open(f"{OUT}/ui_results.json", "w"), indent=2)
print(json.dumps({"passed": sum(r["ok"] for r in results), "total": len(results)}))
