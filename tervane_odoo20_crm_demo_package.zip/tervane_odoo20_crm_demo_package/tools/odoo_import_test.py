# Run inside: odoo-bin shell -c <conf> -d <db> --no-http < odoo_import_test.py
# Test harness: imports the package CSVs through base_import (same server path as
# the Import button: parse_preview + execute_import, test run first), as the
# admin user, with all demo companies active. Writes a JSON report.
import base64
from odoo.tools.binary import BinaryBytes
import json
import os
import sys
import time

PKG = os.environ.get("LG_PKG", "/home/claude/pkg")
IMPORT_DIR = os.path.join(PKG, "import")
REPORT = os.environ.get("LG_REPORT", "/tmp/lg_import_report.json")
ONLY = os.environ.get("LG_ONLY", "")
RERUN = os.environ.get("LG_RERUN", "") == "1"   # re-import test: users file is skipped (see install guide)

SEQUENCE = [
    ("01_res_company.csv", "res.company"),
    ("02_res_users.csv", "res.users"),
    ("03_crm_team.csv", "crm.team"),
    ("04_crm_stage.csv", "crm.stage"),
    ("05_crm_lost_reason.csv", "crm.lost.reason"),
    ("06_crm_tag.csv", "crm.tag"),
    ("07a_res_partner_groups.csv", "res.partner"),
    ("07b_res_partner_legal.csv", "res.partner"),
    ("07c_res_partner_sites.csv", "res.partner"),
    ("07d_res_partner_contacts.csv", "res.partner"),
    ("08_product_template.csv", "product.template"),
    ("09_project_project.csv", "project.project"),
    ("10_project_task_type.csv", "project.task.type"),
    ("11a_crm_lead_opportunities.csv", "crm.lead"),
    ("11b_crm_lead_leads.csv", "crm.lead"),
    ("12_sale_order.csv", "sale.order"),
    ("13_project_task.csv", "project.task"),
    ("14_project_subtask.csv", "project.task"),
    ("90_demo_story_items.csv", "lg.demo.story.item"),
]

OPTIONS = {
    "has_headers": True, "separator": ",", "quoting": '"', "encoding": "utf-8",
    "date_format": "%Y-%m-%d", "datetime_format": "%Y-%m-%d %H:%M:%S",
    "float_thousand_separator": ",", "float_decimal_separator": ".",
    "import_skip_records": [], "import_set_empty_fields": [], "fallback_values": {},
    "name_create_enabled_fields": {}, "limit": 2000, "skip": 0, "advanced": True,
}

admin = env.ref("base.user_admin")
report = {"steps": []}
if os.path.exists(REPORT):
    os.remove(REPORT)


def admin_env():
    companies = env["res.company"].sudo().search([])
    # tracking_disable=True mirrors the Odoo 20 import screen default ("Track changes in chatter" unticked)
    ctx = dict(env.context, allowed_company_ids=companies.ids, lang="en_US", tz="Europe/Brussels", tracking_disable=True)
    return env(user=admin.id, context=ctx)


def run_file(fname, model):
    aenv = admin_env()
    path = os.path.join(IMPORT_DIR, fname)
    with open(path, "rb") as fh:
        content = fh.read()
    imp = aenv["base_import.import"].create({"res_model": model, "file": BinaryBytes(content),
                                             "file_name": fname, "file_type": "text/csv"})
    preview = imp.parse_preview(dict(OPTIONS))
    if preview.get("error"):
        return {"file": fname, "model": model, "error": preview["error"]}
    headers = preview["headers"]
    matches = preview.get("matches", {})
    auto_mapped = [matches.get(i) and ".".join(matches[i]) if isinstance(matches.get(i), list) else matches.get(i)
                   for i in range(len(headers))]
    fields = headers  # technical headers
    t0 = time.time()
    dry = imp.execute_import(fields, headers, dict(OPTIONS), dryrun=True)
    dry_msgs = [m for m in dry.get("messages", []) if m.get("type") == "error"]
    step = {"file": fname, "model": model, "rows_dry_ok": len(dry.get("ids") or []),
            "dry_errors": dry_msgs[:10], "auto_mapping": dict(zip(headers, auto_mapped))}
    if not dry_msgs:
        imp2 = aenv["base_import.import"].create({"res_model": model, "file": BinaryBytes(content),
                                                  "file_name": fname, "file_type": "text/csv"})
        real = imp2.execute_import(fields, headers, dict(OPTIONS), dryrun=False)
        step["rows_imported"] = len(real.get("ids") or [])
        step["errors"] = [m for m in real.get("messages", []) if m.get("type") == "error"][:10]
        step["warnings"] = [m.get("message") for m in real.get("messages", []) if m.get("type") != "error"][:10]
    step["seconds"] = round(time.time() - t0, 2)
    env.cr.commit()
    return step


def pre_config():
    aenv = admin_env()
    settings = aenv["res.config.settings"].create({"group_use_lead": True})
    settings.execute()
    env.cr.commit()
    return {"leads_enabled": aenv.user.has_group("crm.group_use_lead")}


report["pre_config"] = pre_config() if not RERUN else "skipped (rerun)"
for fname, model in SEQUENCE:
    if ONLY and fname not in ONLY.split(","):
        continue
    if RERUN and fname == "02_res_users.csv":
        continue
    try:
        step = run_file(fname, model)
    except Exception as e:  # report and stop
        try:
            env.cr.rollback()
        except Exception:
            pass
        step = {"file": fname, "model": model, "exception": repr(e)}
        report["steps"].append(step)
        break
    report["steps"].append(step)
    if fname == "01_res_company.csv":
        # Same as ticking the new companies in the user's Allowed Companies (UI step in install guide)
        report["admin_companies_before_manual_step"] = admin.company_ids.mapped("name")
        new = env["res.company"].search([])
        admin.sudo().write({"company_ids": [(4, c.id) for c in new]})
        env.cr.commit()
        report["admin_companies_after_company_import"] = admin.company_ids.mapped("name")
    if step.get("dry_errors") or step.get("errors"):
        break

with open(REPORT, "w") as fh:
    json.dump(report, fh, indent=2, default=str)
print(json.dumps([{k: v for k, v in s.items() if k != "auto_mapping"} for s in report["steps"]], indent=1, default=str))
