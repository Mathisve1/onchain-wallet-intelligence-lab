# Run inside: odoo-bin shell -c <conf> -d <db> --no-http < odoo_verify.py
# Post-import validation: record checks, Log-note loader run + rerun, favourites
# reconciled with expected_results.json, multi-company access, side effects.
import ast
import json
import os
import sys
from collections import defaultdict

PKG = os.environ.get("LG_PKG", "/home/claude/pkg")
sys.path.insert(0, os.path.join(PKG, "tools"))
import build_demo_data as gen  # noqa: E402

REPORT = os.environ.get("LG_VERIFY_REPORT", "/tmp/lg_verify_report.json")
RUN_LOADER = os.environ.get("LG_RUN_LOADER", "1") == "1"
expected = json.load(open(os.path.join(PKG, "tools", "expected_results.json")))
as_of_shift = expected["shift_days"]

admin = env.ref("base.user_admin")
companies = env["res.company"].sudo().search([])
ctx = dict(env.context, allowed_company_ids=companies.ids, lang="en_US", tz="Europe/Brussels", active_test=False)
A = env(user=admin.id, context=ctx)
out = {"checks": [], "failures": []}


def check(name, ok, detail=None):
    out["checks"].append({"check": name, "ok": bool(ok), "detail": detail})
    if not ok:
        out["failures"].append({"check": name, "detail": detail})


def ref(xid):
    return A.ref("__import__." + xid, raise_if_not_found=False)


# ---------------------------------------------------------------- records
mail_before = A["mail.mail"].sudo().search_count([])
lead_fail = []
for o in gen.LEADS:
    rec = ref(o["key"])
    if not rec:
        lead_fail.append((o["key"], "missing"))
        continue
    exp_company = gen.COMPANY_NAME.get(o["company"], False)
    got = {
        "type": rec.type, "company": rec.company_id.name or False, "active": rec.active,
        "won_status": rec.won_status, "stage": rec.stage_id.name if o["outcome"] != "lead" else None,
        "prob": rec.probability if o["outcome"] != "lead" else None,
        "rev": rec.expected_revenue if o["outcome"] != "lead" else None,
        "owner": rec.user_id.name or False, "rtype": rec.lg_revenue_type or False,
    }
    want = {
        "type": "lead" if o["outcome"] == "lead" else "opportunity", "company": exp_company,
        "active": o["outcome"] != "lost",
        "won_status": {"won": "won", "lost": "lost"}.get(o["outcome"], "pending"),
        "stage": gen.STAGE_LABEL.get(o["stage"]) if o["outcome"] != "lead" else None,
        "prob": float(o["prob"]) if o["outcome"] != "lead" else None,
        "rev": float(o["rev"]) if o["outcome"] != "lead" else None,
        "owner": gen.USER_NAME.get(o["owner"], False), "rtype": o["rtype"] or False,
    }
    diff = {k: (got[k], want[k]) for k in want if got[k] != want[k]}
    if diff:
        lead_fail.append((o["key"], diff))
check("crm.lead: 56 records with expected type/company/stage/status/probability/revenue/owner/revenue type",
      not lead_fail, lead_fail[:15])

# customer structure
vbe = ref("lg_p_valcrest_be")
grp = ref("lg_g_valcrest")
isa = ref("lg_c_valcrest_be")
site = ref("lg_s_valcrest_antwerp")
check("Legal customer is its own commercial entity (not the group)", vbe.commercial_partner_id == vbe,
      vbe.commercial_partner_id.name)
check("Contact -> legal customer -> group chain",
      isa.commercial_partner_id == vbe and isa.lg_group_id == grp and site.lg_group_id == grp,
      [isa.commercial_partner_id.name, isa.lg_group_id.name, site.lg_group_id.name])
check("Customer group lists 3 legal customers", len(grp.lg_group_member_ids) == 3, grp.lg_group_member_ids.mapped("name"))
lead_a = ref("lg_opp_a")
check("Story A: customer group, legal customer, site on opportunity",
      lead_a.lg_customer_group_id == grp and lead_a.lg_legal_customer_id == vbe and lead_a.lg_site_id == site,
      [lead_a.lg_customer_group_id.name, lead_a.lg_legal_customer_id.name, lead_a.lg_site_id.name])
check("Story A: TCV = 1,850,000 x 36/12", abs(lead_a.lg_tcv - 5550000) < 0.01, lead_a.lg_tcv)
check("Story A: delivering entities = Warehousing + Transport",
      set(lead_a.lg_delivering_company_ids.mapped("name")) == {"Tervane Warehousing NV", "Tervane Transport NV"},
      lead_a.lg_delivering_company_ids.mapped("name"))
check("Story A: viewer can identify originator, owner, reviewer, revenue, accepter",
      lead_a.lg_signal_user_id.name == "Pieter Vandaele" and lead_a.user_id.name == "Ruben Daelman"
      and lead_a.lg_feasibility_user_id.name == "Lotte Verhaegen" and lead_a.expected_revenue == 1850000
      and lead_a.lg_handover_accepted_by_id.name == "Lotte Verhaegen",
      [lead_a.lg_signal_user_id.name, lead_a.user_id.name, lead_a.lg_feasibility_user_id.name,
       lead_a.expected_revenue, lead_a.lg_handover_accepted_by_id.name])
hs = {k: ref(k).lg_handover_state for k in ("lg_opp_a", "lg_opp_b", "lg_opp_wb", "lg_opp_d1")}
check("Handover states: A accepted, B accepted, Westbrook awaiting, D1 none",
      hs == {"lg_opp_a": "accepted", "lg_opp_b": "accepted", "lg_opp_wb": "awaiting", "lg_opp_d1": "none"}, hs)
task_a = ref("lg_task_a")
check("Story A detailed handover has 6 sub-tasks, company Warehousing NV",
      len(task_a.child_ids) == 6 and task_a.company_id.name == "Tervane Warehousing NV",
      [len(task_a.child_ids), task_a.company_id.name])
check("System dates are real (create_date = import time, not backdated)",
      lead_a.create_date.date() >= __import__("datetime").date.today() - __import__("datetime").timedelta(days=1),
      str(lead_a.create_date))
check("Native Closed Date of won deal = system time; business decision date separate",
      bool(lead_a.date_closed) and lead_a.lg_decision_date.isoformat() == gen.LEADS[13]["decision"] if as_of_shift == 0 else bool(lead_a.date_closed),
      [str(lead_a.date_closed), str(lead_a.lg_decision_date)])

# targets
awaiting = A["res.partner"].search([("lg_account_status", "=", "target"), ("lg_first_contact_date", "=", False)])
check("Filter: target accounts awaiting first action", sorted(awaiting.mapped("name")) == expected["F_targets_awaiting_first_action"],
      sorted(awaiting.mapped("name")))
check("Target accounts are not leads (no crm.lead on Sunvale/Polaris/Hexley/Fenwick)",
      A["crm.lead"].search_count([("partner_id", "child_of", awaiting.ids)]) == 0)

# ---------------------------------------------------------------- loader
Item = A["lg.demo.story.item"]
lead_ids_with_notes = {}
if RUN_LOADER:
    msgs_before = A["mail.message"].sudo().search_count([("subtype_id", "=", A.ref("mail.mt_note").id)])
    acts_before = A["mail.activity"].sudo().search_count([])
    Item.action_run_all_pending()
    env.cr.commit()
    states = defaultdict(int)
    for it in Item.search([]):
        states[it.state] += 1
    check("Loader run 1: all 65 register rows done", dict(states) == {"done": 65}, dict(states))
    msgs_after = A["mail.message"].sudo().search_count([("subtype_id", "=", A.ref("mail.mt_note").id)])
    acts_after = A["mail.activity"].sudo().search_count([])
    n_notes = Item.search_count([("kind", "=", "note")])
    n_acts = Item.search_count([("kind", "=", "activity")])
    check("Loader run 1: one internal note per note row", msgs_after - msgs_before == n_notes, [msgs_after - msgs_before, n_notes])
    check("Loader run 1: one activity per activity row", acts_after - acts_before == n_acts, [acts_after - acts_before, n_acts])
    # rerun
    Item.action_run_all_pending()
    Item.search([]).action_run()
    env.cr.commit()
    check("Loader rerun: no duplicate notes", A["mail.message"].sudo().search_count([("subtype_id", "=", A.ref("mail.mt_note").id)]) == msgs_after)
    check("Loader rerun: no duplicate activities", A["mail.activity"].sudo().search_count([]) == acts_after)
    # reset + rerun: marker prevents a second copy
    Item.search([("kind", "=", "note")]).action_reset_to_pending()
    Item.action_run_all_pending()
    env.cr.commit()
    check("Reset to pending + rerun: marker check links existing notes, no duplicates",
          A["mail.message"].sudo().search_count([("subtype_id", "=", A.ref("mail.mt_note").id)]) == msgs_after)

if not RUN_LOADER:
    states = defaultdict(int)
    for it in Item.search([]):
        states[it.state] += 1
    check("Loader (run beforehand from the UI menu): all 65 register rows done", dict(states) == {"done": 65}, dict(states))

loader_ran = RUN_LOADER or (Item.search_count([]) and not Item.search_count([("state", "!=", "done")]))

# note properties
note_rows = Item.search([("kind", "=", "note")])
bad = []
for it in note_rows:
    m = it.message_id
    if not m:
        bad.append((it.name, "no message"))
        continue
    rec = A[it.target_model].browse(it.res_id)
    if (m.model, m.res_id) != (rec._name, rec.id) or m.message_type != "comment" or m.subtype_id != A.ref("mail.mt_note") \
            or m.author_id != admin.partner_id or ("[demo-note %s]" % it.name) not in m.body:
        bad.append((it.name, m.model, m.res_id, m.message_type, m.subtype_id.name, m.author_id.name))
check("Every note: on the right record, type comment + subtype Note (= Log note), author = loader user, marker present",
      not bad, bad[:10])

# chronological order inside story A chatter (newest first in UI = highest id first)
a_items = note_rows.filtered(lambda i: i.target_model == "crm.lead" and i.target_xmlid.endswith("lg_opp_a")).sorted("sequence")
check("Story A opportunity notes posted in register order (A-01 oldest ... A-12 newest)",
      a_items.mapped("message_id").ids == sorted(a_items.mapped("message_id").ids), a_items.mapped("name"))
chatter_a = A["mail.message"].search([("model", "=", "crm.lead"), ("res_id", "=", lead_a.id)], order="id desc")
out["story_a_chatter"] = [{"id": m.id, "type": m.message_type, "subtype": m.subtype_id.name,
                           "author": m.author_id.name, "date": str(m.date),
                           "preview": (m.preview or "")[:110]} for m in chatter_a]
notes_a = chatter_a.filtered(lambda m: m.subtype_id == A.ref("mail.mt_note") and m.message_type == "comment")
others_a = chatter_a - notes_a
check("Story A chatter: 10 demo notes, each with marker; other messages carry no marker",
      len(notes_a) == 10 and all("[demo-note" in m.body for m in notes_a) and not any("[demo-note" in (m.body or "") for m in others_a),
      [len(notes_a), len(chatter_a), sorted(set(chatter_a.mapped("message_type")))])

# ---------------------------------------------------------------- proposals
for so_key, lead_key, exp_total, exp_state in [("lg_so_a", "lg_opp_a", 1850000, "sale"), ("lg_so_b", "lg_opp_b", 620000, "sale"),
                                               ("lg_so_c", "lg_opp_c", 3200000, "draft"), ("lg_so_d1", "lg_opp_d1", 1430000, "sale"),
                                               ("lg_so_d2", "lg_opp_d2", 340000, "draft"), ("lg_so_wb", "lg_opp_wb", 470000, "sale")]:
    so = ref(so_key)
    lead = ref(lead_key)
    ok = (so.amount_untaxed == exp_total and so.state == (exp_state if loader_ran else "draft")
          and so.opportunity_id == lead and lead.expected_revenue == exp_total and so.company_id == lead.company_id)
    check("Proposal %s: untaxed %s, state %s, linked, opportunity revenue unchanged" % (so_key, exp_total, exp_state),
          ok, [so.amount_untaxed, so.state, lead.expected_revenue, so.company_id.name])

# ---------------------------------------------------------------- favourites vs expected
def eval_filter(xid):
    f = A.ref("logistics_crm_demo." + xid)
    domain = ast.literal_eval(f.domain)
    context = ast.literal_eval(f.context)
    return f, domain, context


def to_label(field, value):
    if value is False or value is None:
        return "None"
    fobj = A["crm.lead"]._fields[field.split(":")[0]]
    if fobj.type == "selection":
        return dict(fobj._description_selection(A))[value]
    if fobj.type == "many2one":
        return value.display_name if hasattr(value, "display_name") else value
    if fobj.type in ("date", "datetime"):
        return str(value.year) if hasattr(value, "year") else str(value)
    return str(value)


def pivot_from_odoo(domain, row, col, measure):
    groups = A["crm.lead"].with_context(active_test=False)._read_group(domain, [row, col], [measure + ":sum"])
    table = defaultdict(lambda: defaultdict(float))
    for r, c, v in groups:
        rl = to_label(row, r)
        cl = to_label(col, c)
        if row.startswith("lost_reason_id") or col.startswith("lost_reason_id"):
            pass
        table[rl][cl] += v
    return {k: dict(v) for k, v in table.items()}


def stage_name(rec):
    return rec.name


def compare(name, odoo_table, exp_table):
    norm = lambda t: {r: {c: round(v, 2) for c, v in cs.items() if round(v, 2)} for r, cs in t.items()}
    a, b = norm(odoo_table), norm(exp_table)
    a = {k: v for k, v in a.items() if v}
    b = {k: v for k, v in b.items() if v}
    check(name, a == b, {"odoo": a, "expected": b} if a != b else None)


_, dom, _c = eval_filter("filter_lg_m6_open_stage_segment")
compare("Fav Mgmt 6: open expected annual revenue by stage x segment", pivot_from_odoo(dom, "stage_id", "lg_segment", "expected_revenue"),
        expected["R1_open_stage_x_segment_expected"])
compare("Fav Mgmt 6: open weighted revenue by stage x segment", pivot_from_odoo(dom, "stage_id", "lg_segment", "prorated_revenue"),
        expected["R1_open_stage_x_segment_weighted"])
_, dom, _c = eval_filter("filter_lg_m1_forecast_segment_type")
compare("Fav Mgmt 1: weighted forecast segment x revenue type", pivot_from_odoo(dom, "lg_segment", "lg_revenue_type", "prorated_revenue"),
        expected["R2_open_segment_x_rtype_weighted"])
_, dom, _c = eval_filter("filter_lg_m2_forecast_region_type")
compare("Fav Mgmt 2: weighted forecast region x revenue type", pivot_from_odoo(dom, "lg_region", "lg_revenue_type", "prorated_revenue"),
        expected["R3_open_region_x_rtype_weighted"])
_, dom, _c = eval_filter("filter_lg_m3_won_year_type")
compare("Fav Mgmt 3: won annual revenue by decision year x revenue type",
        pivot_from_odoo(dom, "lg_decision_date:year", "lg_revenue_type", "expected_revenue"), expected["R4_won_year_x_rtype_expected"])
tcv = pivot_from_odoo(dom, "lg_decision_date:year", "type", "lg_tcv")
compare("Fav Mgmt 3: won TCV by decision year", {y: {"TCV": sum(v.values())} for y, v in tcv.items()}, expected["R4_won_year_tcv"])
_, dom, _c = eval_filter("filter_lg_m8_lost_year_reason")
compare("Fav Mgmt 8: lost by decision year x reason", pivot_from_odoo(dom, "lg_decision_date:year", "lost_reason_id", "expected_revenue"),
        expected["R5_lost_year_x_reason_expected"])
_, dom, _c = eval_filter("filter_lg_m4_renewals_retention")
ren = pivot_from_odoo(dom, "lg_decision_date:year", "won_status", "expected_revenue")
compare("Fav Mgmt 4: renewals won vs lost by year", ren, expected["R6_renewals_year_x_status_expected"])
_, dom, _c = eval_filter("filter_lg_m5_group_entity")
compare("Fav Mgmt 5: customer group x contracting entity", pivot_from_odoo(dom, "lg_customer_group_id", "company_id", "expected_revenue"),
        expected["R7_group_x_entity_expected"])
_, dom, _c = eval_filter("filter_lg_m7_owner_stage")
compare("Fav Mgmt 7: open by owner x stage", pivot_from_odoo(dom, "user_id", "stage_id", "expected_revenue"),
        expected["R8_open_owner_x_stage_expected"])

# search-view filters (domains copied from the module XML, evaluated server side)
Lead = A["crm.lead"].with_context(active_test=True)
feas = Lead.search([("lg_feasibility_state", "in", ("requested", "in_review")), ("won_status", "=", "pending")])
check("Filter 'Feasibility input needed'", sorted(feas.mapped("name")) == expected["F_feasibility_needed"], sorted(feas.mapped("name")))
noact = Lead.search([("type", "=", "opportunity"), ("won_status", "=", "pending"), ("activity_ids", "=", False)])
check("Filter 'Open, no next action' = Castellan consignment only (after loader)" if loader_ran else "Filter 'Open, no next action' (before loader: all open)",
      (noact.mapped("name") == ["Castellan - consignment stock near Lyon"]) if loader_ran else len(noact) == 13, noact.mapped("name"))
stalled = Lead.search([("type", "=", "opportunity"), ("won_status", "=", "pending"), ("lg_last_touch_date", "<", "today -60d")])
out["stalled_today"] = sorted(stalled.mapped("name"))
ops = Lead.search([("lg_signal_source", "=", "operations"), ("won_status", "=", "pending")])
check("Filter 'Raised by Operations' (open opportunities + leads)", sorted(ops.mapped("name")) == expected["F_raised_by_operations_open_and_leads"],
      sorted(ops.mapped("name")))
awaiting_ho = Lead.search([("lg_handover_state", "=", "awaiting")])
check("Filter 'Won, awaiting handover acceptance' = Westbrook", awaiting_ho.mapped("name") == ["Westbrook Malt - malt silo transport Terneuzen"],
      awaiting_ho.mapped("name"))
late = Lead.search([("type", "=", "opportunity"), ("activity_ids.date_deadline", "<", "today")])
out["late_activity_opps"] = late.mapped("name")

# ---------------------------------------------------------------- access (multi-company)
def visible(user_key, domain, company_keys=None):
    user = ref("lg_user_" + user_key)
    allowed = user.company_ids if not company_keys else A["res.company"].browse([ref("lg_co_" + k).id for k in company_keys])
    uenv = env(user=user.id, context=dict(lang="en_US", allowed_company_ids=allowed.ids))
    return uenv["crm.lead"].search(domain)


grp_domain = [("lg_customer_group_id", "=", grp.id), ("type", "=", "opportunity")]
total_valcrest = A["crm.lead"].with_context(active_test=False).search_count(grp_domain)
v_jonas = visible("jonas", grp_domain + [("active", "in", [True, False])])
v_ruben = visible("ruben", grp_domain + [("active", "in", [True, False])])
v_sophie = visible("sophie", grp_domain + [("active", "in", [True, False])])
check("Access: Jonas (GmbH only) sees only the Valcrest deals of Tervane Logistik GmbH",
      set(v_jonas.mapped("company_id.name")) == {"Tervane Logistik GmbH"} and len(v_jonas) == 2, v_jonas.mapped("name"))
check("Access: Ruben (Transport + Warehousing) does not see GmbH deals",
      "Tervane Logistik GmbH" not in v_ruben.mapped("company_id.name"), sorted(set(v_ruben.mapped("company_id.name"))))
check("Access: Sophie (all companies) sees the whole Valcrest group", len(v_sophie) == total_valcrest, [len(v_sophie), total_valcrest])
uj = env(user=ref("lg_user_jonas").id, context=dict(allowed_company_ids=ref("lg_user_jonas").company_ids.ids))
check("Access: customer partners are shared (Jonas can read Valcrest Belgium NV)",
      bool(uj["res.partner"].search([("id", "=", vbe.id)])))
check("Access: Jonas cannot read the Warehousing NV quotation of story A",
      not uj["sale.order"].search([("id", "=", ref("lg_so_a").id)]))
out["access_counts"] = {"valcrest_total": total_valcrest, "jonas": len(v_jonas), "ruben": len(v_ruben), "sophie": len(v_sophie)}

# ---------------------------------------------------------------- side effects
mail_after = A["mail.mail"].sudo().search_count([])
outgoing = A["mail.mail"].sudo().search([("state", "in", ("outgoing", "exception"))])
out["mail_mail_created_during_verify"] = mail_after - mail_before
out["mail_mail_outgoing_total"] = len(outgoing)
out["mail_mail_outgoing_recipients"] = sorted(set(outgoing.mapped("email_to")))[:20]
check("No outgoing e-mail queued to fictional addresses", len(outgoing) == 0,
      [(m.subject, m.email_to, m.recipient_ids.mapped("email")) for m in outgoing[:10]])

out["summary"] = {"checks": len(out["checks"]), "failed": len(out["failures"])}
with open(REPORT, "w") as fh:
    json.dump(out, fh, indent=2, default=str)
print(json.dumps(out["summary"]))
for f in out["failures"]:
    print("FAIL:", f["check"], json.dumps(f["detail"], default=str)[:1500])
