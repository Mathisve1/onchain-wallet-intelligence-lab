#!/usr/bin/env python3
"""Generate the data-derived parts of the documentation (manifest, volume matrix,
Log-note register, expected report results) from the same source as the CSVs.

Usage: python3 build_docs_tables.py --as-of 2026-11-02
Writes into ../docs/generated/
"""
import argparse
import csv
import datetime as dt
import json
import os
from collections import Counter, defaultdict

import build_demo_data as g

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "docs", "generated")

MANIFEST = [
    # file, model, purpose, depends, app / rights, mapping to verify, post-import test
    ("01_res_company.csv", "res.company", "3 fictional legal entities of the logistics group (EUR)",
     "-", "Settings (admin)", "country_id/id -> Country, currency_id/id -> Currency",
     "Settings > Companies lists the 3 Tervane companies; admin user has them in Allowed Companies"),
    ("02_res_users.csv", "res.users", "11 fictional internal users (Sales, Operations, Finance, QHSE, IT)",
     "01", "Settings (admin); each user is an internal (licensed) user",
     "group_ids/id -> Groups, company_ids/id -> Allowed Companies",
     "Users have no e-mail (no invitations); notification = Inbox; GmbH-only users: Jonas, Markus"),
    ("03_crm_team.csv", "crm.team", "3 sales teams (separate from segments and legal entities)",
     "01, 02", "CRM", "member_ids/id -> Salespersons", "CRM > Configuration > Sales Teams shows 3 teams with leaders"),
    ("04_crm_stage.csv", "crm.stage", "Pipeline stages; renames the 4 default stages and adds Solution Design + Negotiation",
     "CRM installed", "CRM manager", "id uses crm.stage_lead1..4 to UPDATE the default stages",
     "Pipeline shows New, Qualified, Solution Design, Proposal, Negotiation, Won"),
    ("05_crm_lost_reason.csv", "crm.lost.reason", "Commercially meaningful loss reasons", "-", "CRM manager", "-",
     "CRM > Configuration > Lost Reasons"),
    ("06_crm_tag.csv", "crm.tag", "Service tags (combinations of services on one opportunity)", "-", "CRM", "-",
     "Never sum revenue grouped by tag (many2many double counts)"),
    ("07a_res_partner_groups.csv", "res.partner", "4 customer groups (grouping only, not invoicing entities)",
     "02 (owners)", "Contacts", "lg_is_customer_group -> Customer Group (parent)", "Contacts filter 'Customer Groups' = 4"),
    ("07b_res_partner_legal.csv", "res.partner", "34 legal customers, prospects and target accounts",
     "07a, 02", "Contacts", "lg_customer_group_id/id -> Belongs to Customer Group",
     "Valcrest group form lists 3 legal customers; 'Target Accounts Awaiting First Action' = 4"),
    ("07c_res_partner_sites.csv", "res.partner", "9 operational sites (delivery addresses of legal customers)",
     "07b", "Contacts", "type = delivery, parent_id/id", "Sites appear under their legal customer"),
    ("07d_res_partner_contacts.csv", "res.partner", "32 fictional customer contacts (.example e-mail domains)",
     "07a, 07b", "Contacts", "parent_id/id", "Contact's commercial entity = legal customer, not the group"),
    ("08_product_template.csv", "product.template", "8 service products used as proposal lines (annual values)",
     "Sales", "Sales", "type = service; default_code is the key used by file 12", "Products exist as services, no stock impact"),
    ("09_project_project.csv", "project.project", "3 handover projects, one per legal entity", "01", "Project", "company_id/id",
     "Project app shows 3 'Operations Handover' projects"),
    ("10_project_task_type.csv", "project.task.type", "Handover stages (To Accept, Accepted, Onboarding, Live)", "09", "Project",
     "lg_is_accepted_stage on 'Accepted'", "Stages visible in each handover project"),
    ("11a_crm_lead_opportunities.csv", "crm.lead", "51 opportunities: 13 open, 26 won, 12 lost (archived) over ~3 business years",
     "01-07, 03-06", "CRM; all 3 companies active in the switcher during import",
     "stage_id/id, lost_reason_id/id, tag_ids/id, lg_* fields", "Pipeline Analysis / Commercial Management totals match doc 10"),
    ("11b_crm_lead_leads.csv", "crm.lead", "5 unqualified leads (type = lead), 2 raised by Operations",
     "01-07, 03, 06; CRM setting Leads enabled", "CRM with the Leads setting on", "type = lead",
     "CRM > Leads lists 5 leads; filter 'Raised by Operations'"),
    ("12_sale_order.csv", "sale.order", "6 proposals (quotations) with annual service lines; order_line/id keeps re-import idempotent",
     "08, 11a", "Sales", "order_line/... columns; rows without id continue the previous order",
     "Untaxed totals equal the opportunity's expected annual revenue"),
    ("13_project_task.csv", "project.task", "6 handover tasks (simple and detailed) linked to won opportunities",
     "09, 10, 11a", "Project", "lg_lead_id/id, lg_accepted_by_id/id", "Opportunity A shows 'Accepted by Operations'"),
    ("14_project_subtask.csv", "project.task", "6 workstreams of the detailed handover (story A)", "13", "Project",
     "parent_id/id", "Task HO-A shows 6 sub-tasks"),
    ("90_demo_story_items.csv", "lg.demo.story.item", "Register of 40 Log notes, 21 activities, 4 proposal confirmations",
     "All above + module logistics_crm_demo", "Administrator", "target_xmlid = __import__.<id from the CSVs>",
     "After 'Run all pending': 65 rows Done, notes visible in chatter"),
]

FIELD_TYPES = {
    "id": "external ID", "name": "char", "street": "char", "zip": "char", "city": "char", "login": "char",
    "function": "char", "email": "char", "email_from": "char", "partner_name": "char", "contact_name": "char",
    "default_code": "char", "client_order_ref": "char", "description": "html", "description_sale": "text",
    "requirements": "text", "body": "text", "role": "char", "decision": "char", "verification": "char",
    "type": "selection", "notification_type": "selection", "tz": "selection", "priority": "selection",
    "kind": "selection", "story": "selection", "target_model": "selection", "lg_account_status": "selection",
    "lg_segment": "selection", "lg_region": "selection", "lg_revenue_type": "selection",
    "lg_signal_source": "selection", "lg_feasibility_state": "selection", "lg_handover_type": "selection",
    "sequence": "integer", "color": "integer", "lg_contract_months": "integer", "activity_deadline_days": "integer",
    "probability": "float (%)", "expected_revenue": "monetary (annual)", "list_price": "float",
    "order_line/product_uom_qty": "float", "order_line/product_id": "many2one (matched by product code)", "order_line/price_unit": "monetary (annual)",
    "is_won": "boolean", "fold": "boolean", "use_leads": "boolean", "use_opportunities": "boolean",
    "active": "boolean", "sale_ok": "boolean", "purchase_ok": "boolean", "lg_is_customer_group": "boolean",
    "lg_is_accepted_stage": "boolean",
    "date_deadline": "date", "lg_signal_date": "date (business)", "lg_decision_date": "date (business)",
    "lg_last_touch_date": "date (business)", "lg_contract_start": "date (business)",
    "lg_target_since": "date (business)", "lg_first_contact_date": "date (business)",
    "lg_accepted_date": "date (business)", "lg_go_live_date": "date", "business_date": "date (business)",
    "validity_date": "date", "date_order": "datetime", "target_xmlid": "char (external ID)",
    "activity_type_xmlid": "char (external ID)", "activity_user_xmlid": "char (external ID)",
    "activity_summary": "char",
}


def ftype(col):
    if col.endswith("/id"):
        base = col[:-3]
        return "many2many (ext. IDs, comma-separated)" if base.endswith("_ids") else "many2one (ext. ID)"
    return FIELD_TYPES.get(col, "char")


def write_manifest(import_dir):
    rows = []
    for i, (fname, model, purpose, dep, app, mapping, test) in enumerate(MANIFEST, 1):
        path = os.path.join(import_dir, fname)
        with open(path, encoding="utf-8") as fh:
            reader = list(csv.reader(fh))
        header = reader[0]
        data = reader[1:]
        count = sum(1 for r in data if r[0]) if fname == "12_sale_order.csv" else len(data)
        cols = "; ".join("%s (%s)" % (c, ftype(c)) for c in header)
        rows.append([i, fname, model, purpose, count, cols, "__import__.<id column>, prefix lg_", dep, app, mapping, test])
    hdr = ["sequence", "file", "odoo_model", "purpose", "records", "columns_and_types", "external_ids",
           "depends_on", "app_and_rights", "mapping_to_verify", "post_import_test"]
    with open(os.path.join(OUT, "manifest.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(hdr)
        w.writerows(rows)
    md = ["| # | File | Model | Records | Purpose | Depends on | Post-import test |", "|---|---|---|---|---|---|---|"]
    for r in rows:
        md.append("| %s | `%s` | `%s` | %s | %s | %s | %s |" % (r[0], r[1], r[2], r[4], r[3], r[7], r[10]))
    return "\n".join(md)


def business_year(o, d):
    date = o["decision"] if o["outcome"] in ("won", "lost") else o["signal_date"]
    return d(date)[:4]


def write_volume(d):
    long_rows = defaultdict(lambda: [0, 0.0])
    for o in g.LEADS:
        obj = "crm.lead (lead)" if o["outcome"] == "lead" else "crm.lead (opportunity)"
        key = (obj, business_year(o, d), g.COMPANY_NAME.get(o["company"], "(none)"),
               g.SEGMENT_LABEL.get(o["segment"], "(none)"), o["outcome"])
        long_rows[key][0] += 1
        long_rows[key][1] += o["rev"]
    for k, n, par, c, z, cty, st, seg, owner, ts, fc, dom in g.LEGAL:
        key = ("res.partner (legal customer / prospect / target)", d(ts)[:4] if ts else "(n/a)", "(shared)",
               g.SEGMENT_LABEL[seg], st)
        long_rows[key][0] += 1
    for k, *_rest in g.GROUPS:
        st, seg = _rest[4], _rest[5]
        long_rows[("res.partner (customer group)", "(n/a)", "(shared)", g.SEGMENT_LABEL[seg], st)][0] += 1
    long_rows[("res.partner (site)", "(n/a)", "(shared)", "(n/a)", "site")][0] += len(g.SITES)
    long_rows[("res.partner (contact)", "(n/a)", "(shared)", "(n/a)", "contact")][0] += len(g.CONTACTS)
    for q in g.QUOTES:
        lead = next(o for o in g.LEADS if o["key"] == q[3])
        long_rows[("sale.order (proposal)", business_year(lead, d), g.COMPANY_NAME[q[2]],
                   g.SEGMENT_LABEL[lead["segment"]], "confirmed" if q[8] else "draft")][0] += 1
    proj_company = {p[0]: p[2] for p in g.PROJECTS}
    for t in g.TASKS:
        lead = next(o for o in g.LEADS if o["key"] == t[6])
        long_rows[("project.task (handover)", business_year(lead, d), g.COMPANY_NAME[proj_company[t[2]]],
                   g.SEGMENT_LABEL[lead["segment"]], "accepted" if t[8] else "awaiting")][0] += 1
    long_rows[("project.task (handover workstream)", "2026", "Tervane Warehousing NV", "Polyolefins", "live")][0] += len(g.SUBTASKS)

    with open(os.path.join(OUT, "volume_matrix.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["object", "business_year", "legal_entity", "segment", "status", "records", "expected_annual_revenue_eur"])
        for k in sorted(long_rows):
            w.writerow(list(k) + [long_rows[k][0], int(long_rows[k][1])])

    # compact views for the doc
    opps = [o for o in g.LEADS if o["outcome"] != "lead"]
    years = sorted({business_year(o, d) for o in opps})
    status = ["won", "lost", "open"]
    t1 = ["| Business year | " + " | ".join(s.capitalize() for s in status) + " | Total |", "|---|" + "---|" * (len(status) + 1)]
    for y in years:
        c = Counter(o["outcome"] for o in opps if business_year(o, d) == y)
        t1.append("| %s | %s | %d |" % (y, " | ".join(str(c[s]) for s in status), sum(c.values())))
    ents = [c[1] for c in g.COMPANIES]
    segs = list(g.SEGMENT_LABEL.values())
    t2 = ["| Legal entity | " + " | ".join(segs) + " | Total |", "|---|" + "---|" * (len(segs) + 1)]
    for e in ents:
        row = [sum(1 for o in opps if g.COMPANY_NAME[o["company"]] == e and g.SEGMENT_LABEL[o["segment"]] == s) for s in segs]
        t2.append("| %s | %s | %d |" % (e, " | ".join(map(str, row)), sum(row)))
    return "\n".join(t1), "\n".join(t2)


def write_register(items):
    hdr = ["key", "story", "sequence", "kind", "target_model", "target_record", "fictional_role", "business_date",
           "note_text_or_activity", "decision_or_next_step", "verification_point"]
    rows = []
    for it in sorted(items, key=lambda i: (i["story"], i["sequence"])):
        text = it.get("body", "")
        if it["kind"] == "activity":
            text = "ACTIVITY: %s (assignee %s, due run date %+d days). %s" % (
                it["activity_summary"], it["activity_user_xmlid"].replace("__import__.lg_user_", ""),
                it["activity_deadline_days"], it.get("body", ""))
        if it["kind"] == "confirm_order":
            text = "CONFIRM QUOTATION with the standard action_confirm()"
        rows.append([it["name"], it["story"], it["sequence"], it["kind"], it["target_model"],
                     it["target_xmlid"].replace("__import__.", ""), it.get("role", ""), it.get("business_date", ""),
                     text, it.get("decision", ""), it.get("verification", "")])
    with open(os.path.join(OUT, "log_note_register.csv"), "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(hdr)
        w.writerows(rows)
    md = []
    for story in ("A", "B", "C", "D", "X"):
        md.append("\n### Story %s\n" % story)
        md.append("| Key | Kind | Target | Role (fictional) | Business date | Text (start) | Decision / next step |")
        md.append("|---|---|---|---|---|---|---|")
        for r in rows:
            if r[1] != story:
                continue
            md.append("| %s | %s | `%s` | %s | %s | %s | %s |" % (
                r[0], r[3], r[5], r[6], r[7], (r[8][:110] + ("..." if len(r[8]) > 110 else "")).replace("\n", " "),
                r[9]))
    return "\n".join(md)


def fmt(v):
    return "{:,.0f}".format(v) if v else ""


def table(title, data, cols=None):
    rows = sorted(data)
    cols = cols or sorted({c for r in data.values() for c in r})
    out = ["**%s**" % title, "", "| | " + " | ".join(cols) + " | Total |", "|---|" + "---|" * (len(cols) + 1)]
    tot = defaultdict(float)
    for r in rows:
        vals = [data[r].get(c, 0) for c in cols]
        for c, v in zip(cols, vals):
            tot[c] += v
        out.append("| %s | %s | %s |" % (r, " | ".join(fmt(v) for v in vals), fmt(sum(vals))))
    out.append("| **Total** | %s | **%s** |" % (" | ".join(fmt(tot[c]) for c in cols), fmt(sum(tot.values()))))
    return "\n".join(out)


def write_expected(exp):
    rt = ["New business", "Expansion", "Retained (renewal)"]
    parts = [
        ("Mgmt 1 - Weighted forecast by segment x revenue type (open opportunities, EUR, weighted = annual x probability)",
         exp["R2_open_segment_x_rtype_weighted"], rt),
        ("Mgmt 1 - same records, expected annual revenue (unweighted)", exp["R2_open_segment_x_rtype_expected"], rt),
        ("Mgmt 2 - Weighted forecast by region x revenue type (open, EUR)", exp["R3_open_region_x_rtype_weighted"], rt),
        ("Mgmt 3 - Won expected annual revenue by business decision year x revenue type (EUR)", exp["R4_won_year_x_rtype_expected"], rt),
        ("Mgmt 3 - Won deals count", exp["R4_won_year_x_rtype_count"], rt),
        ("Mgmt 3 - Won total contract value by decision year (EUR, never add to annual figures)", exp["R4_won_year_tcv"], ["TCV"]),
        ("Mgmt 4 - Renewals (retained revenue type): won vs lost by decision year (EUR)", exp["R6_renewals_year_x_status_expected"], ["Won", "Lost"]),
        ("Mgmt 5 - Customer group x contracting entity: open + won with decision since %s (EUR)" % exp["R7_cutoff_won_decision_from"],
         exp["R7_group_x_entity_expected"], [c[1] for c in g.COMPANIES]),
        ("Mgmt 6 - Open pipeline expected annual revenue by stage x segment (EUR)", exp["R1_open_stage_x_segment_expected"],
         list(g.SEGMENT_LABEL.values())),
        ("Mgmt 6 - Open pipeline weighted by stage x segment (EUR)", exp["R1_open_stage_x_segment_weighted"], list(g.SEGMENT_LABEL.values())),
        ("Mgmt 7 - Open pipeline by owner x stage (EUR)", exp["R8_open_owner_x_stage_expected"],
         ["New", "Qualified", "Solution Design", "Proposal", "Negotiation"]),
        ("Mgmt 8 - Lost expected annual revenue by decision year x lost reason (EUR)", exp["R5_lost_year_x_reason_expected"],
         [n for k, n in g.LOST_REASONS if any(n in r for r in exp["R5_lost_year_x_reason_expected"].values())]),
    ]
    md = []
    for title, data, cols in parts:
        cols = [c for c in cols if any(c in r for r in data.values())] or cols
        md.append(table(title, data, cols))
        md.append("")
    return "\n".join(md)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--as-of", default=g.BASE_AS_OF.isoformat())
    args = ap.parse_args()
    as_of = dt.date.fromisoformat(args.as_of)
    os.makedirs(OUT, exist_ok=True)
    import_dir = os.path.join(HERE, "..", "import")
    res = g.build(import_dir, as_of)
    exp = g.expected_results(res["d"])
    exp["as_of"] = as_of.isoformat()
    exp["shift_days"] = res["shift_days"]
    with open(os.path.join(HERE, "expected_results.json"), "w", encoding="utf-8") as fh:
        json.dump(exp, fh, indent=2, ensure_ascii=False)
    manifest_md = write_manifest(import_dir)
    vol_year, vol_entity = write_volume(res["d"])
    register_md = write_register(res["items"])
    expected_md = write_expected(exp)
    for name, content in [("manifest_table.md", manifest_md), ("volume_by_year.md", vol_year),
                          ("volume_by_entity_segment.md", vol_entity), ("register_table.md", register_md),
                          ("expected_results.md", expected_md)]:
        with open(os.path.join(OUT, name), "w", encoding="utf-8") as fh:
            fh.write(content + "\n")
    print("written to", os.path.abspath(OUT))
    print(json.dumps(exp["totals"]))


if __name__ == "__main__":
    main()
