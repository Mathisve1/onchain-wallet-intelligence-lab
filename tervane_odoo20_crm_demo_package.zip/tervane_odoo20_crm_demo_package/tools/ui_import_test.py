"""End-to-end UI import: every CSV through Odoo 20's Import screen (cog menu > Import
records > Upload > Test > Import), then the Log-note loader through its menu.
Usage: python3 ui_import_test.py http://localhost:8069 admin admin <import_dir> <out_dir> <company_ids csv>
"""
import json
import os
import sys

from playwright.sync_api import sync_playwright

BASE, LOGIN, PWD, IMPORT_DIR, OUT, CIDS = sys.argv[1:7]

STEPS = [
    ("01_res_company.csv", "base.action_res_company_form"),
    ("02_res_users.csv", "base.action_res_users"),
    ("03_crm_team.csv", "sales_team.crm_team_action_config"),
    ("04_crm_stage.csv", "crm.crm_stage_action"),
    ("05_crm_lost_reason.csv", "crm.crm_lost_reason_action"),
    ("06_crm_tag.csv", "sales_team.sales_team_crm_tag_action"),
    ("07a_res_partner_groups.csv", "contacts.action_contacts"),
    ("07b_res_partner_legal.csv", "contacts.action_contacts"),
    ("07c_res_partner_sites.csv", "contacts.action_contacts"),
    ("07d_res_partner_contacts.csv", "contacts.action_contacts"),
    ("08_product_template.csv", "sale.product_template_action"),
    ("09_project_project.csv", "project.open_view_project_all"),
    ("10_project_task_type.csv", "project.open_task_type_form"),
    ("11a_crm_lead_opportunities.csv", "crm.crm_lead_all_leads"),
    ("11b_crm_lead_leads.csv", "crm.crm_lead_all_leads"),
    ("12_sale_order.csv", "sale.action_quotations"),
    ("13_project_task.csv", "project.action_view_all_task"),
    ("14_project_subtask.csv", "project.action_view_all_task"),
    ("90_demo_story_items.csv", "logistics_crm_demo.action_lg_demo_story_item"),
]
results = []

with sync_playwright() as p:
    browser = p.chromium.launch()
    ctx = browser.new_context(viewport={"width": 1500, "height": 950}, locale="en-US", timezone_id="Europe/Brussels")
    page = ctx.new_page()
    page.goto(f"{BASE}/web/login")
    page.fill("input[name=login]", LOGIN)
    page.fill("input[name=password]", PWD)
    page.click("button[type=submit]")
    page.wait_for_selector(".o_main_navbar", timeout=60000)

    for fname, action in STEPS:
        if fname == "02_res_users.csv":
            # install-guide step C5: tick all companies in the switcher (same effect as the cookie)
            ids = page.evaluate("""async () => {
                const r = await fetch('/web/dataset/call_kw/res.company/search_read', {method: 'POST',
                    headers: {'Content-Type': 'application/json'},
                    body: JSON.stringify({jsonrpc: '2.0', method: 'call', params: {model: 'res.company',
                        method: 'search_read', args: [[]], kwargs: {fields: ['id', 'name']}}})});
                const j = await r.json();
                return j.result.sort((a, b) => (a.name.startsWith('Tervane') ? 0 : 1) - (b.name.startsWith('Tervane') ? 0 : 1)).map(c => c.id);
            }""")
            print("companies", ids)
            ctx.add_cookies([{"name": "cids", "value": "-".join(map(str, ids)), "url": BASE}])
        step = {"file": fname, "action": action}
        try:
            page.goto(f"{BASE}/odoo/action-{action}?view_type=list")
            page.wait_for_selector(".o_list_view, .o_kanban_view", timeout=60000)
            page.locator(".o_control_panel .o_cp_action_menus button, .o_control_panel button.o_cp_action_menus").first.click()
            page.wait_for_timeout(500)
            page.locator(".o-dropdown--menu .dropdown-item").filter(has_text="Import").first.click()
            page.wait_for_selector(".o_import_action", timeout=30000)
            page.locator(".o_import_action input[type=file]").first.set_input_files(os.path.join(IMPORT_DIR, fname))
            page.wait_for_selector(".o_import_data_content, .o_import_preview", timeout=30000)
            page.wait_for_timeout(1200)
            page.get_by_role("button", name="Test").first.click()
            page.wait_for_timeout(2500)
            body = page.inner_text(".o_import_action")
            step["test_ok"] = "Everything seems valid." in body
            if not step["test_ok"]:
                step["test_text"] = body[:1500]
                page.screenshot(path=f"{OUT}/uiimport_fail_{fname}.png")
                results.append(step)
                break
            page.get_by_role("button", name="Import").first.click()
            page.wait_for_selector(".o_import_action", state="detached", timeout=120000)
            note = page.locator(".o_notification").all_inner_texts()
            step["notification"] = " | ".join(n.strip() for n in note)[:200]
            step["ok"] = True   # Odoo leaves the import screen only after a successful import
        except Exception as e:  # report and stop
            step["error"] = repr(e)[:500]
            page.screenshot(path=f"{OUT}/uiimport_error_{fname}.png")
            results.append(step)
            break
        results.append(step)
        print(fname, step.get("ok"), step.get("notification", ""))
        page.wait_for_timeout(800)

    # Run the loader from the menu (Actions > Run all pending demo story items)
    if all(r.get("ok") for r in results) and len(results) == len(STEPS):
        page.goto(f"{BASE}/odoo/action-logistics_crm_demo.action_lg_demo_story_item?view_type=list")
        page.wait_for_selector(".o_list_view", timeout=60000)
        page.get_by_role("button", name="Run All Pending").first.click()
        page.wait_for_timeout(8000)
        page.screenshot(path=f"{OUT}/uiimport_loader_done.png")
        results.append({"loader": "run with the Run All Pending button", "page_text": page.inner_text(".o_content")[:300]})
    browser.close()

json.dump(results, open(f"{OUT}/ui_import_results.json", "w"), indent=2)
print(json.dumps({"imported_ok": sum(1 for r in results if r.get("ok")), "files": len(STEPS)}))
