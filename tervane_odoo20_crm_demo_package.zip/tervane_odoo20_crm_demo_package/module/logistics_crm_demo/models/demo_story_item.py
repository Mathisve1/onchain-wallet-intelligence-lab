import logging

from markupsafe import Markup, escape

from odoo import _, fields, models
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

ALLOWED_TARGET_MODELS = ("crm.lead", "project.task", "res.partner", "sale.order")


class LgDemoStoryItem(models.Model):
    """Register of demo Log notes, activities and proposal confirmations.

    Rows are imported from CSV (standard import, external IDs). Running them uses
    only supported public APIs:
      * notes      -> record.message_post(message_type='comment', subtype 'mail.mt_note'),
                      i.e. exactly what the chatter 'Log note' button does;
      * activities -> record.activity_schedule(...);
      * proposals  -> sale.order.action_confirm().
    Nothing is written to mail_message directly, nothing is backdated, the author
    is the user who runs the loader. Every row is executed at most once.
    """

    _name = "lg.demo.story.item"
    _description = "Demo story item (Log note / activity register)"
    _order = "story, sequence, id"

    name = fields.Char(string="Key", required=True, help="Unique register key, e.g. A-01")
    story = fields.Selection([
        ("A", "A - Expand an existing relationship (primary)"),
        ("B", "B - New Food & Feed customer"),
        ("C", "C - Strategic negotiation / loss"),
        ("D", "D - Renewal and account development"),
        ("X", "Supporting history"),
    ], required=True)
    sequence = fields.Integer(default=10)
    kind = fields.Selection([
        ("note", "Log note"),
        ("activity", "Activity (next action)"),
        ("confirm_order", "Confirm quotation"),
    ], required=True, default="note")
    target_model = fields.Selection([(m, m) for m in ALLOWED_TARGET_MODELS], required=True)
    target_xmlid = fields.Char(
        string="Target External ID", required=True,
        help="External ID of the target record, e.g. __import__.lead_a_valcrest_warehousing")
    role = fields.Char(string="Fictional Role", help="Shown inside the note text. NOT the chatter author.")
    business_date = fields.Date(string="Business Date (fictional)")
    body = fields.Text(string="Note Text")
    decision = fields.Char(string="Decision / Next Step")
    verification = fields.Char(string="Verification Point")
    activity_type_xmlid = fields.Char(default="mail.mail_activity_data_todo")
    activity_summary = fields.Char()
    activity_user_xmlid = fields.Char(string="Activity Assignee External ID")
    activity_deadline_days = fields.Integer(
        string="Deadline (days from run)",
        help="Deadline = date of the loader run + N days (negative = already overdue).")

    state = fields.Selection([
        ("pending", "Pending"),
        ("done", "Done"),
        ("target_missing", "Target missing"),
        ("error", "Error"),
    ], default="pending", required=True, readonly=True, copy=False)
    res_id = fields.Integer(string="Target Record ID", readonly=True, copy=False)
    message_id = fields.Many2one("mail.message", readonly=True, copy=False, ondelete="set null")
    activity_id = fields.Many2one("mail.activity", readonly=True, copy=False, ondelete="set null")
    done_on = fields.Datetime(readonly=True, copy=False)
    done_by_id = fields.Many2one("res.users", string="Run By", readonly=True, copy=False)
    log = fields.Text(readonly=True, copy=False)

    _name_unique = models.Constraint("UNIQUE(name)", "The register key must be unique.")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _marker(self):
        return "[demo-note %s]" % self.name

    def _resolve_target(self):
        self.ensure_one()
        record = self.env.ref(self.target_xmlid.strip(), raise_if_not_found=False)
        if not record or record._name != self.target_model:
            return None
        # archived records (lost opportunities) are fine targets
        return record.with_context(active_test=False).exists()

    def _resolve_user(self, xmlid):
        if not xmlid:
            return self.env.user
        user = self.env.ref(xmlid.strip(), raise_if_not_found=False)
        if user and user._name == "res.users":
            return user
        return self.env.user

    def _note_html(self):
        self.ensure_one()
        parts = []
        header = []
        if self.business_date:
            header.append(Markup("<b>%s</b>") % _("Business date: %s", self.business_date.strftime("%d %b %Y")))
        if self.role:
            header.append(escape(_("Role: %s", self.role)))
        if header:
            parts.append(Markup("<p>%s</p>") % Markup(" &middot; ").join(header))
        for paragraph in (self.body or "").split("\n\n"):
            paragraph = paragraph.strip()
            if paragraph:
                lines = [escape(line) for line in paragraph.split("\n")]
                parts.append(Markup("<p>%s</p>") % Markup("<br/>").join(lines))
        if self.decision:
            parts.append(Markup("<p><b>%s</b> %s</p>") % (_("Decision / next step:"), self.decision))
        parts.append(Markup("<p><small><i>%s</i></small></p>") % _(
            "%(marker)s Demo story note loaded by the demo package. The author and time "
            "shown by Odoo are the user who ran the loader and the moment it ran; the "
            "business date and role above are fictional.", marker=self._marker()))
        return Markup("").join(parts)

    def _find_existing_note(self, record):
        return self.env["mail.message"].sudo().search([
            ("model", "=", record._name),
            ("res_id", "=", record.id),
            ("message_type", "=", "comment"),
            ("body", "ilike", self._marker()),
        ], limit=1)

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    def _run_one(self):
        self.ensure_one()
        if self.state == "done":
            return
        record = self._resolve_target()
        now = fields.Datetime.now()
        if record is None or not record:
            self.write({"state": "target_missing",
                        "log": _("Target %s (%s) not found. Import the CSV files first.",
                                 self.target_xmlid, self.target_model)})
            return
        vals = {"res_id": record.id, "done_on": now, "done_by_id": self.env.user.id}
        if self.kind == "note":
            existing = self._find_existing_note(record)
            if existing:
                vals.update(state="done", message_id=existing.id,
                            log=_("Note already present on the record; linked, not posted again."))
            else:
                message = record.with_context(mail_post_autofollow_author_skip=True).message_post(
                    body=self._note_html(),
                    message_type="comment",
                    subtype_xmlid="mail.mt_note",
                )
                vals.update(state="done", message_id=message.id, log=_("Posted as internal note."))
        elif self.kind == "activity":
            user = self._resolve_user(self.activity_user_xmlid)
            deadline = fields.Date.add(fields.Date.context_today(self), days=self.activity_deadline_days or 0)
            activity = record.with_context(mail_activity_quick_update=True).activity_schedule(
                act_type_xmlid=self.activity_type_xmlid or "mail.mail_activity_data_todo",
                date_deadline=deadline,
                summary=self.activity_summary or "",
                note=escape(self.body or ""),
                user_id=user.id,
            )
            vals.update(state="done", activity_id=activity[:1].id,
                        log=_("Activity scheduled for %(user)s, due %(date)s.", user=user.name, date=deadline))
        elif self.kind == "confirm_order":
            if record.state in ("draft", "sent"):
                record.action_confirm()
                vals.update(state="done", log=_("Quotation confirmed with action_confirm()."))
            else:
                vals.update(state="done", log=_("Quotation already in state %s; nothing to do.", record.state))
        self.write(vals)

    def action_run(self):
        items = self.filtered(lambda i: i.state != "done").sorted(lambda i: (i.story, i.sequence, i.id))
        for item in items:
            try:
                with self.env.cr.savepoint():
                    item._run_one()
            except Exception as error:  # noqa: BLE001 - reported on the row, run continues
                _logger.exception("Demo story item %s failed", item.name)
                item.write({"state": "error", "log": str(error)})
        return True

    def action_run_all_pending(self):
        """Runs every row that is not Done, whatever is selected (list button and server action)."""
        self = self.browse()
        self.search([("state", "!=", "done")]).action_run()
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": _("Demo story items"),
                "message": _("Run finished: %(done)s done, %(missing)s target missing, %(error)s error.",
                             done=self.search_count([("state", "=", "done")]),
                             missing=self.search_count([("state", "=", "target_missing")]),
                             error=self.search_count([("state", "=", "error")])),
                "sticky": False,
                "next": {"type": "ir.actions.client", "tag": "soft_reload"},
            },
        }

    def action_reset_to_pending(self):
        """Explicit admin action. Does NOT delete notes already posted; the marker
        check prevents a second copy of a note that is still on the record."""
        self.write({"state": "pending", "log": False})
        return True

    def action_open_target(self):
        self.ensure_one()
        record = self._resolve_target()
        if not record:
            raise UserError(_("Target record not found."))
        return {"type": "ir.actions.act_window", "res_model": record._name,
                "res_id": record.id, "view_mode": "form"}
