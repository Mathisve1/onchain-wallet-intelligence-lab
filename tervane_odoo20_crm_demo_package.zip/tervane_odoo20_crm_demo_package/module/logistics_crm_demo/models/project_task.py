from markupsafe import Markup

from odoo import _, fields, models
from odoo.exceptions import UserError


class ProjectTaskType(models.Model):
    _inherit = "project.task.type"

    lg_is_accepted_stage = fields.Boolean(
        string="Handover Accepted Stage",
        help="'Accept handover' moves the task to this stage.")


class ProjectTask(models.Model):
    _inherit = "project.task"

    lg_lead_id = fields.Many2one(
        "crm.lead", string="Opportunity", index="btree_not_null", tracking=True,
        domain="[('type', '=', 'opportunity')]")
    lg_handover_type = fields.Selection([
        ("simple", "Simple handover"),
        ("detailed", "Detailed handover (integrated solution)"),
    ], string="Handover Type")
    lg_commercial_owner_id = fields.Many2one(
        "res.users", string="Commercial Owner", related="lg_lead_id.user_id")
    lg_accepted_by_id = fields.Many2one(
        "res.users", string="Accepted By", tracking=True, domain="[('share', '=', False)]")
    lg_accepted_date = fields.Date(string="Accepted On (business)", tracking=True)
    lg_go_live_date = fields.Date(string="Planned Go-live")

    def action_lg_accept_handover(self):
        """Live demo action: the current user accepts the handover.

        Uses the real user and the real time. Posts a standard internal note.
        """
        for task in self:
            if task.lg_accepted_by_id:
                raise UserError(_("This handover was already accepted by %s.", task.lg_accepted_by_id.name))
            vals = {
                "lg_accepted_by_id": self.env.user.id,
                "lg_accepted_date": fields.Date.context_today(self),
            }
            accepted_stage = task.project_id.type_ids.filtered("lg_is_accepted_stage")[:1]
            if accepted_stage:
                vals["stage_id"] = accepted_stage.id
            task.write(vals)
            task.message_post(
                body=Markup("<p>%s</p>") % _(
                    "Handover accepted by %(user)s. Operations now owns delivery; "
                    "%(owner)s remains commercial owner of the account.",
                    user=self.env.user.name,
                    owner=task.lg_lead_id.user_id.name or _("the account manager")),
                message_type="comment",
                subtype_xmlid="mail.mt_note",
            )
            if task.lg_lead_id:
                task.lg_lead_id.message_post(
                    body=Markup("<p>%s</p>") % _(
                        "Handover '%(task)s' accepted by %(user)s.",
                        task=task.name, user=self.env.user.name),
                    message_type="comment",
                    subtype_xmlid="mail.mt_note",
                )
        return True
