from odoo import api, fields, models

from .crm_lead import SEGMENTS


class ResPartner(models.Model):
    """Customer structure for the demo.

    Odoo 20 makes the top of the parent_id chain the commercial entity of every
    child (and derives 'is a company' from the Tax ID). A customer group must
    therefore NOT be the parent_id of its legal customers, otherwise the group
    would become the invoicing entity. Structure used here:

        customer group (lg_is_customer_group)        top-level partner, grouping only
          ^ lg_customer_group_id
        legal customer                               top-level partner = commercial entity
          <- parent_id: sites (delivery addresses) and contacts
    """
    _inherit = "res.partner"

    lg_account_status = fields.Selection([
        ("target", "Target account"),
        ("prospect", "Prospect (engaged)"),
        ("customer", "Customer"),
        ("former", "Former customer"),
    ], string="Account Status", tracking=True, index=True,
        help="A target account is a deliberately selected company. It is NOT a lead: "
             "a lead is only created once there is a concrete signal.")
    lg_segment = fields.Selection(SEGMENTS, string="Primary Segment", index=True)
    lg_is_customer_group = fields.Boolean(
        string="Customer Group (parent)",
        help="Groups several legal customers for reporting. Not an invoicing entity.")
    lg_customer_group_id = fields.Many2one(
        "res.partner", string="Belongs to Customer Group", index=True,
        domain="[('lg_is_customer_group', '=', True)]",
        help="Set on a legal customer that belongs to a customer group.")
    lg_group_member_ids = fields.One2many(
        "res.partner", "lg_customer_group_id", string="Legal Customers in Group")
    lg_target_since = fields.Date(string="Target Since (business)")
    lg_first_contact_date = fields.Date(
        string="First Contact (business)",
        help="Empty on a target account = still awaiting a first action.")
    lg_group_id = fields.Many2one(
        "res.partner", string="Customer Group", compute="_compute_lg_group_id",
        store=True, recursive=True, index=True,
        help="Reporting group: the customer group, or the legal customer itself when it has no group.")

    @api.depends("parent_id", "parent_id.lg_group_id", "lg_customer_group_id", "lg_is_customer_group")
    def _compute_lg_group_id(self):
        for partner in self:
            if partner.lg_is_customer_group:
                partner.lg_group_id = partner
            elif partner.parent_id:
                partner.lg_group_id = partner.parent_id.lg_group_id
            elif partner.lg_customer_group_id:
                partner.lg_group_id = partner.lg_customer_group_id
            else:
                partner.lg_group_id = partner
