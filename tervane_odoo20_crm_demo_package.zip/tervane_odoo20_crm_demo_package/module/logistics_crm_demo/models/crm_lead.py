from odoo import api, fields, models

SEGMENTS = [
    ("polyolefins", "Polyolefins"),
    ("food_feed", "Food & Feed"),
    ("circular", "Circular Polymers"),
]

REGIONS = [
    ("benelux", "Benelux"),
    ("germany", "Germany"),
    ("france", "France"),
    ("southern_europe", "Southern Europe"),
    ("cee", "Central & Eastern Europe"),
]

REVENUE_TYPES = [
    ("new", "New business"),
    ("expansion", "Expansion"),
    ("retained", "Retained (renewal)"),
]


class CrmLead(models.Model):
    _inherit = "crm.lead"

    # Native fields, relabelled only. Convention of this demo: the native
    # "Expected Revenue" holds the EXPECTED ANNUAL REVENUE of the opportunity,
    # so the native prorated revenue is the probability-weighted annual forecast.
    expected_revenue = fields.Monetary(string="Expected Annual Revenue")
    prorated_revenue = fields.Monetary(string="Weighted Annual Revenue")

    lg_segment = fields.Selection(SEGMENTS, string="Segment", tracking=True, index=True)
    lg_region = fields.Selection(REGIONS, string="Region", tracking=True, index=True)
    lg_revenue_type = fields.Selection(
        REVENUE_TYPES, string="Revenue Type", tracking=True, index=True,
        help="New business: first contract with a customer group.\n"
             "Expansion: incremental annual revenue at an existing customer group "
             "(new service, site, legal entity or volume).\n"
             "Retained: renewal of the existing contracted scope (incl. indexation).")

    lg_signal_source = fields.Selection([
        ("operations", "Operations"),
        ("sales", "Sales / account management"),
        ("customer", "Customer request"),
        ("tender", "Tender / RFQ"),
        ("marketing", "Marketing / event"),
    ], string="Signal Source", index=True)
    lg_signal_user_id = fields.Many2one(
        "res.users", string="Signal Raised By", domain="[('share', '=', False)]")
    lg_signal_date = fields.Date(string="Signal Date (business)")

    lg_feasibility_state = fields.Selection([
        ("not_needed", "Not needed"),
        ("requested", "Requested"),
        ("in_review", "In review"),
        ("feasible", "Feasible"),
        ("conditional", "Feasible with conditions"),
        ("not_feasible", "Not feasible"),
    ], string="Feasibility", tracking=True, index=True)
    lg_feasibility_user_id = fields.Many2one(
        "res.users", string="Feasibility Reviewer", domain="[('share', '=', False)]")

    lg_decision_date = fields.Date(
        string="Decision Date (business)", index=True,
        help="Fictional business date of the won/lost decision. Odoo's own "
             "'Closed Date' stays the real system date.")
    lg_last_touch_date = fields.Date(string="Last Customer Interaction (business)")
    lg_contract_start = fields.Date(string="Contract Start")
    lg_contract_months = fields.Integer(string="Contract Term (months)")
    lg_tcv = fields.Monetary(
        string="Total Contract Value", currency_field="company_currency",
        compute="_compute_lg_tcv", store=True,
        help="Expected annual revenue x contract term / 12. Never add this to "
             "annual revenue figures.")

    lg_customer_group_id = fields.Many2one(
        "res.partner", string="Customer Group",
        related="partner_id.lg_group_id", store=True, index=True)
    lg_legal_customer_id = fields.Many2one(
        "res.partner", string="Legal Customer",
        related="partner_id.commercial_partner_id", store=True, index=True)
    lg_site_id = fields.Many2one(
        "res.partner", string="Operational Site",
        domain="[('type', 'in', ('delivery', 'other'))]")
    lg_delivering_company_ids = fields.Many2many(
        "res.company", "lg_crm_lead_delivering_company_rel", "lead_id", "company_id",
        string="Delivering Entities",
        help="Group entities that deliver part of the service. The contracting "
             "entity is the opportunity's Company; revenue is reported once, there.")

    lg_handover_task_ids = fields.One2many("project.task", "lg_lead_id", string="Handovers")
    lg_handover_count = fields.Integer(compute="_compute_lg_handover_count")
    lg_handover_state = fields.Selection([
        ("none", "No handover"),
        ("awaiting", "Awaiting Operations acceptance"),
        ("accepted", "Accepted by Operations"),
    ], string="Handover", compute="_compute_lg_handover", store=True, index=True)
    lg_handover_accepted_by_id = fields.Many2one(
        "res.users", string="Handover Accepted By",
        compute="_compute_lg_handover", store=True)

    @api.depends("expected_revenue", "lg_contract_months")
    def _compute_lg_tcv(self):
        for lead in self:
            lead.lg_tcv = (lead.expected_revenue or 0.0) * (lead.lg_contract_months or 0) / 12.0

    @api.depends("lg_handover_task_ids.lg_accepted_by_id", "lg_handover_task_ids.parent_id",
                 "lg_handover_task_ids.active")
    def _compute_lg_handover(self):
        for lead in self:
            main_tasks = lead.lg_handover_task_ids.filtered(lambda t: not t.parent_id)
            if not main_tasks:
                lead.lg_handover_state = "none"
                lead.lg_handover_accepted_by_id = False
            elif all(t.lg_accepted_by_id for t in main_tasks):
                lead.lg_handover_state = "accepted"
                lead.lg_handover_accepted_by_id = main_tasks[:1].lg_accepted_by_id
            else:
                lead.lg_handover_state = "awaiting"
                lead.lg_handover_accepted_by_id = False

    def _compute_lg_handover_count(self):
        for lead in self:
            lead.lg_handover_count = len(lead.lg_handover_task_ids.filtered(lambda t: not t.parent_id))

    def action_lg_view_handovers(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Handovers",
            "res_model": "project.task",
            "view_mode": "list,form",
            "domain": [("lg_lead_id", "=", self.id), ("parent_id", "=", False)],
            "context": {"default_lg_lead_id": self.id},
        }
