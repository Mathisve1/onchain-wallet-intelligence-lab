# logistics_crm_demo (Odoo 20)

Demo-only module for the fictional Tervane Logistics Group presales demo. Creates no business data on install.

## What it adds

* `crm.lead`: segment, region, revenue type, signal (source, user, date), feasibility (state, reviewer), business dates (signal, decision, last interaction, contract start), contract term, computed TCV, customer group / legal customer (stored related), operational site, delivering entities, handover state; relabels Expected Revenue → Expected Annual Revenue and Prorated Revenue → Weighted Annual Revenue.
* `res.partner`: account status, primary segment, customer-group link (`lg_customer_group_id`, deliberately not `parent_id`, because Odoo 20 makes the top of the parent chain the commercial entity), computed reporting group, target / first-contact business dates.
* `project.task`: opportunity link, handover type, accepted by / on, go-live; button **Accept Handover** (current user, current date, standard internal note on task and opportunity). `project.task.type`: "Handover Accepted Stage" flag.
* Views: Commercial Journey tab, list columns, search filters and group-bys; CRM > Reporting > Commercial Management (pivot / graph / list) with 8 shared favourites.
* `lg.demo.story.item` (CRM > Configuration > Demo Story Items, administrators): importable register of Log notes, activities and quotation confirmations, executed with `message_post` (comment + `mail.mt_note`), `activity_schedule` and `action_confirm`. Each row runs once; a reset note is matched by its `[demo-note KEY]` marker. No direct SQL, no backdating, no forged authors.

## Dependencies

`crm`, `sale_crm`, `project`, `mail`. Access rights use Odoo 20's `ir.access` model (`security/ir.access.csv`).

## Tests

`tests/test_demo_story_item.py` (post_install): idempotent loader, Run All Pending from the list button, TCV and handover state, group is not the commercial parent. Run: `odoo-bin -d <db> -i logistics_crm_demo --test-enable --test-tags=/logistics_crm_demo --stop-after-init`.

Not for production databases. Uninstalling removes fields, views and favourites, not imported records.
