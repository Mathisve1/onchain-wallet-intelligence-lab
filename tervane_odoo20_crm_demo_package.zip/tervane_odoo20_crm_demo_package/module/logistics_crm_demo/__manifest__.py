{
    "name": "Logistics CRM Demo (Tervane, fictional)",
    "version": "20.0.1.0.0",
    "summary": "Demo-only fields, filters, handover link and an auditable Log-note loader "
               "for the fictional Tervane Logistics Group presales demo.",
    "description": """
Demo-only module. Adds commercial fields on opportunities (segment, region,
revenue type, signal, feasibility, business dates, customer group, contract
term, TCV), an account status on contacts (target account vs customer), an
opportunity link and an Accept handover action on project tasks, search
filters, a management reporting action with shared favourites, and Demo story
items: an importable register of Log notes and activities that are posted with
the standard message_post() and activity_schedule() API.

No data is created on install. Business data comes from the CSV files of the
demo package. Not intended for production databases.
""",
    "author": "Demo package (fictional data)",
    "category": "Sales/CRM",
    "license": "LGPL-3",
    "depends": ["crm", "sale_crm", "project", "mail"],
    "data": [
        "security/ir.access.csv",
        "views/crm_lead_views.xml",
        "views/res_partner_views.xml",
        "views/project_task_views.xml",
        "views/demo_story_item_views.xml",
        "views/reporting_views.xml",
        "data/ir_filters.xml",
    ],
    "installable": True,
    "application": False,
}
