from odoo.tests import TransactionCase, tagged


@tagged("post_install", "-at_install")
class TestDemoStoryItem(TransactionCase):
    """The loader posts each register row once, as a standard internal note."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.partner = cls.env["res.partner"].create({"name": "Fictional Test Customer"})
        cls.lead = cls.env["crm.lead"].create({
            "name": "Fictional test opportunity", "type": "opportunity",
            "partner_id": cls.partner.id, "expected_revenue": 120000, "lg_contract_months": 24,
        })
        cls.env["ir.model.data"].create({
            "module": "__import__", "name": "lg_test_lead", "model": "crm.lead", "res_id": cls.lead.id,
        })
        Item = cls.env["lg.demo.story.item"]
        cls.note = Item.create({
            "name": "T-01", "story": "X", "kind": "note", "target_model": "crm.lead",
            "target_xmlid": "__import__.lg_test_lead", "role": "Test role", "body": "Test body",
            "decision": "Test decision",
        })
        cls.activity = Item.create({
            "name": "T-02", "story": "X", "kind": "activity", "target_model": "crm.lead",
            "target_xmlid": "__import__.lg_test_lead", "activity_summary": "Next action",
            "activity_deadline_days": 3,
        })
        cls.missing = Item.create({
            "name": "T-03", "story": "X", "kind": "note", "target_model": "crm.lead",
            "target_xmlid": "__import__.does_not_exist", "body": "x",
        })

    def _notes(self):
        return self.env["mail.message"].search([
            ("model", "=", "crm.lead"), ("res_id", "=", self.lead.id),
            ("message_type", "=", "comment"), ("subtype_id", "=", self.env.ref("mail.mt_note").id)])

    def test_run_is_idempotent(self):
        items = self.note | self.activity | self.missing
        items.action_run()
        self.assertEqual(self.note.state, "done")
        self.assertEqual(self.activity.state, "done")
        self.assertEqual(self.missing.state, "target_missing")
        notes = self._notes()
        self.assertEqual(len(notes), 1)
        self.assertIn("[demo-note T-01]", notes.body)
        self.assertEqual(notes.author_id, self.env.user.partner_id, "author must be the real user, not a fictional one")
        self.assertEqual(len(self.lead.activity_ids), 1)
        # second run and reset + run: still one note, one activity
        items.action_run()
        self.note.action_reset_to_pending()
        self.note.action_run()
        self.assertEqual(len(self._notes()), 1)
        self.assertEqual(len(self.lead.activity_ids), 1)

    def test_run_all_pending_from_list_button(self):
        # the list button calls the method on the selected (or no) records; it must run all pending rows
        self.env["lg.demo.story.item"].browse(self.note.ids).action_run_all_pending()
        self.assertEqual(self.activity.state, "done")
        self.assertEqual(len(self._notes()), 1)

    def test_tcv_and_handover_state(self):
        self.assertAlmostEqual(self.lead.lg_tcv, 240000)
        self.assertEqual(self.lead.lg_handover_state, "none")
        project = self.env["project.project"].create({"name": "Handover test"})
        task = self.env["project.task"].create({"name": "HO test", "project_id": project.id, "lg_lead_id": self.lead.id})
        self.assertEqual(self.lead.lg_handover_state, "awaiting")
        task.action_lg_accept_handover()
        self.assertEqual(self.lead.lg_handover_state, "accepted")
        self.assertEqual(self.lead.lg_handover_accepted_by_id, self.env.user)

    def test_customer_group_is_not_commercial_parent(self):
        group = self.env["res.partner"].create({"name": "Group X", "lg_is_customer_group": True})
        legal = self.env["res.partner"].create({"name": "Legal X", "lg_customer_group_id": group.id})
        contact = self.env["res.partner"].create({"name": "Person X", "parent_id": legal.id})
        self.assertEqual(legal.commercial_partner_id, legal)
        self.assertEqual(contact.commercial_partner_id, legal)
        self.assertEqual(contact.lg_group_id, group)
